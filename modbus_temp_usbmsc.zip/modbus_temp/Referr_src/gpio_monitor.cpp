/*
 * ESP32-S3 GPIO Monitoring System
 * 
 * Features:
 * - Monitors two GPIO inputs for state changes (toggle detection)
 * - Triggers events when GPIO state changes
 * - CSV logging to SD card with RTC timestamps
 * - USB Mass Storage for SD card access
 * - WiFi SoftAP for configuration
 * - OTA firmware updates
 * - SMS and MQTT alerts
 * - Modular architecture
 * 
 * Hardware Connections:
 * 
 * SD Card (SPI):
 * - MISO: GPIO 39, SCK: GPIO 40, MOSI: GPIO 41, CS: GPIO 42
 * 
 * RTC DS3231 (I2C):
 * - SDA: GPIO 11, SCL: GPIO 10
 * 
 * GPIO Inputs:
 * - Input 1: GPIO 4 (configurable)
 * - Input 2: GPIO 5 (configurable)
 * 
 * EC200U Modem (UART2):
 * - TX: GPIO 16, RX: GPIO 17, KEY: GPIO 38
 * 
 * USB Detection:
 * - VSTAT: GPIO 8
 */

#include "FS.h"
#include "SD.h"
#include "SPI.h"
#include "Wire.h"
#include "RTClib.h"
#include "USB.h"
#include "USBMSC.h"
#include <WiFi.h>
#include <WebServer.h>
#include <Update.h>
#include <ArduinoJson.h>
#include <Preferences.h>

// ==================== DEBUG CONTROL ====================
#define DEBUG_MODE 1
#include "debug.h"

// Include modular classes
#include "gpio_manager.h"
#include "mqtt.h"
#include "sms.h"
#include "sdcard.h"
#include "usbmsc.h"

// Pin Definitions
#define SD_MISO 39
#define SD_SCK  40
#define SD_MOSI 41
#define SD_CS   42
#define RTC_SDA 11
#define RTC_SCL 10
#define USB_VSTAT 8

// WiFi AP Settings
const char* AP_SSID = "GPIOMonitor01";
const char* AP_PASS = "12345678";

// Objects
RTC_DS3231 rtc;
HardwareSerial modemSerial(2); // Shared UART2 for modem
WebServer server(80);
Preferences preferences;

// Modular class instances
GPIOManager* gpioMgr = nullptr;
MQTTManager* mqttMgr = nullptr;
SMSManager* smsMgr = nullptr;
SDCardManager* sdcardMgr = nullptr;
USBMSCManager* usbmscMgr = nullptr;

// Global State
bool sdReady = false;
bool rtcReady = false;
bool mscMode = false;
bool apMode = false;
String currentLogFile = "";

// Modem State
bool modemReady = false;
bool simPresent = false;
bool networkRegistered = false;
int signalQuality = 0;
bool gprsConnected = false;
bool mqttConnected = false;
String modemIP = "";
String simProvider = "Unknown";

// Non-blocking MQTT reconnection
unsigned long lastMQTTReconnectAttempt = 0;
const unsigned long MQTT_RECONNECT_INTERVAL = 30000;  // Try every 30 seconds
bool mqttReconnecting = false;

// ==================== FUNCTION DECLARATIONS ====================
void initializeRTC();
void initializeModules();
void createTodayLogFile();
void logGPIOEvent(uint8_t inputNum, String status);
bool ensureMQTTConnection();
void backgroundMQTTReconnect();
void enableMSC();
void disableMSC();
void startSoftAP();
void stopSoftAP();
void setupWebServer();
String getRTCTimestamp();
String getRTCDate();

// ==================== SETUP ====================
void setup() {
  Serial.begin(115200);
  delay(100);
  
  pinMode(USB_VSTAT, INPUT);
  
  Serial.println("\n╔═══════════════════════════════════════╗");
  Serial.println("║       ESP32-S3 GPIO Monitor          ║");
  Serial.println("║       Modular Architecture           ║");
  Serial.println("╚═══════════════════════════════════════╝\n");
  
  initializeRTC();
  initializeModules();
  smsMgr->loadSMSConfig();
  
  // Activate GPRS and connect to MQTT
  if (modemReady && simPresent && networkRegistered) {
    Serial.println("\n[5/5] Setting up MQTT connection...");
    mqttMgr->activatePDPContext();
    gprsConnected = mqttMgr->isGPRSConnected();
    if (gprsConnected) {
      mqttMgr->connectToMQTT();
      mqttConnected = mqttMgr->isMQTTConnected();
    }
  }

  // Update SMS modem status after initial connections
  if (smsMgr) {
    smsMgr->setModemStatus(modemReady, networkRegistered, mqttConnected);
  }
  
  // Check for USB connection
  if (digitalRead(USB_VSTAT)) {
    Serial.println("🔌 USB Connected - Starting Mass Storage Mode");
    delay(500);
    enableMSC();
  } else {
    // Start WiFi AP Mode
    startSoftAP();
  }
}

// ==================== MAIN LOOP ====================
void loop() {
  // Check USB status
  static bool lastUSB = false;
  bool currentUSB = digitalRead(USB_VSTAT);
  
  if (currentUSB != lastUSB) {
    lastUSB = currentUSB;
    if (currentUSB) {
      Serial.println("\n🔌 USB Connected");
      delay(500);
      if (apMode) {
        stopSoftAP();
        delay(200);
      }
      enableMSC();
    } else {
      Serial.println("\n🔌 USB Disconnected");
      if (mscMode) {
        disableMSC();
        delay(500);
      }
      if (!apMode) {
        startSoftAP();
      }
    }
  }
  
  // Handle web server
  if (apMode && !mscMode) {
    server.handleClient();
  }

  // Handle GPIO Monitoring and Triggering
  if (gpioMgr && !mscMode) {
    gpioMgr->loop();

    if (gpioMgr->hasNewEvent()) {
      uint8_t eventSource = gpioMgr->getEventSource();
      String status1 = gpioMgr->getDGStatusString();
      String status2 = gpioMgr->getEBStatusString();

      Serial.printf("GPIO Event Detected on Input %d: DG_Status=%s, EB_Status=%s\n", 
                    eventSource, status1.c_str(), status2.c_str());

      INFO_PRINTLN("******** GPIO TRIGGER ACTIVATED ********");
      
      // 1. Log to SD Card (quick, no blocking)
      logGPIOEvent(eventSource, eventSource == 1 ? status1 : status2);

      // 2. Send SMS Alert (may take time, but proceed non-blocking)
      String smsMessage = "GPIO Alert\n";
      smsMessage += "DG Status: " + status1 + "\n";
      smsMessage += "EB Status: " + status2 + "\n";
      smsMessage += "Time: " + getRTCDate() + " " + getRTCTimestamp();
      
      if (smsMgr->isEnabled()) {
        smsMgr->sendCustomSMS(smsMessage);
        
        // After SMS, MQTT connection might be disrupted - force reconnection check
        delay(500);
        mqttConnected = mqttMgr->isMQTTConnected();
        if (!mqttConnected) {
          WARN_PRINTLN("⚠️ MQTT disconnected after SMS - attempting reconnection...");
          mqttMgr->connectToMQTT();
          mqttConnected = mqttMgr->isMQTTConnected();
          if (mqttConnected) {
            STATUS_OK("MQTT reconnected successfully!");
          }
        }
      }

      // 3. Publish to MQTT (if connected, don't block on reconnect)
      mqttConnected = mqttMgr->isMQTTConnected();  // Refresh status
      if (mqttConnected) {
        String timestamp = String(getRTCDate()) + "T" + String(getRTCTimestamp());
        String deviceStatus = String(eventSource) == "1" ? (status1 == "ON" ? "DG_ON" : "DG_OFF") : (status2 == "ON" ? "EB_ON" : "EB_OFF");
        
        // Use the new publishGPIOEvent function
        mqttMgr->publishGPIOEvent(MQTT_CLIENT_ID, deviceStatus, timestamp);
      } else {
        WARN_PRINTLN("⚠️ MQTT not connected - event will be retried on next background reconnect");
      }
      
      INFO_PRINTLN("****************************************");
      
      gpioMgr->clearEvent();
    }
  }
  
  // Background MQTT reconnection (non-blocking)
  if (!mscMode && !apMode) {
    backgroundMQTTReconnect();
  }
  
  delay(10);
}

// ==================== INITIALIZATION ====================

void initializeRTC() {
  Serial.println("═══════════════════════════════════════");
  Serial.println("RTC Initialization");
  Serial.println("═══════════════════════════════════════");
  
  Wire.begin(RTC_SDA, RTC_SCL);
  
  if (rtc.begin(&Wire)) {
    rtcReady = true;
    Serial.println("✅ RTC OK");
    
    if (rtc.lostPower()) {
      Serial.println("⚠️  Setting default time");
      rtc.adjust(DateTime(2025, 1, 1, 0, 0, 0));
    }
    
    DateTime now = rtc.now();
    Serial.printf("Time: %04d-%02d-%02d %02d:%02d:%02d\n",
                  now.year(), now.month(), now.day(),
                  now.hour(), now.minute(), now.second());
  } else {
    rtcReady = false;
    Serial.println("❌ RTC Failed");
  }
  Serial.println();
}

void initializeModules() {
  // Initialize SD Card Manager
  sdcardMgr = new SDCardManager(SD_MISO, SD_SCK, SD_MOSI, SD_CS);
  sdcardMgr->initialize();
  sdReady = sdcardMgr->isReady();
  
  createTodayLogFile();
  
  // Initialize USB MSC Manager
  usbmscMgr = new USBMSCManager();
  
  // Initialize GPIO Manager
  gpioMgr = new GPIOManager();
  gpioMgr->begin();

  // Initialize MQTT Manager (share same modem serial)
  mqttMgr = new MQTTManager(&rtc, &modemSerial);
  mqttMgr->initializeModem();
  modemReady = mqttMgr->isModemReady();
  simPresent = mqttMgr->isSIMReady();
  networkRegistered = mqttMgr->isNetworkRegistered();
  signalQuality = mqttMgr->getSignalQualityValue();
  simProvider = mqttMgr->getSIMProvider();
  gprsConnected = mqttMgr->isGPRSConnected();
  
  // Initialize SMS Manager
  smsMgr = new SMSManager(&rtc, &modemSerial);
  smsMgr->setModemStatus(modemReady, networkRegistered, mqttMgr->isMQTTConnected());
}

// ==================== NON-BLOCKING MQTT RECONNECTION ====================

void backgroundMQTTReconnect() {
  unsigned long now = millis();
  
  // Only attempt reconnection at intervals to avoid blocking
  if (now - lastMQTTReconnectAttempt < MQTT_RECONNECT_INTERVAL) {
    return;  // Not time yet
  }
  
  if (mqttReconnecting || mqttConnected) {
    return;  // Already connected or reconnecting
  }
  
  if (!modemReady) {
    return;  // Modem not ready
  }
  
  lastMQTTReconnectAttempt = now;
  mqttReconnecting = true;
  
  DEBUG_PRINTLN("[MQTT] Background reconnection attempt...");
  
  // Try GPRS first (quick check)
  if (!gprsConnected) {
    gprsConnected = mqttMgr->checkGPRSStatus();
    if (!gprsConnected) {
      DEBUG_PRINTLN("[MQTT] GPRS check failed, will retry later");
      mqttReconnecting = false;
      return;
    }
  }
  
  // Connect to MQTT
  mqttMgr->connectToMQTT();
  mqttConnected = mqttMgr->isMQTTConnected();
  
  if (mqttConnected) {
    STATUS_OK("MQTT reconnected in background");
  } else {
    WARN_PRINTLN("[MQTT] Background reconnection failed, will retry");
  }
  
  mqttReconnecting = false;
}

// ==================== LOGGING ====================

static unsigned long logEntryCount = 0;

void createTodayLogFile() {
  if (!sdReady || !rtcReady || !sdcardMgr) return;
  
  DateTime now = rtc.now();
  char filename[32];
  sprintf(filename, "/%04d-%02d-%02d.csv", now.year(), now.month(), now.day());
  currentLogFile = String(filename);
  
  if (!sdcardMgr->fileExists(filename)) {
    File f = sdcardMgr->openFile(filename, "write");
    if (f) {
      f.println("S.No,Timestamp,Input_Number,Status,DG_Status,EB_Status");
      f.close();
      Serial.printf("📝 Created log: %s\n", filename);
      logEntryCount = 0;
    }
  }
}

void logGPIOEvent(uint8_t inputNum, String status) {
  if (!sdReady || !rtcReady || !sdcardMgr) return;
  
  createTodayLogFile();
  logEntryCount++;
  
  DateTime now = rtc.now();
  
  File f = sdcardMgr->openFile(currentLogFile.c_str(), "append");
  if (f) {
    char timestamp[32];
    sprintf(timestamp, "%02d:%02d:%02d",
            now.hour(), now.minute(), now.second());
    
    f.printf("%lu,%s,%d,%s,%s,%s\n",
             logEntryCount,
             timestamp,
             inputNum,
             status.c_str(),
             gpioMgr->getDGStatusString().c_str(),
             gpioMgr->getEBStatusString().c_str());
    f.close();
    
    Serial.printf("📝 Logged [%lu]: %s - Input%d: %s (DG:%s, EB:%s)\n", 
                  logEntryCount, timestamp, inputNum, status.c_str(),
                  gpioMgr->getDGStatusString().c_str(),
                  gpioMgr->getEBStatusString().c_str());
  }
}

// ==================== UTILITY FUNCTIONS ====================

// Attempt to bring MQTT back online before publishing events
bool ensureMQTTConnection() {
  if (!mqttMgr) return false;
  
  // Update local connection status from manager
  mqttConnected = mqttMgr->isMQTTConnected();
  if (mqttConnected) return true;
  
  // Don't block here - just return false
  // Background reconnection will handle it
  DEBUG_PRINTLN("⚠️ MQTT not connected - will reconnect in background");
  return false;
}

// ==================== USB MASS STORAGE ====================

void enableMSC() {
  if (!sdReady || mscMode || !sdcardMgr || !usbmscMgr) return;
  
  uint64_t cardSize = sdcardMgr->getCardSize();
  if (cardSize == 0) return;
  
  usbmscMgr->enable(cardSize);
  
  mscMode = true;
  Serial.println("💾 USB Mass Storage ENABLED");
}

void disableMSC() {
  if (!mscMode || !sdcardMgr || !usbmscMgr) return;
  
  usbmscMgr->disable();
  mscMode = false;
  
  Serial.println("💾 USB Mass Storage DISABLED");
  
  delay(500);
  sdcardMgr->reinitialize();
}

// ==================== WIFI SOFT AP ====================

void startSoftAP() {
  Serial.println("\n═══════════════════════════════════════");
  Serial.println("Starting WiFi Access Point");
  Serial.println("═══════════════════════════════════════");
  
  WiFi.softAP(AP_SSID, AP_PASS);
  IPAddress IP = WiFi.softAPIP();
  
  Serial.printf("SSID: %s\n", AP_SSID);
  Serial.printf("Password: %s\n", AP_PASS);
  Serial.printf("IP: %s\n", IP.toString().c_str());
  Serial.println("═══════════════════════════════════════\n");
  
  setupWebServer();
  server.begin();
  apMode = true;
}

void stopSoftAP() {
  if (!apMode) return;
  
  server.stop();
  WiFi.softAPdisconnect(true);
  apMode = false;
  Serial.println("📡 WiFi AP Stopped");
}

// ==================== UTILITY FUNCTIONS ====================

String getRTCTimestamp() {
  if (!rtcReady) return "00:00:00";
  
  DateTime now = rtc.now();
  char timestamp[16];
  sprintf(timestamp, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  return String(timestamp);
}

String getRTCDate() {
  if (!rtcReady) return "0000-00-00";
  
  DateTime now = rtc.now();
  char date[16];
  sprintf(date, "%04d-%02d-%02d", now.year(), now.month(), now.day());
  return String(date);
}

// ==================== WEB SERVER ====================

void setupWebServer() {
  server.on("/", HTTP_GET, []() {
    String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>⚙️ GPIO Monitor System</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:linear-gradient(135deg,#2b5876 0%,#4e4376 100%);min-height:100vh;padding:20px}
.container{max-width:900px;margin:0 auto;background:rgba(255,255,255,0.98);padding:30px;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3)}
h1{color:#2b5876;text-align:center;margin-bottom:10px;font-size:2em;text-shadow:2px 2px 4px rgba(0,0,0,0.1)}
.subtitle{text-align:center;color:#666;margin-bottom:30px;font-size:0.9em}
.tabs{display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap}
.tab{flex:1;min-width:120px;padding:12px;background:#2b5876;color:#fff;border:none;border-radius:10px;cursor:pointer;font-size:14px;font-weight:bold;transition:all 0.3s;text-align:center}
.tab:hover{background:#4e4376;transform:translateY(-2px);box-shadow:0 5px 15px rgba(0,0,0,0.2)}
.tab.active{background:#4e4376;box-shadow:0 5px 15px rgba(0,0,0,0.3)}
.content{display:none;animation:fadeIn 0.5s}
.content.active{display:block}
@keyframes fadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
.card{background:#f8f9fa;padding:20px;margin:15px 0;border-radius:15px;box-shadow:0 5px 15px rgba(0,0,0,0.1)}
.card h2{color:#2b5876;margin-bottom:15px;font-size:1.3em;display:flex;align-items:center;gap:10px}
.form-group{margin:15px 0}
label{display:block;margin-bottom:8px;font-weight:600;color:#333;font-size:0.95em}
input,select,textarea{width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:15px;transition:all 0.3s;background:#fff}
input:focus,select:focus,textarea:focus{outline:none;border-color:#2b5876;box-shadow:0 0 0 3px rgba(43,88,118,0.1)}
button{width:100%;padding:14px;background:linear-gradient(135deg,#2b5876,#4e4376);color:#fff;border:none;border-radius:10px;cursor:pointer;font-size:16px;font-weight:bold;transition:all 0.3s;margin-top:10px}
button:hover{transform:translateY(-2px);box-shadow:0 5px 20px rgba(43,88,118,0.4)}
.status{padding:15px;margin:15px 0;border-radius:10px;font-size:14px;display:none}
.status.show{display:block;animation:slideIn 0.3s}
@keyframes slideIn{from{opacity:0;transform:translateX(-20px)}to{opacity:1;transform:translateX(0)}}
.success{background:#d4edda;color:#155724;border-left:5px solid #28a745}
.error{background:#f8d7da;color:#721c24;border-left:5px solid #dc3545}
.info{background:#d1ecf1;color:#0c5460;border-left:5px solid #17a2b8}
.gpio-status{display:flex;gap:20px;margin-top:15px}
.gpio-box{flex:1;padding:20px;border-radius:10px;text-align:center;font-size:1.2em;font-weight:bold}
.gpio-on{background:#d4edda;color:#155724}
.gpio-off{background:#f8d7da;color:#721c24}
</style>
</head>
<body>
<div class="container">
<h1>⚙️ GPIO Monitor System</h1>
<p class="subtitle">Configuration & Management Portal</p>

<div class="tabs">
<button class="tab active" onclick="switchTab('gpio')">🔧 GPIO</button>
<button class="tab" onclick="switchTab('sms')">📱 SMS</button>
<button class="tab" onclick="switchTab('datetime')">🕒 Date/Time</button>
<button class="tab" onclick="switchTab('status')">📊 Status</button>
<button class="tab" onclick="switchTab('ota')">⬆️ OTA</button>
<button class="tab" onclick="switchTab('system')">⚙️ System</button>
</div>

<div id="gpio" class="content active">
<div class="card">
<h2>🔧 GPIO Settings</h2>
<div class="form-group">
<label for="gpio1pin">GPIO Input 1 Pin Number</label>
<input type="number" id="gpio1pin" min="0" max="48" placeholder="e.g., 4">
</div>
<div class="form-group">
<label for="gpio2pin">GPIO Input 2 Pin Number</label>
<input type="number" id="gpio2pin" min="0" max="48" placeholder="e.g., 5">
</div>
<div class="form-group">
<label for="debounce">Debounce Time (milliseconds)</label>
<input type="number" id="debounce" min="0" max="1000" placeholder="e.g., 50">
</div>
<button onclick="saveGPIOConfig()">💾 Save GPIO Settings</button>
<div id="gpio-status" class="status"></div>
</div>
</div>

<div id="sms" class="content">
<div class="card">
<h2>📱 SMS Settings</h2>
<div class="form-group">
<label style="display:flex;align-items:center;gap:10px;"><input type="checkbox" id="smsEnabled" style="width:auto">Enable SMS Notifications</label>
</div>
<div class="form-group">
<label>📞 Phone Number 1</label>
<input type="text" id="smsPhone1" placeholder="Enter primary phone number">
</div>
<div class="form-group">
<label>📞 Phone Number 2 (Optional)</label>
<input type="text" id="smsPhone2" placeholder="Enter secondary phone number">
</div>
<p class="info status show">SMS will include both input statuses when any input toggles.</p>
<button onclick="saveSMSConfig()">💾 Save SMS Settings</button>
<div id="sms-status" class="status"></div>
<hr style="margin:20px 0">
<h3 style="color:#2b5876;margin-bottom:15px">📤 Test SMS</h3>
<div class="form-group">
<label>Test Phone Number</label>
<input type="text" id="testPhone" placeholder="Enter phone number for test">
</div>
<div class="form-group">
<label>Test Message</label>
<textarea id="testMessage" rows="3" placeholder="Enter test message">GPIO Monitor Test Message</textarea>
</div>
<button onclick="sendTestSMS()">📨 Send Test SMS</button>
<div id="test-sms-status" class="status"></div>
</div>
</div>

<div id="datetime" class="content">
<div class="card">
<h2>🕒 Set Date & Time</h2>
<div class="form-group">
<label>Select Date and Time</label>
<input type="datetime-local" id="datetime">
</div>
<button onclick="setDateTime()">✅ Update Date & Time</button>
<div id="datetime-status" class="status"></div>
</div>
</div>

<div id="status" class="content">
<div class="card">
<h2>📊 System Status</h2>
<button onclick="updateStatus()" style="margin-bottom:15px">🔄 Refresh Status</button>
<div id="status-info"></div>
<div class="gpio-status">
<div class="gpio-box" id="gpio1-box">Input 1: --</div>
<div class="gpio-box" id="gpio2-box">Input 2: --</div>
</div>
</div>
</div>

<div id="ota" class="content">
<div class="card">
<h2>⬆️ OTA Firmware Update</h2>
<div class="form-group">
<label>Select firmware (.bin)</label>
<input type="file" id="otaFile" accept=".bin,.bin.gz">
</div>
<button onclick="uploadOTA()">🚀 Upload & Update</button>
<div id="ota-status" class="status"></div>
</div>
</div>

<div id="system" class="content">
<div class="card">
<h2>⚙️ System Control</h2>
<div class="info status show" style="margin-bottom:20px">
⚠️ Warning: Restarting the ESP32 will temporarily disconnect all connections.
</div>
<button onclick="restartESP()" style="background:linear-gradient(135deg,#dc3545,#c82333)">🔄 Restart ESP32</button>
<div id="restart-status" class="status"></div>
</div>
</div>

</div>

<script>
function switchTab(tab){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.content').forEach(c=>c.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById(tab).classList.add('active');
  if(tab==='gpio') loadGPIOConfig();
  if(tab==='sms') loadSMSConfig();
  if(tab==='status') updateStatus();
}

function showStatus(id,message,type){
  const el=document.getElementById(id);
  el.className='status '+type+' show';
  el.innerHTML=message;
  setTimeout(()=>el.classList.remove('show'),5000);
}

function loadGPIOConfig(){
  fetch('/gpioconfig').then(r=>r.json()).then(d=>{
    document.getElementById('gpio1pin').value = d.gpio1_pin || '';
    document.getElementById('gpio2pin').value = d.gpio2_pin || '';
    document.getElementById('debounce').value = d.debounce || '';
  });
}

function saveGPIOConfig(){
  const params=new URLSearchParams({
    gpio1_pin: document.getElementById('gpio1pin').value,
    gpio2_pin: document.getElementById('gpio2pin').value,
    debounce: document.getElementById('debounce').value
  });
  fetch('/savegpio?'+params).then(r=>r.json()).then(d=>{
    showStatus('gpio-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function loadSMSConfig(){
  fetch('/smsconfig').then(r=>r.json()).then(d=>{
    document.getElementById('smsEnabled').checked=d.enabled;
    document.getElementById('smsPhone1').value=d.phone1||'';
    document.getElementById('smsPhone2').value=d.phone2||'';
  });
}

function saveSMSConfig(){
  const params=new URLSearchParams({
    enabled:document.getElementById('smsEnabled').checked,
    phone1:document.getElementById('smsPhone1').value,
    phone2:document.getElementById('smsPhone2').value
  });
  fetch('/savesms?'+params).then(r=>r.json()).then(d=>{
    showStatus('sms-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function sendTestSMS(){
  const phone = document.getElementById('testPhone').value;
  const message = document.getElementById('testMessage').value;
  if(!phone || !message){
    showStatus('test-sms-status','❌ Please enter both phone and message','error');
    return;
  }
  showStatus('test-sms-status','⏳ Sending test SMS...','info');
  const params=new URLSearchParams({phone:phone,message:message});
  fetch('/testsms?'+params).then(r=>r.json()).then(d=>{
    showStatus('test-sms-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function setDateTime(){
  let dt=document.getElementById('datetime').value;
  if(!dt){
    const now=new Date();
    dt=now.getFullYear()+'-'+(now.getMonth()+1).toString().padStart(2,'0')+'-'+now.getDate().toString().padStart(2,'0')+'T'+now.getHours().toString().padStart(2,'0')+':'+now.getMinutes().toString().padStart(2,'0');
  }
  fetch('/settime?datetime='+encodeURIComponent(dt)).then(r=>r.json()).then(d=>{
    showStatus('datetime-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function updateStatus(){
  fetch('/status').then(r=>r.json()).then(d=>{
    let html = '<p><strong>📅 RTC Time:</strong> '+d.time+'</p>';
    html += '<p><strong>🔧 GPIO1 Pin:</strong> '+d.gpio1_pin+'</p>';
    html += '<p><strong>🔧 GPIO2 Pin:</strong> '+d.gpio2_pin+'</p>';
    html += '<p><strong>⏱️ Debounce Time:</strong> '+d.debounce+'ms</p>';
    html += '<hr style="margin:15px 0">';
    html += '<h3 style="color:#2b5876;margin:15px 0">📡 Modem Status</h3>';
    html += '<p><strong>Modem Ready:</strong> '+(d.modem_ready ? '✅ Yes' : '❌ No')+'</p>';
    html += '<p><strong>SIM Card:</strong> '+(d.sim_present ? '✅ Inserted' : '❌ Not Found')+'</p>';
    html += '<p><strong>Network:</strong> '+(d.network_registered ? '✅ Registered' : '❌ Not Registered')+'</p>';
    html += '<p><strong>Signal Strength:</strong> '+d.signal_quality+'/31 '+(d.signal_quality > 20 ? '📶' : d.signal_quality > 10 ? '📶' : '📶')+'</p>';
    html += '<p><strong>SIM Provider:</strong> '+d.sim_provider+'</p>';
    html += '<p><strong>APN:</strong> '+d.apn+'</p>';
    html += '<p><strong>GPRS:</strong> '+(d.gprs_connected ? '✅ Connected' : '❌ Disconnected')+'</p>';
    html += '<p><strong>Modem IP:</strong> '+(d.modem_ip || 'Not Assigned')+'</p>';
    html += '<p><strong>MQTT:</strong> '+(d.mqtt_connected ? '✅ Connected' : '❌ Disconnected')+'</p>';
    document.getElementById('status-info').innerHTML=html;
    
    // Update GPIO status boxes
    const gpio1Box = document.getElementById('gpio1-box');
    const gpio2Box = document.getElementById('gpio2-box');
    gpio1Box.textContent = 'DG Status: ' + d.dg_status;
    gpio2Box.textContent = 'EB Status: ' + d.eb_status;
    gpio1Box.className = 'gpio-box ' + (d.dg_status === 'ON' ? 'gpio-on' : 'gpio-off');
    gpio2Box.className = 'gpio-box ' + (d.eb_status === 'ON' ? 'gpio-on' : 'gpio-off');
  });
}

function uploadOTA(){
  const f=document.getElementById('otaFile').files[0];
  if(!f){ showStatus('ota-status','❌ Please select a firmware file','error'); return; }
  const fd=new FormData();
  fd.append('update', f, f.name);
  showStatus('ota-status','⏳ Uploading firmware...','info');
  fetch('/update', {method:'POST', body:fd})
    .then(r=>r.json())
    .then(d=>{
      if(d.success){
        showStatus('ota-status','✅ Update successful. Rebooting...','success');
        setTimeout(()=>{ location.reload(); }, 5000);
      } else {
        showStatus('ota-status','❌ Update failed: ' + (d.error || ''),'error');
      }
    }).catch(()=>{ showStatus('ota-status','❌ Upload error','error'); });
}

function restartESP(){
  if(!confirm('Are you sure you want to restart the ESP32?')) return;
  showStatus('restart-status','⏳ Restarting ESP32...','info');
  fetch('/restart').then(r=>r.json()).then(d=>{
    if(d.success){
      showStatus('restart-status','✅ ESP32 is restarting. Please wait...','success');
      setTimeout(()=>{ location.reload(); }, 5000);
    } else {
      showStatus('restart-status','❌ Restart failed','error');
    }
  }).catch(()=>{ showStatus('restart-status','❌ Connection error','error'); });
}

// Load initial config on page load
window.onload = () => {
  loadGPIOConfig();
  updateStatus();
  setInterval(updateStatus, 2000); // Auto-refresh status every 2 seconds
};

</script>
</body>
</html>
)rawliteral";
    server.send(200, "text/html", html);
  });

  // Get GPIO config
  server.on("/gpioconfig", HTTP_GET, []() {
    if (!gpioMgr) return;
    String json = "{";
    json += "\"gpio1_pin\":" + String(gpioMgr->getGPIO1Pin()) + ",";
    json += "\"gpio2_pin\":" + String(gpioMgr->getGPIO2Pin()) + ",";
    json += "\"debounce\":" + String(gpioMgr->getDebounceTime());
    json += "}";
    server.send(200, "application/json", json);
  });

  // Save GPIO config
  server.on("/savegpio", HTTP_GET, []() {
    if (!gpioMgr) return;
    if (server.hasArg("gpio1_pin")) {
      gpioMgr->setGPIO1Pin(server.arg("gpio1_pin").toInt());
    }
    if (server.hasArg("gpio2_pin")) {
      gpioMgr->setGPIO2Pin(server.arg("gpio2_pin").toInt());
    }
    if (server.hasArg("debounce")) {
      gpioMgr->setDebounceTime(server.arg("debounce").toInt());
    }
    gpioMgr->saveConfig();
    server.send(200, "application/json", "{\"success\":true,\"message\":\"GPIO settings saved!\"}");
  });

  // Get SMS config
  server.on("/smsconfig", HTTP_GET, []() {
    String json = "{";
    json += "\"enabled\":" + String(smsMgr->isEnabled() ? "true" : "false") + ",";
    json += "\"phone1\":\"" + smsMgr->getSMSPhone1() + "\",";
    json += "\"phone2\":\"" + smsMgr->getSMSPhone2() + "\"";
    json += "}";
    server.send(200, "application/json", json);
  });
  
  // Save SMS config
  server.on("/savesms", HTTP_GET, []() {
    if (server.hasArg("enabled")) {
      smsMgr->setEnabled(server.arg("enabled") == "true");
    }
    if (server.hasArg("phone1")) {
      smsMgr->setSMSPhone1(server.arg("phone1"));
    }
    if (server.hasArg("phone2")) {
      smsMgr->setSMSPhone2(server.arg("phone2"));
    }
    smsMgr->saveSMSConfig();
    server.send(200, "application/json", "{\"success\":true,\"message\":\"SMS settings saved!\"}");
  });

  // Test SMS endpoint
  server.on("/testsms", HTTP_GET, []() {
    if (!server.hasArg("phone") || !server.hasArg("message")) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Phone and message required\"}");
      return;
    }
    String phone = server.arg("phone");
    String message = server.arg("message");
    
    if (smsMgr) {
      smsMgr->sendSMS(phone, message);
      server.send(200, "application/json", "{\"success\":true,\"message\":\"Test SMS sent!\"}");
    } else {
      server.send(500, "application/json", "{\"success\":false,\"message\":\"SMS manager not available\"}");
    }
  });

  // Set date/time
  server.on("/settime", HTTP_GET, []() {
    if (!server.hasArg("datetime") || !rtcReady) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid request\"}");
      return;
    }
    String dt = server.arg("datetime");
    rtc.adjust(DateTime(dt.substring(0, 4).toInt(), dt.substring(5, 7).toInt(), dt.substring(8, 10).toInt(), dt.substring(11, 13).toInt(), dt.substring(14, 16).toInt(), 0));
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Time updated\"}");
  });
  
  // Get system status
  server.on("/status", HTTP_GET, []() {
    String json = "{";
    json += "\"time\":\"" + getRTCDate() + " " + getRTCTimestamp() + "\",";
    if (gpioMgr) {
      json += "\"gpio1_pin\":" + String(gpioMgr->getGPIO1Pin()) + ",";
      json += "\"gpio2_pin\":" + String(gpioMgr->getGPIO2Pin()) + ",";
      json += "\"debounce\":" + String(gpioMgr->getDebounceTime()) + ",";
      json += "\"dg_status\":\"" + gpioMgr->getDGStatusString() + "\",";
      json += "\"eb_status\":\"" + gpioMgr->getEBStatusString() + "\",";
    }
    json += "\"mqtt_connected\":" + String(mqttConnected ? "true" : "false") + ",";
    json += "\"modem_ready\":" + String(modemReady ? "true" : "false") + ",";
    json += "\"sim_present\":" + String(simPresent ? "true" : "false") + ",";
    json += "\"network_registered\":" + String(networkRegistered ? "true" : "false") + ",";
    json += "\"gprs_connected\":" + String(gprsConnected ? "true" : "false") + ",";
    json += "\"signal_quality\":" + String(signalQuality) + ",";
    json += "\"sim_provider\":\"" + simProvider + "\",";
    json += "\"modem_ip\":\"" + modemIP + "\",";
    json += "\"apn\":\"" + (mqttMgr ? mqttMgr->getAPN() : "unknown") + "\"";
    json += "}";
    server.send(200, "application/json", json);
  });

  // OTA firmware update
  server.on("/update", HTTP_POST,
    []() {
      bool ok = !Update.hasError();
      String resp = "{\"success\":" + String(ok ? "true" : "false") + ",\"error\":\"" + (Update.hasError() ? String(Update.errorString()) : "") + "\"}";
      server.send(200, "application/json", resp);
      if (ok) { ESP.restart(); }
    },
    []() {
      HTTPUpload &upload = server.upload();
      if (upload.status == UPLOAD_FILE_START) {
        if (!Update.begin(UPDATE_SIZE_UNKNOWN)) { Update.printError(Serial); }
      } else if (upload.status == UPLOAD_FILE_WRITE) {
        if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) { Update.printError(Serial); }
      } else if (upload.status == UPLOAD_FILE_END) {
        if (!Update.end(true)) { Update.printError(Serial); }
      }
    }
  );
  // ESP32 restart endpoint
  server.on("/restart", HTTP_GET, []() {
    server.send(200, "application/json", "{\"success\":true,\"message\":\"ESP32 restarting...\"}");
    delay(1000);
    ESP.restart();
  });}
