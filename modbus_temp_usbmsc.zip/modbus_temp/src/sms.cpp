#include "sms.h"
#include "debug.h"
#include <Preferences.h>

static Preferences preferences;

SMSManager::SMSManager(RTC_DS3231* rtcPtr, HardwareSerial* modemPtr)
  : rtc(rtcPtr), rtcReady(rtcPtr != nullptr), modemSerial(modemPtr),
    modemReady(false), networkRegistered(false), smsEnabled(true),
    apn_name("bsnlnet"), mqttConnected(false) {
}

SMSManager::~SMSManager() {
}

void SMSManager::loadSMSConfig() {
  preferences.begin("sms", true);
  
  smsPhone1 = preferences.getString("phone1", "");
  smsPhone2 = preferences.getString("phone2", "");
  smsMessage = preferences.getString("message", "Access Granted: {name} ({personID}) scanned at {time} on {date}");
  smsEnabled = preferences.getBool("enabled", true);
  
  preferences.end();
  
  INFO_PRINTLN("\n═══ SMS Configuration (from Flash) ═══");
  INFO_PRINTLN("Phone 1: " + (smsPhone1.length() > 0 ? smsPhone1 : "(not set)"));
  INFO_PRINTLN("Phone 2: " + (smsPhone2.length() > 0 ? smsPhone2 : "(not set)"));
  INFO_PRINTLN("Enabled: " + String(smsEnabled ? "Yes" : "No"));
  INFO_PRINTLN("═══════════════════════════════════════\n");
}

void SMSManager::saveSMSConfig() {
  preferences.begin("sms", false);
  
  preferences.putString("phone1", smsPhone1);
  preferences.putString("phone2", smsPhone2);
  preferences.putString("message", smsMessage);
  preferences.putBool("enabled", smsEnabled);
  
  preferences.end();
  
  STATUS_OK("SMS config saved to flash!");
}

bool SMSManager::sendSMS(String number, String message) {
  // Try to initialize modem on-demand if not ready
  if (!modemReady || !networkRegistered) {
    INFO_PRINTLN("� Modem not ready - attempting on-demand initialization...");
    // This would need access to MQTTManager - for now just fail gracefully
    STATUS_FAIL("Modem/SIM not ready - SMS not sent");
    DEBUG_PRINTF("   Modem:%d Network:%d\n", modemReady, networkRegistered);
    DEBUG_PRINTLN("   Tip: Insert SIM card and restart device");
    return false;
  }
  
  if (number.length() == 0) {
    WARN_PRINTLN("Phone number not configured");
    return false;
  }
  
  // IMPORTANT: Send MQTT keepalive BEFORE SMS to keep connection alive
  if (mqttConnected) {
    DEBUG_PRINTLN("Sending MQTT keepalive before SMS...");
    String keepCmd = "AT+QMTPING=0";
    modemSerial->println(keepCmd);
    
    unsigned long keepStart = millis();
    String keepResponse = "";
    while (millis() - keepStart < 5000) {
      if (modemSerial->available()) {
        keepResponse += (char)modemSerial->read();
      }
    }
    
    if (keepResponse.indexOf("OK") != -1) {
      STATUS_OK("Keepalive sent - MQTT connection refreshed");
    } else {
      WARN_PRINTLN("Keepalive failed");
    }
  }
  
  // Add +91 prefix if number doesn't start with +
  if (!number.startsWith("+")) {
    number = "+91" + number;
    DEBUG_PRINTLN("Added country code: " + number);
  }
  
  INFO_PRINTLN("\n📤 Sending SMS to " + number + "...");
  
  // Clear buffer
  DEBUG_PRINTLN("[SMS] Clearing serial buffer...");
  delay(100);
  int cleared = 0;
  while (modemSerial->available()) {
    modemSerial->read();
    cleared++;
  }
  DEBUG_PRINTF("[SMS] Cleared %d bytes\n", cleared);
  delay(100);
  
  // Quick modem check
  DEBUG_PRINTLN("[SMS] Testing modem with AT command...");
  modemSerial->println("AT");
  unsigned long checkStart = millis();
  String checkResponse = "";
  while (millis() - checkStart < 2000) {
    if (modemSerial->available()) {
      char c = modemSerial->read();
      checkResponse += c;
      Serial.print(c); // Show response in real-time
    }
  }
  DEBUG_PRINTF("[SMS] AT Response (len=%d): [%s]\n", checkResponse.length(), checkResponse.c_str());
  
  if (checkResponse.indexOf("OK") == -1) {
    STATUS_FAIL("Modem not responding to AT command");
    DEBUG_PRINTLN("[SMS] ERROR: Expected 'OK' but got different response");
    DEBUG_PRINTLN("[SMS] This usually means modem serial is busy or disconnected");
    return false;
  }
  DEBUG_PRINTLN("[SMS] ✅ Modem responding");
  delay(300);
  
  // Set SMS text mode
  DEBUG_PRINTLN("[SMS] Setting text mode: AT+CMGF=1");
  modemSerial->println("AT+CMGF=1");
  
  unsigned long start = millis();
  String response = "";
  while (millis() - start < 3000) {
    if (modemSerial->available()) {
      char c = modemSerial->read();
      response += c;
      Serial.print(c);
    }
  }
  DEBUG_PRINTF("[SMS] CMGF Response (len=%d): [%s]\n", response.length(), response.c_str());
  
  if (response.indexOf("OK") == -1) {
    STATUS_FAIL("SMS mode failed!");
    DEBUG_PRINTLN("[SMS] ERROR: CMGF command rejected or timed out");
    return false;
  }
  STATUS_OK("SMS mode set");
  
  delay(500);
  cleared = 0;
  while (modemSerial->available()) {
    modemSerial->read();
    cleared++;
  }
  DEBUG_PRINTF("[SMS] Cleared %d bytes before CSCS\n", cleared);
  
  // Set character set to GSM
  DEBUG_PRINTLN("[SMS] Setting charset: AT+CSCS=\"GSM\"");
  modemSerial->println("AT+CSCS=\"GSM\"");
  
  start = millis();
  response = "";
  while (millis() - start < 2000) {
    if (modemSerial->available()) {
      char c = modemSerial->read();
      response += c;
      Serial.print(c);
    }
  }
  DEBUG_PRINTF("[SMS] CSCS Response: [%s]\n", response.c_str());
  
  if (response.indexOf("OK") != -1) {
    STATUS_OK("Character set: GSM");
  } else {
    WARN_PRINTLN("Character set command failed (non-critical)");
  }
  
  delay(500);
  cleared = 0;
  while (modemSerial->available()) {
    modemSerial->read();
    cleared++;
  }
  DEBUG_PRINTF("[SMS] Cleared %d bytes before CMGS\n", cleared);
  
  // Send SMS command
  String cmd = "AT+CMGS=\"" + number + "\"";
  DEBUG_PRINTLN("[SMS] Sending: " + cmd);
  modemSerial->println(cmd);
  
  // Wait for '>' prompt
  start = millis();
  bool promptReceived = false;
  response = "";
  DEBUG_PRINTLN("[SMS] Waiting for '>' prompt...");
  
  while (millis() - start < 5000) {
    if (modemSerial->available()) {
      char c = modemSerial->read();
      response += c;
      Serial.print(c); // Show response in real-time
      if (c == '>') {
        promptReceived = true;
        DEBUG_PRINTLN("\n[SMS] ✅ Got '>' prompt!");
        break;
      }
    }
  }
  
  if (!promptReceived) {
    STATUS_FAIL("No '>' prompt received!");
    DEBUG_PRINTF("[SMS] Timeout after %dms\n", (int)(millis() - start));
    DEBUG_PRINTF("[SMS] Response received (len=%d): [%s]\n", response.length(), response.c_str());
    DEBUG_PRINTLN("[SMS] Sending ESC to cancel...");
    modemSerial->write(0x1B);
    delay(100);
    while (modemSerial->available()) modemSerial->read();
    return false; // SMS operation failed
  }
  
  STATUS_OK("Got prompt, sending message...");
  delay(100);
  
  // Send message
  DEBUG_PRINTF("[SMS] Message (len=%d): %s\n", message.length(), message.c_str());
  modemSerial->print(message);
  
  delay(300);
  DEBUG_PRINTLN("[SMS] Sending Ctrl+Z (0x1A) to submit...");
  modemSerial->write(0x1A);
  
  // Wait for send confirmation
  start = millis();
  response = "";
  DEBUG_PRINTLN("[SMS] Waiting for +CMGS confirmation (timeout: 30s)...");
  
  while (millis() - start < 30000) {
    if (modemSerial->available()) {
      char c = modemSerial->read();
      response += c;
      Serial.print(c);
      if (response.indexOf("+CMGS:") != -1 && response.indexOf("OK") != -1) {
        DEBUG_PRINTF("\n[SMS] ✅ Confirmation received after %dms\n", (int)(millis() - start));
        INFO_PRINTLN("✅✅✅ SMS sent successfully!");
        
        // IMPORTANT: Check and restore MQTT connection after SMS
        delay(1000);
        if (mqttConnected) {
          String mqttCheck = "AT+QMTCONN?";
          modemSerial->println(mqttCheck);
          
          unsigned long mqttStart = millis();
          String mqttResponse = "";
          while (millis() - mqttStart < 2000) {
            if (modemSerial->available()) {
              mqttResponse += (char)modemSerial->read();
            }
          }
          
          if (mqttResponse.indexOf("+QMTCONN: 0,0,0") == -1) {
            WARN_PRINTLN("⚠️ MQTT disconnected after SMS");
          } else {
            STATUS_OK("MQTT still connected");
          }
        }
        
        return true; // SMS sent successfully
      }
      if (response.indexOf("ERROR") != -1 || response.indexOf("+CMS ERROR") != -1) {
        // Parse CMS error code
        int errorIdx = response.indexOf("+CMS ERROR:");
        String errorMsg = "SMS send error";
        if (errorIdx != -1) {
          String errorCode = response.substring(errorIdx + 12);
          errorCode.trim();
          errorMsg += " (Code: " + errorCode + ")";
          
          // Common error codes
          if (errorCode == "304") errorMsg += " - SMSC not set";
          else if (errorCode == "305") errorMsg += " - Invalid destination";
          else if (errorCode == "330") errorMsg += " - Service not subscribed";
          else if (errorCode == "500") errorMsg += " - Unknown error";
        }
        STATUS_FAIL(errorMsg + "\nResponse: " + response);
        return false; // SMS operation failed
      }
    }
  }
  
  STATUS_FAIL("SMS send timeout! Last response: " + response);
  return false; // SMS operation failed
}

bool SMSManager::sendModbusAlert(float temperature, float humidity, const String& status, float lowThreshold, float highThreshold) {
  if (!smsEnabled) {
    DEBUG_PRINTLN("SMS disabled, skipping alert.");
    return false;
  }
  
  if (!rtcReady) {
    WARN_PRINTLN("RTC not ready, cannot create timestamp for SMS.");
    return false;
  }
  
  // Create a standard message for temperature alerts
  String message = "Temperature Alert: " + status + "\n";
  message += "Temp: " + String(temperature, 2) + " °C (Low: " + String(lowThreshold, 2) + ", High: " + String(highThreshold, 2) + ")\n";
  message += "Humidity: " + String(humidity, 2) + " %RH\n";
  message += "Time: " + getRTCTimestamp();

  bool anySuccess = false;
  
  // Send to configured phone numbers
  if (smsPhone1.length() > 0) {
    if (sendSMS(smsPhone1, message)) {
      anySuccess = true;
    }
    delay(2000); // Delay between sending two SMS
  }
  
  if (smsPhone2.length() > 0) {
    if (sendSMS(smsPhone2, message)) {
      anySuccess = true;
    }
  }
  
  // Return true if at least one SMS was sent successfully
  return anySuccess;
}

void SMSManager::sendCustomSMS(String message) {
  if (!smsEnabled) {
    DEBUG_PRINTLN("SMS disabled, skipping.");
    return;
  }
  
  // Send to configured phone numbers
  if (smsPhone1.length() > 0) {
    sendSMS(smsPhone1, message);
    delay(2000);
  }
  
  if (smsPhone2.length() > 0) {
    sendSMS(smsPhone2, message);
  }
}

void SMSManager::setSMSPhone1(String phone) {
  smsPhone1 = phone;
}

void SMSManager::setSMSPhone2(String phone) {
  smsPhone2 = phone;
}

void SMSManager::setSMSMessage(String message) {
  smsMessage = message;
}

void SMSManager::setAPNName(String apn) {
  apn_name = apn;
}

void SMSManager::setEnabled(bool enabled) {
  smsEnabled = enabled;
}

void SMSManager::setModemStatus(bool ready, bool network, bool mqtt) {
  modemReady = ready;
  networkRegistered = network;
  mqttConnected = mqtt;
}

String SMSManager::getSMSPhone1() const {
  return smsPhone1;
}

String SMSManager::getSMSPhone2() const {
  return smsPhone2;
}

String SMSManager::getSMSMessage() const {
  return smsMessage;
}

String SMSManager::getAPNName() const {
  return apn_name;
}

bool SMSManager::isEnabled() const {
  return smsEnabled;
}

String SMSManager::getRTCTimestamp() {
  if (!rtcReady || !rtc) return "00:00:00";
  
  DateTime now = rtc->now();
  char timestamp[16];
  sprintf(timestamp, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  return String(timestamp);
}
