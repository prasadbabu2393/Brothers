#ifndef MODBUS_MANAGER_H
#define MODBUS_MANAGER_H

#include <Arduino.h>
#include <Preferences.h>

// Default settings
#define DEFAULT_MODBUS_PERIODICITY 5000 // ms
#define DEFAULT_MODBUS_TEMP_LOW 18.0
#define DEFAULT_MODBUS_TEMP_HIGH 30.0

// NVS keys for storing settings
#define NVS_MODBUS_PERIODICITY "modbus_period"
#define NVS_MODBUS_TEMP_LOW "modbus_low"
#define NVS_MODBUS_TEMP_HIGH "modbus_high"

class ModbusManager {
public:
    ModbusManager(HardwareSerial& serial, uint8_t rxPin, uint8_t txPin, uint8_t deRePin);
    void begin();
    void loop();

    // Configuration
    void loadConfig();
    void saveConfig();

    // Setters
    void setHighThreshold(float threshold);
    void setLowThreshold(float threshold);
    void setPeriodicity(uint32_t periodicity);

    // Getters
    float getHighThreshold() const;
    float getLowThreshold() const;
    uint32_t getPeriodicity() const;
    float getRegister1Value() const;
    float getRegister2Value() const;
    float getTemperature() const { return getRegister1Value(); }
    float getHumidity() const { return getRegister2Value(); }
    bool isNewDataAvailable() const;
    void clearNewDataFlag();

private:
    HardwareSerial& _modbusSerial;
    Preferences _preferences;

    uint8_t _rxPin;
    uint8_t _txPin;
    uint8_t _deRePin;

    // Configuration variables
    float _lowThreshold;
    float _highThreshold;
    uint32_t _periodicity;

    // Data variables
    float _register1Value;
    float _register2Value;
    bool _newDataAvailable;
    
    unsigned long _lastReadTime;

    // Helper methods
    void readRegisters();
    uint16_t calculateCRC(uint8_t *data, int length);
    bool readModbusInputRegisters(uint8_t slaveAddr, uint16_t startAddr, uint16_t numRegs, uint8_t *responseBuffer, int &responseLength);
};

#endif // MODBUS_MANAGER_H
