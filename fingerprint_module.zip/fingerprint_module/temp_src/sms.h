#ifndef SMS_H
#define SMS_H

#include <Arduino.h>
#include "RTClib.h"

class SMSManager {
private:
  HardwareSerial* modemSerial;
  bool modemReady;
  bool networkRegistered;
  RTC_DS3231* rtc;
  bool rtcReady;
  
  // SMS Configuration
  String smsPhone1;
  String smsPhone2;
  String smsMessage;
  bool smsEnabled;
  String apn_name;
  bool mqttConnected;

public:
  SMSManager(RTC_DS3231* rtcPtr, HardwareSerial* modemPtr);
  ~SMSManager();
  
  // SMS operations
  void sendSMS(String number, String message);
  void sendModbusAlert(float temperature, float humidity, const String& status, float lowThreshold, float highThreshold);
  void sendCustomSMS(String message);
  
  // Configuration
  void loadSMSConfig();
  void saveSMSConfig();
  void setSMSPhone1(String phone);
  void setSMSPhone2(String phone);
  void setSMSMessage(String message);
  void setAPNName(String apn);
  void setEnabled(bool enabled);
  void setModemStatus(bool ready, bool network, bool mqtt);
  
  // Getters
  String getSMSPhone1() const;
  String getSMSPhone2() const;
  String getSMSMessage() const;
  String getAPNName() const;
  bool isEnabled() const;
  
  // Utility
  String getRTCTimestamp();
};

#endif // SMS_H
