#include "modbus_manager.h"
#include "debug.h"

// Modbus configuration
#define MODBUS_SLAVE_ID 1
#define MODBUS_START_ADDRESS 0
#define MODBUS_REGISTER_COUNT 2
#define MODBUS_READ_INPUT_REG 0x04
#define MODBUS_TIMEOUT_MS 1000

ModbusManager::ModbusManager(HardwareSerial& serial, uint8_t rxPin, uint8_t txPin, uint8_t deRePin) :
    _modbusSerial(serial),
    _rxPin(rxPin),
    _txPin(txPin),
    _deRePin(deRePin),
    _lowThreshold(DEFAULT_MODBUS_TEMP_LOW),
    _highThreshold(DEFAULT_MODBUS_TEMP_HIGH),
    _periodicity(DEFAULT_MODBUS_PERIODICITY),
    _register1Value(0.0),
    _register2Value(0.0),
    _newDataAvailable(false),
    _lastReadTime(0) {
}

void ModbusManager::begin() {
    INFO_PRINTLN("Initializing Modbus Manager...");

    if (_deRePin != 255) {
        pinMode(_deRePin, OUTPUT);
        digitalWrite(_deRePin, LOW); // default to receive
    }

    _modbusSerial.begin(9600, SERIAL_8N1, _rxPin, _txPin);
    loadConfig();
    INFO_PRINTLN("Modbus Manager Initialized.");
}

void ModbusManager::loadConfig() {
    _preferences.begin("modbus", false);
    _periodicity = _preferences.getULong(NVS_MODBUS_PERIODICITY, DEFAULT_MODBUS_PERIODICITY);

    // Backward compatibility: fall back to the old single-threshold key for high threshold
    float legacyHigh = _preferences.getFloat("modbus_thresh", DEFAULT_MODBUS_TEMP_HIGH);
    _lowThreshold = _preferences.getFloat(NVS_MODBUS_TEMP_LOW, DEFAULT_MODBUS_TEMP_LOW);
    _highThreshold = _preferences.getFloat(NVS_MODBUS_TEMP_HIGH, legacyHigh);
    if (_highThreshold <= _lowThreshold) {
        _lowThreshold = DEFAULT_MODBUS_TEMP_LOW;
        _highThreshold = DEFAULT_MODBUS_TEMP_HIGH;
    }
    
    _preferences.end();
    
    INFO_PRINTF("Loaded Modbus Config: Periodicity=%u ms, Low=%.2f, High=%.2f\n", _periodicity, _lowThreshold, _highThreshold);
}

void ModbusManager::saveConfig() {
    _preferences.begin("modbus", false);
    _preferences.putULong(NVS_MODBUS_PERIODICITY, _periodicity);
    _preferences.putFloat(NVS_MODBUS_TEMP_LOW, _lowThreshold);
    _preferences.putFloat(NVS_MODBUS_TEMP_HIGH, _highThreshold);
    _preferences.end();
    
    INFO_PRINTLN("Saved Modbus Config.");
}

void ModbusManager::setHighThreshold(float threshold) {
    if (threshold > _lowThreshold) {
        _highThreshold = threshold;
    }
}

void ModbusManager::setLowThreshold(float threshold) {
    if (threshold < _highThreshold) {
        _lowThreshold = threshold;
    }
}

void ModbusManager::setPeriodicity(uint32_t periodicity) {
    if (periodicity > 100) { // Set a minimum reasonable periodicity
        _periodicity = periodicity;
    }
}

void ModbusManager::loop() {
    if (millis() - _lastReadTime > _periodicity) {
        _lastReadTime = millis();
        readRegisters();
    }
}

void ModbusManager::readRegisters() {
    uint8_t responseBuffer[20];
    int responseLength = 0;
    
    bool success = readModbusInputRegisters(MODBUS_SLAVE_ID, MODBUS_START_ADDRESS, MODBUS_REGISTER_COUNT, responseBuffer, responseLength);

    if (success && responseLength >= 9 && responseBuffer[1] == MODBUS_READ_INPUT_REG) {
        // Extract temperature (bytes 3-4)
        int16_t rawTemperature = (responseBuffer[3] << 8) | responseBuffer[4];
        _register1Value = rawTemperature / 100.0f; // °C
        
        // Extract humidity (bytes 5-6)
        int16_t rawHumidity = (responseBuffer[5] << 8) | responseBuffer[6];
        _register2Value = rawHumidity / 100.0f;    // %RH

        _newDataAvailable = true;

        DEBUG_PRINTF("Modbus Read OK. Temp: %.2f °C, Hum: %.2f %%\n", _register1Value, _register2Value);
    } else {
        ERROR_PRINTLN("Modbus Read Failed!");
    }
}

float ModbusManager::getHighThreshold() const {
    return _highThreshold;
}

float ModbusManager::getLowThreshold() const {
    return _lowThreshold;
}

uint32_t ModbusManager::getPeriodicity() const {
    return _periodicity;
}

float ModbusManager::getRegister1Value() const {
    return _register1Value;
}

float ModbusManager::getRegister2Value() const {
    return _register2Value;
}

bool ModbusManager::isNewDataAvailable() const {
    return _newDataAvailable;
}

void ModbusManager::clearNewDataFlag() {
    _newDataAvailable = false;
}

// Calculate Modbus CRC16 (same as rs485_temp.ino)
uint16_t ModbusManager::calculateCRC(uint8_t *data, int length) {
    uint16_t crc = 0xFFFF;
    
    for (int i = 0; i < length; i++) {
        crc ^= data[i];
        
        for (int j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    
    return crc;
}

// Read Modbus Input Registers (same logic as rs485_temp.ino)
bool ModbusManager::readModbusInputRegisters(uint8_t slaveAddr, uint16_t startAddr, uint16_t numRegs, uint8_t *responseBuffer, int &responseLength) {
    uint8_t request[8];
    
    // Build Modbus request
    request[0] = slaveAddr;                    // Slave address
    request[1] = MODBUS_READ_INPUT_REG;        // Function code
    request[2] = (startAddr >> 8) & 0xFF;      // Start address high byte
    request[3] = startAddr & 0xFF;             // Start address low byte
    request[4] = (numRegs >> 8) & 0xFF;        // Number of registers high byte
    request[5] = numRegs & 0xFF;               // Number of registers low byte
    
    // Calculate CRC
    uint16_t crc = calculateCRC(request, 6);
    request[6] = crc & 0xFF;                   // CRC low byte
    request[7] = (crc >> 8) & 0xFF;            // CRC high byte
    
    // Clear receive buffer
    while (_modbusSerial.available()) {
        _modbusSerial.read();
    }
    
    // Send request
    if (_deRePin != 255) {
        digitalWrite(_deRePin, HIGH);  // Enable transmit mode
    }
    delayMicroseconds(100);         // Small delay for mode switching
    
    _modbusSerial.write(request, 8);
    _modbusSerial.flush();          // Wait for transmission to complete
    
    delayMicroseconds(100);         // Small delay before switching to receive
    if (_deRePin != 255) {
        digitalWrite(_deRePin, LOW);   // Enable receive mode
    }
    
    // Wait for response
    unsigned long startTime = millis();
    responseLength = 0;
    
    while (millis() - startTime < MODBUS_TIMEOUT_MS) {
        if (_modbusSerial.available()) {
            responseBuffer[responseLength++] = _modbusSerial.read();
            
            // Check if we have enough data for a valid response
            if (responseLength >= 5) {
                // Expected response length: Address(1) + Function(1) + ByteCount(1) + Data(N) + CRC(2)
                uint8_t byteCount = responseBuffer[2];
                int expectedLength = 3 + byteCount + 2;  // 3 header bytes + data + 2 CRC bytes
                
                if (responseLength >= expectedLength) {
                    break;  // Got complete response
                }
            }
            
            if (responseLength >= 20) {
                break;  // Buffer full
            }
        }
    }
    
    // Check if response received
    if (responseLength < 5) {
        DEBUG_PRINTF("No response or timeout. Received bytes: %d\n", responseLength);
        return false;
    }
    
    // Verify CRC
    uint16_t receivedCRC = responseBuffer[responseLength - 2] | (responseBuffer[responseLength - 1] << 8);
    uint16_t calculatedCRC = calculateCRC(responseBuffer, responseLength - 2);
    
    if (receivedCRC != calculatedCRC) {
        DEBUG_PRINTF("CRC Error! Received: 0x%04X, Calculated: 0x%04X\n", receivedCRC, calculatedCRC);
        return false;
    }
    
    // Check for Modbus exception
    if (responseBuffer[1] & 0x80) {
        DEBUG_PRINTF("Modbus Exception: 0x%02X\n", responseBuffer[2]);
        return false;
    }
    
    return true;
}
