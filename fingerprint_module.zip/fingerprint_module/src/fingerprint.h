#ifndef FINGERPRINT_H
#define FINGERPRINT_H

#include <Adafruit_Fingerprint.h>
#include "RTClib.h"
#include "SD.h"

// Fingerprint Pin Definitions
#define FP_TX   9
#define FP_RX   3

// User Data Structure
struct UserData {
  int fpID;
  String name;
  String personID;
};

// Fingerprint Class
class FingerprintManager {
private:
  HardwareSerial* fpSerial;
  Adafruit_Fingerprint* finger;
  bool fpReady;
  String enrollmentStatus;
  RTC_DS3231* rtc;
  bool rtcReady;
  bool sdReady;

  // Async enrollment state
  bool enrollActive;
  int enrollId;
  String enrollName;
  String enrollPersonId;
  uint8_t enrollPhase; // 0 idle, 1 first image, 2 first tz, 3 wait remove, 4 second image, 5 second tz, 6 create model, 7 store, 8 complete
  unsigned long phaseStart;
  unsigned int tries;
  
  // Callback for enrollment complete
  void (*onEnrollmentComplete)(int fpID, String name, String personID);

public:
  FingerprintManager(RTC_DS3231* rtcPtr, bool sdReadyFlag, SPIClass* spiPtr);
  ~FingerprintManager();
  
  // Initialization
  void initialize();
  
  // Fingerprint operations
  bool checkFingerprintOnStartup();
  bool enrollNewFingerprint(int id, String name, String personID);
  bool startEnrollment(int id, String name, String personID);
  void processEnrollment();
  bool isEnrollmentActive() const;
  int scanFingerprint(); // Returns finger ID if found, -1 if not found, -2 if no finger/error
  void setEnrollmentCompleteCallback(void (*callback)(int, String, String));
  
  // User data management
  void saveUserData(int fpID, String name, String personID);
  UserData getUserData(int fpID);
  
  // Getters
  bool isReady() const;
  String getEnrollmentStatus() const;
  int getTemplateCount();
  bool loadModel(int id);
  bool deleteModel(int id);
  bool emptyDatabase();
  uint8_t getFingerID() const;
  uint16_t getConfidence() const;
};

#endif // FINGERPRINT_H
