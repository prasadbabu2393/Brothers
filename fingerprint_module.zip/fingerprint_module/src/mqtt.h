#ifndef MQTT_H
#define MQTT_H

#include <Arduino.h>
#include "RTClib.h"

// AWS MQTT Configuration
#define MQTT_SERVER "13.203.2.58"
#define MQTT_PORT 1883
#define MQTT_CLIENT_ID "fingerprint_01"
#define MQTT_TOPIC "home/fingerprint"

// 4G Modem Pin Definitions
#define MODEM_TX 16
#define MODEM_RX 17
#define MODEM_KEY 38

// MQTT Timing Configuration
#define MQTT_PUBLISH_INTERVAL 2000
#define CONNECTION_CHECK_INTERVAL 3000
#define KEEPALIVE_INTERVAL 5000
#define MAX_CONNECTION_RETRIES 3

class MQTTManager {
private:
  HardwareSerial* modemSerial;
  bool modemReady;
  bool gprsConnected;
  bool mqttConnected;
  bool simReady;
  bool networkRegistered;
  int signalQuality;
  String simProvider;
  String modemIP;
  String apn_name;
  RTC_DS3231* rtc;
  bool rtcReady;
  
  // Timing
  unsigned long lastMqttPublish;
  unsigned long lastConnectionCheck;
  unsigned long lastKeepalive;
  unsigned int connectionRetries;

public:
  MQTTManager(RTC_DS3231* rtcPtr, HardwareSerial* serialPtr);
  ~MQTTManager();
  
  // Modem management
  void initializeModem();
  void powerOnModem();
  void setupModem();
  bool checkModemStatus();
  bool checkSIMStatus();
  bool checkNetworkRegistration();
  int getSignalQuality();
  String detectSIMProvider();
  void autoConfigureAPN();
  void checkSIMBalance();
  String sendATCommand(String command, unsigned long timeout);
  
  // GPRS/PDP
  void activatePDPContext();
  bool checkGPRSStatus();
  
  // MQTT operations
  void connectToMQTT();
  void publishFingerprintEvent(String eventType, int fpID, String name, String personID, String authStatus);
  void sendKeepalive();
  void checkMQTTConnectionStatus();
  
  // Utility
  String getRTCTimestamp();
  String getRTCDate();
  String readResponse(unsigned long timeout);
  void displayModemStatus();
  
  // Getters
  bool isModemReady() const;
  bool isGPRSConnected() const;
  bool isMQTTConnected() const;
  bool isSIMReady() const;
  bool isNetworkRegistered() const;
  int getSignalQualityValue() const;
  String getSIMProvider() const;
  String getModemIP() const;
  String getAPN() const;
  void setAPN(String newAPN);
};

#endif // MQTT_H
