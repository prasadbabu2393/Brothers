#include "fingerprint.h"
#include "debug.h"
#include <Preferences.h>

// Global preferences for user data storage
static Preferences preferences;

FingerprintManager::FingerprintManager(RTC_DS3231* rtcPtr, bool sdReadyFlag, SPIClass* spiPtr)
  : rtc(rtcPtr), rtcReady(rtcPtr != nullptr), sdReady(sdReadyFlag) {
  fpSerial = new HardwareSerial(1);
  finger = new Adafruit_Fingerprint(fpSerial);
  fpReady = false;
  enrollmentStatus = "";
  enrollActive = false;
  enrollPhase = 0;
  enrollId = 0;
  phaseStart = 0;
  tries = 0;
  onEnrollmentComplete = nullptr;
}

FingerprintManager::~FingerprintManager() {
  if (fpSerial) delete fpSerial;
  if (finger) delete finger;
}

void FingerprintManager::initialize() {
  DEBUG_PRINTLN("═══════════════════════════════════════");
  DEBUG_PRINTLN("Fingerprint Sensor Initialization");
  DEBUG_PRINTLN("═══════════════════════════════════════");
  
  fpSerial->begin(57600, SERIAL_8N1, FP_RX, FP_TX);
  delay(10);
  
  if (finger->verifyPassword()) {
    fpReady = true;
    STATUS_OK("Fingerprint Sensor OK");
    finger->getTemplateCount();
    DEBUG_PRINTF("Stored: %d / %d\n", finger->templateCount, finger->capacity);
    enrollmentStatus = "READY:Fingerprint sensor ready";
  } else {
    fpReady = false;
    STATUS_FAIL("Fingerprint Sensor Failed");
    INFO_PRINTLN("Check wiring:");
    DEBUG_PRINTLN("  Sensor RX → ESP32 GPIO 9");
    DEBUG_PRINTLN("  Sensor TX → ESP32 GPIO 3");
    enrollmentStatus = "ERROR:Fingerprint sensor failed";
  }
  DEBUG_PRINTLN("");
}

bool FingerprintManager::isReady() const {
  return fpReady;
}

String FingerprintManager::getEnrollmentStatus() const {
  return enrollmentStatus;
}

int FingerprintManager::getTemplateCount() {
  if (!fpReady) return 0;
  finger->getTemplateCount();
  return finger->templateCount;
}

bool FingerprintManager::loadModel(int id) {
  if (!fpReady) return false;
  return (finger->loadModel(id) == FINGERPRINT_OK);
}

bool FingerprintManager::deleteModel(int id) {
  if (!fpReady) return false;
  return (finger->deleteModel(id) == FINGERPRINT_OK);
}

bool FingerprintManager::emptyDatabase() {
  if (!fpReady) return false;
  return (finger->emptyDatabase() == FINGERPRINT_OK);
}

uint8_t FingerprintManager::getFingerID() const {
  return finger->fingerID;
}

uint16_t FingerprintManager::getConfidence() const {
  return finger->confidence;
}

bool FingerprintManager::checkFingerprintOnStartup() {
  if (!fpReady) {
    STATUS_FAIL("Sensor not ready");
    enrollmentStatus = "ERROR:Sensor not ready";
    return false;
  }
  
  INFO_PRINTLN("\n👆 Place finger on sensor within 10 seconds...\n");
  enrollmentStatus = "STARTUP:Place finger for authentication";
  
  unsigned long startTime = millis();
  while (millis() - startTime < 10000) {
    int result = finger->getImage();
    
    if (result == FINGERPRINT_OK) {
      DEBUG_PRINTLN("📸 Image captured");
      enrollmentStatus = "STARTUP:Processing fingerprint";
      
      result = finger->image2Tz();
      if (result != FINGERPRINT_OK) continue;
      
      result = finger->fingerSearch();
      if (result == FINGERPRINT_OK) {
        INFO_PRINTF("✅ Match Found - ID: %d, Confidence: %d\n", 
                     finger->fingerID, finger->confidence);
        
        UserData user = getUserData(finger->fingerID);
        enrollmentStatus = "SUCCESS:Access granted";
        return true;
      } else if (result == FINGERPRINT_NOTFOUND) {
        STATUS_FAIL("Fingerprint not registered");
        enrollmentStatus = "ERROR:Fingerprint not registered";
        return false;
      }
    }
    
    if ((millis() - startTime) % 1000 == 0) {
      DEBUG_PRINT(".");
    }
    delay(10);
  }
  
  WARN_PRINTLN("Timeout - No finger detected");
  enrollmentStatus = "ERROR:Timeout - No finger detected";
  return false;
}

bool FingerprintManager::enrollNewFingerprint(int id, String name, String personID) {
  if (!fpReady) {
    enrollmentStatus = "ERROR:Fingerprint sensor not ready";
    return false;
  }
  
  INFO_PRINTF("\n📝 Enrolling ID #%d: %s (%s)\n", id, name.c_str(), personID.c_str());
  enrollmentStatus = "STEP:Place your finger on the sensor";
  
  // First scan
  int p = -1;
  int timeout = 0;
  while (p != FINGERPRINT_OK && timeout < 200) {
    p = finger->getImage();
    delay(10);
    timeout++;
  }
  
  if (p != FINGERPRINT_OK) {
    enrollmentStatus = "ERROR:Timeout - No finger detected";
    return false;
  }
  
  enrollmentStatus = "SUCCESS:Image 1 captured";
  delay(500);
  
  p = finger->image2Tz(1);
  if (p != FINGERPRINT_OK) {
    enrollmentStatus = "ERROR:Image conversion failed";
    return false;
  }
  
  enrollmentStatus = "STEP:Remove your finger";
  delay(500);
  
  while (finger->getImage() != FINGERPRINT_NOFINGER) {
    delay(10);
  }
  
  enrollmentStatus = "STEP:Place the SAME finger again";
  delay(500);
  
  // Second scan
  p = -1;
  timeout = 0;
  while (p != FINGERPRINT_OK && timeout < 200) {
    p = finger->getImage();
    delay(10);
    timeout++;
  }
  
  if (p != FINGERPRINT_OK) {
    enrollmentStatus = "ERROR:Timeout - No finger detected";
    return false;
  }
  
  enrollmentStatus = "SUCCESS:Image 2 captured - Processing";
  delay(500);
  
  p = finger->image2Tz(2);
  if (p != FINGERPRINT_OK) {
    enrollmentStatus = "ERROR:Image conversion failed";
    return false;
  }
  
  p = finger->createModel();
  if (p == FINGERPRINT_ENROLLMISMATCH) {
    enrollmentStatus = "ERROR:Fingerprints don't match - Try again";
    return false;
  } else if (p != FINGERPRINT_OK) {
    enrollmentStatus = "ERROR:Model creation failed";
    return false;
  }
  
  p = finger->storeModel(id);
  if (p != FINGERPRINT_OK) {
    enrollmentStatus = "ERROR:Storage failed";
    return false;
  }
  
  enrollmentStatus = "COMPLETE:Enrollment successful!";
  
  saveUserData(id, name, "");
  
  return true;
}

bool FingerprintManager::startEnrollment(int id, String name, String personID) {
  if (!fpReady) {
    enrollmentStatus = "ERROR:Fingerprint sensor not ready";
    return false;
  }
  if (enrollActive) {
    enrollmentStatus = "ERROR:Enrollment already in progress";
    return false;
  }
  enrollActive = true;
  enrollId = id;
  enrollName = name;
  enrollPersonId = personID;
  enrollPhase = 1; // first image
  phaseStart = millis();
  tries = 0;
  INFO_PRINTF("\n📝 Enrolling ID #%d: %s (%s)\n", id, name.c_str(), personID.c_str());
  enrollmentStatus = "STEP:Place your finger on the sensor";
  return true;
}

void FingerprintManager::processEnrollment() {
  if (!enrollActive || !fpReady) return;

  // Debug: Print current phase
  static int lastPhase = -1;
  if (enrollPhase != lastPhase) {
    Serial.printf("[ENROLL] Entering Phase %d\n", enrollPhase);
    lastPhase = enrollPhase;
  }

  switch (enrollPhase) {
    case 1: { // first image capture - WAIT for finger placement
      int p = finger->getImage();
      if (p == FINGERPRINT_OK) {
        enrollmentStatus = "SUCCESS:Image 1 captured";
        STATUS_OK("First fingerprint captured!");
        enrollPhase = 2;
        phaseStart = millis();
      } else if (p == FINGERPRINT_NOFINGER) {
        // Still waiting for finger - don't timeout too quickly
        if (millis() - phaseStart > 30000) { // 30s timeout
          enrollmentStatus = "ERROR:Timeout - No finger detected";
          enrollPhase = 9; // error hold
          phaseStart = millis();
        }
      } else {
        // Other error
        if (millis() - phaseStart > 30000) {
          enrollmentStatus = "ERROR:Sensor error - Try again";
          enrollPhase = 9;
          phaseStart = millis();
        }
      }
      break;
    }
    case 2: { // convert first image
      int p = finger->image2Tz(1);
      if (p == FINGERPRINT_OK) {
        enrollmentStatus = "STEP:Remove your finger";
        STATUS_OK("Please remove your finger");
        enrollPhase = 3;
        phaseStart = millis();
      } else {
        enrollmentStatus = "ERROR:Image conversion failed";
        enrollPhase = 9;
        phaseStart = millis();
      }
      break;
    }
    case 3: { // wait finger removed - WAIT until finger is actually removed
      int p = finger->getImage();
      if (p == FINGERPRINT_NOFINGER) {
        enrollmentStatus = "STEP:Place the SAME finger again";
        STATUS_OK("Now place the same finger again");
        enrollPhase = 4;
        phaseStart = millis();
      } else if (millis() - phaseStart > 15000) { // 15s timeout
        enrollmentStatus = "ERROR:Please remove finger and try again";
        enrollPhase = 9;
        phaseStart = millis();
      }
      break;
    }
    case 4: { // second image capture - WAIT for finger placement
      int p = finger->getImage();
      if (p == FINGERPRINT_OK) {
        enrollmentStatus = "SUCCESS:Image 2 captured - Processing";
        STATUS_OK("Second fingerprint captured!");
        enrollPhase = 5;
        phaseStart = millis();
      } else if (p == FINGERPRINT_NOFINGER) {
        // Still waiting for finger
        if (millis() - phaseStart > 30000) { // 30s timeout
          enrollmentStatus = "ERROR:Timeout - No finger detected";
          enrollPhase = 9;
          phaseStart = millis();
        }
      } else {
        // Other error
        if (millis() - phaseStart > 30000) {
          enrollmentStatus = "ERROR:Sensor error - Try again";
          enrollPhase = 9;
          phaseStart = millis();
        }
      }
      break;
    }
    case 5: { // convert second image
      Serial.println("[ENROLL] Phase 5: Converting second image...");
      int p = finger->image2Tz(2);
      Serial.printf("[ENROLL] image2Tz(2) result: %d\n", p);
      if (p == FINGERPRINT_OK) {
        enrollmentStatus = "PROGRESS:Creating fingerprint model...";
        STATUS_OK("Converting second image...");
        enrollPhase = 6; // create model
        phaseStart = millis();
      } else {
        enrollmentStatus = "ERROR:Image conversion failed (code: " + String(p) + ")";
        STATUS_FAIL("Image conversion failed");
        enrollPhase = 9;
        phaseStart = millis();
      }
      break;
    }
    case 6: { // create model
      Serial.println("[ENROLL] Phase 6: Creating fingerprint model...");
      int p = finger->createModel();
      Serial.printf("[ENROLL] createModel() result: %d\n", p);
      if (p == FINGERPRINT_OK) {
        enrollmentStatus = "PROGRESS:Saving fingerprint...";
        STATUS_OK("Model created successfully!");
        enrollPhase = 7; // store
        phaseStart = millis();
      } else if (p == FINGERPRINT_ENROLLMISMATCH) {
        enrollmentStatus = "ERROR:Fingerprints don't match - Try again";
        STATUS_FAIL("Fingerprints don't match");
        enrollPhase = 9;
        phaseStart = millis();
      } else {
        enrollmentStatus = "ERROR:Model creation failed (code: " + String(p) + ")";
        STATUS_FAIL("Model creation failed");
        enrollPhase = 9;
        phaseStart = millis();
      }
      break;
    }
    case 7: { // store model
      Serial.printf("[ENROLL] Phase 7: Storing model ID %d...\n", enrollId);
      int p = finger->storeModel(enrollId);
      Serial.printf("[ENROLL] storeModel(%d) result: %d\n", enrollId, p);
      if (p == FINGERPRINT_OK) {
        saveUserData(enrollId, enrollName, enrollPersonId);
        enrollmentStatus = "COMPLETE:Enrollment successful!";
        STATUS_OK("✅ Fingerprint enrolled successfully!");
        INFO_PRINTF("✅ Saved: ID #%d - %s (%s)\n", enrollId, enrollName.c_str(), enrollPersonId.c_str());
        enrollPhase = 8;
        phaseStart = millis(); // Track when success message was set
        
        // Call callback to send SMS and MQTT
        if (onEnrollmentComplete) {
          onEnrollmentComplete(enrollId, enrollName, enrollPersonId);
        }
      } else {
        enrollmentStatus = "ERROR:Storage failed (code: " + String(p) + ")";
        STATUS_FAIL("Storage failed");
        // Hold error state and keep enrollment active to avoid scanning
        enrollPhase = 9;
        phaseStart = millis();
      }
      break;
    }
    case 8: { // keep success message visible for 5 seconds
      if (millis() - phaseStart > 5000) {
        enrollActive = false;
        enrollmentStatus = "READY:Fingerprint sensor ready";
      }
      break;
    }
    case 9: { // hold error message visible for 5 seconds then reset
      if (millis() - phaseStart > 5000) {
        enrollActive = false;
        enrollmentStatus = "READY:Fingerprint sensor ready";
      }
      break;
    }
    default:
      enrollActive = false;
      break;
  }
}

bool FingerprintManager::isEnrollmentActive() const {
  return enrollActive;
}

void FingerprintManager::setEnrollmentCompleteCallback(void (*callback)(int, String, String)) {
  onEnrollmentComplete = callback;
}

int FingerprintManager::scanFingerprint() {
  if (!fpReady) return -2;
  
  int result = finger->getImage();
  if (result != FINGERPRINT_OK) {
    return -2; // No finger or error
  }
  
  result = finger->image2Tz();
  if (result != FINGERPRINT_OK) {
    return -2; // Conversion error
  }
  
  result = finger->fingerSearch();
  if (result == FINGERPRINT_OK) {
    return finger->fingerID; // Match found
  } else if (result == FINGERPRINT_NOTFOUND) {
    return -1; // No match
  }
  
  return -2; // Other error
}

void FingerprintManager::saveUserData(int fpID, String name, String personID) {
  String key = "user" + String(fpID);
  preferences.begin("users", false);
  preferences.putString(key.c_str(), name);
  preferences.end();
  
  DEBUG_PRINTLN("💾 Employee name saved to flash: ID" + String(fpID) + " = " + name);
}

UserData FingerprintManager::getUserData(int fpID) {
  UserData user = {fpID, "Unknown", "N/A"};
  
  String key = "user" + String(fpID);
  preferences.begin("users", true);
  String name = preferences.getString(key.c_str(), "Unknown");
  preferences.end();
  
  user.name = name;
  user.personID = String(fpID);
  
  return user;
}
