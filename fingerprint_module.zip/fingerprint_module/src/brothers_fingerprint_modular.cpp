/*
 * ESP32-S3 Fingerprint Access Control System (Modular Version)
 * 
 * Features:
 * - Fingerprint-based relay control (GPIO 4, 5)
  // Add scanning state and registration mode
  json += "\"scanning\":" + String((!relayActive && fingerprintMgr->isReady() && !mscMode && !fingerprintMgr->isEnrollmentActive() && !registrationMode) ? "true" : "false") + ",";
  json += "\"registrationMode\":" + String(registrationMode ? "true" : "false");
 * - WiFi SoftAP for configuration
 * - OTA firmware updates
 * - Modular architecture with reusable classes
 * 
 * Hardware Connections:
 * 
  // Add scanning state and registration mode
  json += "\"scanning\":" + String((!relayActive && fingerprintMgr->isReady() && !mscMode && !fingerprintMgr->isEnrollmentActive() && !registrationMode) ? "true" : "false") + ",";
  json += "\"registrationMode\":" + String(registrationMode ? "true" : "false");
 * 
 * RTC DS3231 (I2C):
 * - SDA: GPIO 11, SCL: GPIO 10
 * 
 * Fingerprint R307 (UART):
 * - TX: GPIO 9, RX: GPIO 3
 * 
 * Relays:
 * - Relay 1: GPIO 4
 * - Relay 2: GPIO 5
 * 
 * USB Detection:
 * - VSTAT: GPIO 8
 */

#include "FS.h"
#include "SD.h"
#include "SPI.h"
#include "Wire.h"
#include "RTClib.h"
#include "USB.h"
#include "USBMSC.h"
#include <WiFi.h>
#include <WebServer.h>
#include <Update.h>
#include <ArduinoJson.h>
#include <Preferences.h>

// ==================== DEBUG CONTROL ====================
#define DEBUG_MODE 0
#include "debug.h"

// Include modular classes
#include "fingerprint.h"
#include "mqtt.h"
#include "sms.h"
#include "sdcard.h"
#include "usbmsc.h"

 
#define SD_MISO 39
#define SD_SCK  40
#define SD_MOSI 41
#define SD_CS   42
#define RTC_SDA 11
#define RTC_SCL 10
#define RELAY1  47
#define RELAY2  21
#define USB_VSTAT 8
#define IO 12 //to disable relay

// WiFi AP Settings
const char* AP_SSID = "AccessControl01";
const char* AP_PASS = "12345678";

// Objects
RTC_DS3231 rtc;
HardwareSerial modemSerial(2);
WebServer server(80);
Preferences preferences;

// Modular class instances
FingerprintManager* fingerprintMgr = nullptr;
MQTTManager* mqttMgr = nullptr;
SMSManager* smsMgr = nullptr;
SDCardManager* sdcardMgr = nullptr;
USBMSCManager* usbmscMgr = nullptr;

// Global State
bool sdReady = false;
bool rtcReady = false;
bool relayActive = false;
bool mscMode = false;
bool apMode = false;
bool registrationMode = false; // default NORMAL mode on boot
String currentLogFile = "";
unsigned long relayOnSince = 0;
const unsigned long RELAY_ON_TIMEOUT_MS =  60UL * 1000UL; // 1 minute
const unsigned long RELAYON = 240UL * 60UL * 1000UL; // 15 minutes

// Modem State
bool modemReady = false;
bool simPresent = false;
bool networkRegistered = false;
int signalQuality = 0;
bool gprsConnected = false;
bool mqttConnected = false;
String modemIP = "";
String simProvider = "Unknown";
String simBalance = "Checking...";

// ==================== FUNCTION DECLARATIONS ====================
void initializeRTC();
void initializeModules();
void createTodayLogFile();
void logAccess(int fpID, bool success);
void activateRelays();
void deactivateRelays();
bool ensureMQTTConnection();
void enableMSC();
void disableMSC();
void startSoftAP();
void stopSoftAP();
void setupWebServer();
String getRTCTimestamp();
String getRTCDate();

// Callback for enrollment complete
void onFingerprintEnrolled(int fpID, String name, String personID);

// ==================== SETUP ====================
void setup() {
  Serial.begin(115200);
  delay(100);
  
  pinMode(USB_VSTAT, INPUT);
  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  digitalWrite(RELAY1, LOW);
  digitalWrite(RELAY2, LOW);
  
  Serial.println("\n╔═══════════════════════════════════════╗");
  Serial.println("║  Fingerprint Access Control System   ║");
  Serial.println("║  Modular Architecture Version        ║");
  Serial.println("╚═══════════════════════════════════════╝\n");
  
  initializeRTC();
  initializeModules();
  smsMgr->loadSMSConfig();
  
  // Activate GPRS and connect to MQTT
  if (modemReady && simPresent && networkRegistered) {
    Serial.println("\n[5/5] Setting up MQTT connection...");
    mqttMgr->activatePDPContext();
    if (gprsConnected) {
      mqttMgr->connectToMQTT();
      mqttConnected = mqttMgr->isMQTTConnected();
    }
  }
  
  // Check for USB connection
  if (digitalRead(USB_VSTAT)) {
    Serial.println("🔌 USB Connected - Starting Mass Storage Mode");
    enableMSC();
  } else {
    // Start WiFi AP Mode directly
    startSoftAP();
  }
}

// ==================== MAIN LOOP ====================
void loop() {
  // Check USB status
  static bool lastUSB = false;
  bool currentUSB = digitalRead(USB_VSTAT);
  
  if (currentUSB != lastUSB) {
    lastUSB = currentUSB;
    if (currentUSB) {
      Serial.println("\n🔌 USB Connected");
      if (apMode) {
        stopSoftAP();
      }
      enableMSC();
    } else {
      Serial.println("\n🔌 USB Disconnected");
      disableMSC();
      if (!apMode) {
        startSoftAP();
      }
    }
  }
  
  // Handle web server
  if (apMode && !mscMode) {
    server.handleClient();
  }
  
  // Drive async fingerprint enrollment state machine
  if (fingerprintMgr) {
    fingerprintMgr->processEnrollment();
  }

  // Auto-deactivate relays after timeout
  if (relayActive && relayOnSince > 0 && (millis() - relayOnSince) >= RELAYON) {
    deactivateRelays();
    Serial.println("⏱️ Relay timeout reached - auto deactivated");
  }
  
  // MQTT Status monitoring and keepalive
  static unsigned long lastConnectionCheck = 0;
  const unsigned long connectionCheckInterval = 3000;
  
  if (millis() - lastConnectionCheck >= connectionCheckInterval) {
    lastConnectionCheck = millis();
    
  }
  
  static unsigned long lastKeepalive = 0;
  const unsigned long keepaliveInterval = 5000;
  
  // CONTINUOUS FINGERPRINT SCANNING WHEN RELAYS ARE OFF, NOT ENROLLING, NOT IN REGISTRATION MODE
  if ( fingerprintMgr->isReady() && !mscMode && !registrationMode) {
    // ONLY scan if NOT enrolling
    if (!fingerprintMgr->isEnrollmentActive()) {
      static unsigned long lastCheck = 0;
      if (millis() - lastCheck > 500) {
        lastCheck = millis();
        
        // Get user count
        int userCount = fingerprintMgr->getTemplateCount();
        
        // Try to scan fingerprint
        int result = fingerprintMgr->scanFingerprint();
        
        // If finger detected (result != -2 means finger was on sensor)
        if (result >= 0) {
        // Match found - AUTHORIZED
        DEBUG_PRINTF("\n✅ Fingerprint Match - ID: %d\n", result);
        UserData user = fingerprintMgr->getUserData(result);
        if(relayActive && relayOnSince > 0 && (millis() - relayOnSince) >= RELAY_ON_TIMEOUT_MS){
          deactivateRelays();
        }
        else{
          activateRelays();
        }
        logAccess(result, true);
        
        // Update modem status before SMS (fresh query from modem manager)
        smsMgr->setModemStatus(mqttMgr->isModemReady(), mqttMgr->isNetworkRegistered(), mqttMgr->isMQTTConnected());
        smsMgr->sendAccessSMS(result, user.name, user.personID);
        
        if (ensureMQTTConnection()) {
          mqttMgr->publishFingerprintEvent("scan", result, user.name, user.personID, "GRANTED");
        }
        
        DEBUG_PRINTLN("💡 Relays will auto-off after 15 minutes\n");
      } else if (result == -1) {
        // Not found - UNAUTHORIZED
        DEBUG_PRINTLN("\n❌ UNAUTHORIZED Fingerprint - Not Registered");
        logAccess(0, false);
        
        // Check if NO users are registered
        if (userCount == 0) {
          INFO_PRINTLN("⚠️ NO USERS REGISTERED - Fingerprint detected but database is empty!");
          
          // Send SMS alert
          smsMgr->setModemStatus(mqttMgr->isModemReady(), mqttMgr->isNetworkRegistered(), mqttMgr->isMQTTConnected());
          String noUserMsg = "ALERT: Fingerprint detected but NO USERS REGISTERED!\n";
          noUserMsg += "Time: " + getRTCTimestamp() + "\n";
          noUserMsg += "Please register users first.";
          
          if (smsMgr->getSMSPhone1().length() > 0) {
            smsMgr->sendSMS(smsMgr->getSMSPhone1(), noUserMsg);
            delay(2000);
          }
          if (smsMgr->getSMSPhone2().length() > 0) {
            smsMgr->sendSMS(smsMgr->getSMSPhone2(), noUserMsg);
          }
          
          // Send to AWS
          if (ensureMQTTConnection()) {
            mqttMgr->publishFingerprintEvent("alert", 0, "No Users Registered", "N/A", "NO_USERS");
          }
        } else {
          // Users exist but this fingerprint not registered
          smsMgr->setModemStatus(mqttMgr->isModemReady(), mqttMgr->isNetworkRegistered(), mqttMgr->isMQTTConnected());
          smsMgr->sendUnauthorizedSMS();
          
          // Publish to AWS
          if (ensureMQTTConnection()) {
            mqttMgr->publishFingerprintEvent("scan", 0, "Unknown", "N/A", "DENIED");
          }
        }
      }
      // result == -2 means no finger detected, do nothing
    }
  }
  }
  delay(10);
}

// ==================== INITIALIZATION ====================

void initializeRTC() {
  Serial.println("═══════════════════════════════════════");
  Serial.println("RTC Initialization");
  Serial.println("═══════════════════════════════════════");
  
  Wire.begin(RTC_SDA, RTC_SCL);
  
  if (rtc.begin(&Wire)) {
    rtcReady = true;
    Serial.println("✅ RTC OK");
    
    if (rtc.lostPower()) {
      Serial.println("⚠️  Setting default time");
      rtc.adjust(DateTime(2025, 1, 1, 0, 0, 0));
    }
    
    DateTime now = rtc.now();
    Serial.printf("Time: %04d-%02d-%02d %02d:%02d:%02d\n",
                  now.year(), now.month(), now.day(),
                  now.hour(), now.minute(), now.second());
  } else {
    rtcReady = false;
    Serial.println("❌ RTC Failed");
  }
  Serial.println();
}

void initializeModules() {
  // Initialize SD Card Manager
  sdcardMgr = new SDCardManager(SD_MISO, SD_SCK, SD_MOSI, SD_CS);
  sdcardMgr->initialize();
  sdReady = sdcardMgr->isReady();
  
  // Create users.json if needed
  if (sdReady && !sdcardMgr->fileExists("/users.json")) {
    sdcardMgr->createFile("/users.json", "[]");
    Serial.println("📝 Created users.json");
  }
  
  createTodayLogFile();
  
  // Initialize USB MSC Manager
  usbmscMgr = new USBMSCManager();
  
  // Initialize Fingerprint Manager
  fingerprintMgr = new FingerprintManager(&rtc, sdReady, nullptr);
  fingerprintMgr->initialize();
  
  // Set enrollment callback for SMS and MQTT
  fingerprintMgr->setEnrollmentCompleteCallback(onFingerprintEnrolled);
  
  // Initialize MQTT Manager with shared modemSerial
  mqttMgr = new MQTTManager(&rtc, &modemSerial);
  mqttMgr->initializeModem();
  modemReady = mqttMgr->isModemReady();
  gprsConnected = mqttMgr->isGPRSConnected();
  simPresent = mqttMgr->isSIMReady();
  networkRegistered = mqttMgr->isNetworkRegistered();
  
  // Initialize SMS Manager with shared modemSerial
  smsMgr = new SMSManager(&rtc, &modemSerial);
  smsMgr->setModemStatus(modemReady, networkRegistered, false);
}

// ==================== LOGGING ====================

static unsigned long logEntryCount = 0;

void createTodayLogFile() {
  if (!sdcardMgr) return;
  
  if (!sdReady) {
    sdcardMgr->reinitialize();
    sdReady = sdcardMgr->isReady();
    if (!sdReady) return;
  }
  
  if (!rtcReady) {
    if (rtc.begin(&Wire)) {
      rtcReady = true;
    } else {
      return;
    }
  }
  
  DateTime now = rtc.now();
  char filename[32];
  sprintf(filename, "/%04d-%02d-%02d.csv", now.year(), now.month(), now.day());
  currentLogFile = String(filename);
  
  if (!sdcardMgr->fileExists(filename)) {
    File f = sdcardMgr->openFile(filename, "write");
    if (f) {
      f.println("S.No,Employee_Name,Time,Auth_Status");
      f.close();
      Serial.printf("📝 Created log: %s\n", filename);
      logEntryCount = 0;
    } else {
      sdcardMgr->createFile(filename, "S.No,Employee_Name,Time,Auth_Status");
      logEntryCount = 0;
    }
  }
}

void logAccess(int fpID, bool success) {
  if (!sdcardMgr) return;
  
  if (!sdReady) {
    sdcardMgr->reinitialize();
    sdReady = sdcardMgr->isReady();
    if (!sdReady) return;
  }
  
  if (!rtcReady) {
    if (rtc.begin(&Wire)) {
      rtcReady = true;
    } else {
      return;
    }
  }
  
  createTodayLogFile();
  
  if (currentLogFile.length() == 0) return;
  
  logEntryCount++;
  
  DateTime now = rtc.now();
  UserData user = fingerprintMgr->getUserData(fpID);
  
  File f = sdcardMgr->openFile(currentLogFile.c_str(), "append");
  if (!f) {
    f = sdcardMgr->openFile(currentLogFile.c_str(), "write");
    if (f) {
      f.println("S.No,Employee_Name,Time,Auth_Status");
    }
  }
  
  if (f) {
    char timestamp[32];
    sprintf(timestamp, "%02d:%02d:%02d",
            now.hour(), now.minute(), now.second());
    
    f.printf("%lu,%s,%s,%s\n",
             logEntryCount,
             user.name.c_str(),
             timestamp,
             success ? "GRANTED" : "DENIED");
    f.close();
    
    Serial.printf("📝 Logged [%lu]: %s - %s - %s\n", 
                  logEntryCount, user.name.c_str(), timestamp,
                  success ? "GRANTED" : "DENIED");
  }
}

// Attempt to bring MQTT back online before publishing events
bool ensureMQTTConnection() {
  if (!mqttMgr) return false;
  if (mqttConnected) return true;
  
  Serial.println("🔄 MQTT not connected - reconnecting...");
  mqttMgr->activatePDPContext();
  gprsConnected = mqttMgr->isGPRSConnected();
  mqttMgr->connectToMQTT();
  mqttConnected = mqttMgr->isMQTTConnected();
  
  if (!mqttConnected) {
    Serial.println("⚠️ MQTT reconnect failed");
  }
  return mqttConnected;
}

// ==================== RELAY CONTROL ====================

void activateRelays() {
  digitalWrite(RELAY1, HIGH);
  digitalWrite(RELAY2, HIGH);
  relayActive = true;
  relayOnSince = millis();
  Serial.println("🔓 Relays ACTIVATED");
}

void deactivateRelays() {
  digitalWrite(RELAY1, LOW);
  digitalWrite(RELAY2, LOW);
  relayActive = false;
  Serial.println("🔒 Relays DEACTIVATED");
}

// ==================== USB MASS STORAGE ====================

void enableMSC() {
  if (!sdReady || mscMode || !sdcardMgr || !usbmscMgr) return;
  
  uint64_t cardSize = sdcardMgr->getCardSize();
  if (cardSize == 0) {
    Serial.println("⚠️ Cannot enable MSC - SD card size is 0");
    return;
  }
  
  // Keep SD mounted but avoid filesystem operations while MSC is active
  // This matches the working reference implementation
  Serial.println("💾 Enabling USB Mass Storage...");
  
  usbmscMgr->enable(cardSize);
  
  mscMode = true;
  Serial.println("💾 USB Mass Storage ENABLED - SD card accessible from PC");
  Serial.println("⚠️  Do not unplug while transferring files!");
}

void disableMSC() {
  if (!mscMode || !sdcardMgr || !usbmscMgr) return;
  
  usbmscMgr->disable();
  mscMode = false;
  
  Serial.println("💾 USB Mass Storage DISABLED");
  
  // Reinitialize SD filesystem after USB MSC release (matches reference)
  delay(500);
  sdcardMgr->endSD();
  delay(100);
  sdcardMgr->reinitialize();
}

// ==================== WIFI SOFT AP ====================

void startSoftAP() {
  Serial.println("\n═══════════════════════════════════════");
  Serial.println("Starting WiFi Access Point");
  Serial.println("═══════════════════════════════════════");
  
  WiFi.softAP(AP_SSID, AP_PASS);
  IPAddress IP = WiFi.softAPIP();
  
  Serial.printf("SSID: %s\n", AP_SSID);
  Serial.printf("Password: %s\n", AP_PASS);
  Serial.printf("IP: %s\n", IP.toString().c_str());
  Serial.println("═══════════════════════════════════════\n");
  
  setupWebServer();
  server.begin();
  apMode = true;
}

void stopSoftAP() {
  if (!apMode) return;
  
  server.stop();
  WiFi.softAPdisconnect(true);
  apMode = false;
  Serial.println("📡 WiFi AP Stopped");
}

// ==================== UTILITY FUNCTIONS ====================

String getRTCTimestamp() {
  if (!rtcReady) return "00:00:00";
  
  DateTime now = rtc.now();
  char timestamp[16];
  sprintf(timestamp, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  return String(timestamp);
}

String getRTCDate() {
  if (!rtcReady) return "0000-00-00";
  
  DateTime now = rtc.now();
  char date[16];
  sprintf(date, "%04d-%02d-%02d", now.year(), now.month(), now.day());
  return String(date);
}

// ==================== ENROLLMENT CALLBACK ====================

void onFingerprintEnrolled(int fpID, String name, String personID) {
  // Registration completion: show status in UI only.
  // Per requirement, do NOT send SMS or publish to AWS for registration.
  INFO_PRINTLN("\n========================================");
  INFO_PRINTLN("   REGISTRATION COMPLETE (UI only)");
  INFO_PRINTLN("========================================\n");
}

// ==================== WEB SERVER ====================

void setupWebServer() {
  // Main page - HTML UI (same as before)
  server.on("/", HTTP_GET, []() {
    String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>🔐 Access Control System</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;padding:20px}
.container{max-width:900px;margin:0 auto;background:rgba(255,255,255,0.95);padding:30px;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3)}
h1{color:#667eea;text-align:center;margin-bottom:10px;font-size:2em;text-shadow:2px 2px 4px rgba(0,0,0,0.1)}
.subtitle{text-align:center;color:#666;margin-bottom:30px;font-size:0.9em}
.tabs{display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap}
.tab{flex:1;min-width:120px;padding:12px;background:#667eea;color:#fff;border:none;border-radius:10px;cursor:pointer;font-size:14px;font-weight:bold;transition:all 0.3s;text-align:center}
.tab:hover{background:#764ba2;transform:translateY(-2px);box-shadow:0 5px 15px rgba(0,0,0,0.2)}
.tab.active{background:#764ba2;box-shadow:0 5px 15px rgba(0,0,0,0.3)}
.content{display:none;animation:fadeIn 0.5s}
.content.active{display:block}
@keyframes fadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
.card{background:#f8f9fa;padding:20px;margin:15px 0;border-radius:15px;box-shadow:0 5px 15px rgba(0,0,0,0.1)}
.card h2{color:#667eea;margin-bottom:15px;font-size:1.3em;display:flex;align-items:center;gap:10px}
.form-group{margin:15px 0}
label{display:block;margin-bottom:8px;font-weight:600;color:#333;font-size:0.95em}
input,select,textarea{width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:15px;transition:all 0.3s;background:#fff}
input:focus,select:focus,textarea:focus{outline:none;border-color:#667eea;box-shadow:0 0 0 3px rgba(102,126,234,0.1)}
button{width:100%;padding:14px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;border-radius:10px;cursor:pointer;font-size:16px;font-weight:bold;transition:all 0.3s;margin-top:10px}
button:hover{transform:translateY(-2px);box-shadow:0 5px 20px rgba(102,126,234,0.4)}
.status{padding:15px;margin:15px 0;border-radius:10px;font-size:14px;display:none}
.status.show{display:block;animation:slideIn 0.3s}
@keyframes slideIn{from{opacity:0;transform:translateX(-20px)}to{opacity:1;transform:translateX(0)}}
.success{background:#d4edda;color:#155724;border-left:5px solid #28a745}
.error{background:#f8d7da;color:#721c24;border-left:5px solid #dc3545}
.info{background:#d1ecf1;color:#0c5460;border-left:5px solid #17a2b8}
.user-item{background:#fff;padding:15px;margin:10px 0;border-radius:10px;border-left:4px solid #667eea;display:flex;justify-content:space-between;align-items:center}
.delete-btn{background:#dc3545;color:#fff;border:none;padding:8px 15px;border-radius:8px;cursor:pointer;font-size:14px}
.system-status{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin-bottom:20px}
.status-card{background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;padding:20px;border-radius:15px;text-align:center;box-shadow:0 5px 15px rgba(0,0,0,0.2)}
</style>
</head>
<body>
<div class="container">
<h1>🔐 Access Control System</h1>
<p class="subtitle">Fingerprint Authentication & Management Portal (Modular)</p>

<div id="system-banner" class="info status" style="margin-bottom:20px;text-align:center;font-weight:bold;"></div>

<div class="tabs">
<button class="tab active" onclick="switchTab('register')">👤 Register</button>
<button class="tab" onclick="switchTab('manage')">📋 Manage</button>
<button class="tab" onclick="switchTab('sms')">📱 SMS Settings</button>
<button class="tab" onclick="switchTab('datetime')">🕒 Date/Time</button>
<button class="tab" onclick="switchTab('status')">📊 Status</button>
<button class="tab" onclick="switchTab('ota')">⬆️ OTA Update</button>
<button class="tab" onclick="switchTab('restart')">🔄 Restart</button>
</div>

<div id="register" class="content active">
<div class="card">
<h2>👤 Register New Fingerprint</h2>
<div class="form-group" style="display:flex;align-items:center;gap:10px;justify-content:space-between;">
  <label style="flex:1;">Registration Mode</label>
  <label class="switch" style="flex:0;display:flex;align-items:center;gap:10px;">
    <input type="checkbox" id="regModeToggle" style="width:auto">
    <span id="regModeLabel">OFF (Normal Mode)</span>
  </label>
  <button style="max-width:180px" onclick="toggleRegistrationMode()">Toggle Mode</button>
  <small id="regModeHint" style="color:#666;flex:1;text-align:right;">Turn ON to allow registration</small>
  <style>.switch input{transform:scale(1.4);}</style>
</div>
<div class="form-group">
<label>Employee Name</label>
<input type="text" id="name" placeholder="Enter employee name">
</div>
<button onclick="enrollFP()">🚀 Start Registration</button>
<div id="enroll-status" class="status"></div>
<div id="enroll-instructions" class="info status" style="margin-top:10px;"></div>
</div>
</div>

<div id="manage" class="content">
<div class="card">
<h2>📋 Registered Users</h2>
<button onclick="loadUsers()" style="margin-bottom:15px">🔄 Refresh List</button>
<button onclick="deleteAllFingerprints()" style="background:#dc3545;margin-bottom:15px">🗑️ Delete All</button>
<div id="users-list"></div>
</div>
</div>

<div id="datetime" class="content">
<div class="card">
<h2>🕒 Set Date & Time</h2>
<div class="form-group">
<label>Select Date and Time</label>
<input type="datetime-local" id="datetime">
</div>
<button onclick="setDateTime()">✅ Update Date & Time</button>
<div id="datetime-status" class="status"></div>
</div>
</div>

<div id="sms" class="content">
<div class="card">
<h2>📱 SMS Settings</h2>
<div class="form-group">
<label style="display:flex;align-items:center;gap:10px;">
<input type="checkbox" id="smsEnabled" style="width:auto">
Enable SMS Notifications
</label>
</div>
<div class="form-group">
<label>📞 Phone Number 1</label>
<input type="text" id="smsPhone1" placeholder="8185861199">
</div>
<div class="form-group">
<label>📞 Phone Number 2 (Optional)</label>
<input type="text" id="smsPhone2" placeholder="9876543210">
</div>
<div class="form-group">
<label>💬 SMS Message Template</label>
<textarea id="smsMessage" style="height:100px;">Access Granted: {name} ({personID}) scanned at {time} on {date}</textarea>
</div>
<button onclick="saveSMSConfig()">💾 Save SMS Settings</button>
<div id="sms-status" class="status"></div>
</div>
</div>

<div id="status" class="content">
<div class="card">
<h2>📊 System Status</h2>
<div id="status-info"></div>
</div>
</div>

<div id="ota" class="content">
<div class="card">
<h2>⬆️ OTA Firmware Update</h2>
<div class="form-group">
<label>Select firmware (.bin)</label>
<input type="file" id="otaFile" accept=".bin,.bin.gz">
</div>
<button onclick="uploadOTA()">🚀 Upload & Update</button>
<div id="ota-status" class="status"></div>
</div>
</div>

<div id="restart" class="content">
<div class="card">
<h2>🔄 Restart ESP32-S3</h2>
<p class="info status show">⚠️ This will restart the ESP32-S3 device. You will need to reconnect to the WiFi after restart.</p>
<button onclick="restartDevice()" style="background:linear-gradient(135deg,#dc3545,#c82333)">🔄 Restart Device</button>
<div id="restart-status" class="status"></div>
</div>
</div>

</div>

<script>
function switchTab(tab){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.content').forEach(c=>c.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById(tab).classList.add('active');
  if(tab==='manage')loadUsers();
  if(tab==='sms')loadSMSConfig();
  if(tab==='status')updateStatus();
}

function showStatus(id,message,type){
  const el=document.getElementById(id);
  el.className='status '+type+' show';
  el.innerHTML=message;
  setTimeout(()=>el.classList.remove('show'),5000);
}

// Poll enrollment status from device and reflect on UI
let enrollPoll=null;
function pollEnrollStatus(){
  fetch('/enrollstatus').then(r=>r.json()).then(d=>{
    if(!d || !d.status) return;
    const s=d.status;
    let type='info';
    let instructionMsg = '';
    
    if(s.startsWith('SUCCESS:')) {
      type='success';
      instructionMsg = '';
    } else if(s.startsWith('ERROR:')) {
      type='error';
      instructionMsg = '';
    } else if(s.startsWith('COMPLETE:')) {
      type='success';
      instructionMsg = '✅ Registration completed successfully!';
    } else if(s.startsWith('STEP:')) {
      type='info';
      // Extract instruction from status
      instructionMsg = s.substring(5); // Remove "STEP:" prefix
    } else {
      type='info';
    }
    
    showStatus('enroll-status',s,type);
    
    // Show instructions separately in a dedicated area
    if(instructionMsg){
      const instrEl = document.getElementById('enroll-instructions');
      instrEl.className = 'info status show';
      instrEl.innerHTML = '📌 ' + instructionMsg;
    }
    
    // Stop polling when enrollment finishes
    if(s.startsWith('COMPLETE:') || s.startsWith('ERROR:')){
      if(enrollPoll){
        clearInterval(enrollPoll);
        enrollPoll=null;
      }
      // Clear instructions after completion
      setTimeout(()=>{
        document.getElementById('enroll-instructions').classList.remove('show');
      }, 5000);
    }
  }).catch(()=>{});
}

function enrollFP(){
  const name=document.getElementById('name').value;
  if(!name){
    showStatus('enroll-status','❌ Please enter employee name','error');
    return;
  }
  // Require registration mode ON
  fetch('/getmode').then(r=>r.json()).then(m=>{
    if(!m.registration){
      showStatus('enroll-status','❌ Enable Registration Mode first','error');
      return;
    }
    startEnrollment(name);
  });
}

function startEnrollment(name){
  // Begin polling status immediately so user sees steps
  if(enrollPoll){clearInterval(enrollPoll);}
  enrollPoll=setInterval(pollEnrollStatus,1000);
  pollEnrollStatus();
  showStatus('enroll-status','⏳ Starting enrollment... Place your finger','info');
  fetch('/nextid').then(r=>r.json()).then(d=>{
    const fpid=d.nextId;
    fetch('/enroll?fpid='+fpid+'&name='+encodeURIComponent(name)+'&personid='+fpid)
      .then(r=>r.json())
      .then(res=>{
        // Once enroll completes, fetch final status and stop polling
        pollEnrollStatus();
      }).catch(()=>{});
  });
}

function loadRegistrationMode(){
  fetch('/getmode').then(r=>r.json()).then(d=>{
    const on = !!d.registration;
    document.getElementById('regModeToggle').checked = on;
    document.getElementById('regModeLabel').innerText = on ? 'ON (Registration Mode)' : 'OFF (Normal Mode)';
    document.getElementById('regModeHint').innerText = on ? 'Registration mode active. Scanning paused.' : 'Turn ON to allow registration';
  });
}

function toggleRegistrationMode(){
  const newVal = !document.getElementById('regModeToggle').checked ? 1 : 0;
  fetch('/setmode?registration='+newVal).then(r=>r.json()).then(()=>{
    loadRegistrationMode();
  });
}

function setDateTime(){
  let dt=document.getElementById('datetime').value;
  if(!dt){
    const now=new Date();
    dt=now.getFullYear()+'-'+(now.getMonth()+1).toString().padStart(2,'0')+'-'+now.getDate().toString().padStart(2,'0')+'T'+now.getHours().toString().padStart(2,'0')+':'+now.getMinutes().toString().padStart(2,'0');
  }
  fetch('/settime?datetime='+encodeURIComponent(dt)).then(r=>r.json()).then(d=>{
    showStatus('datetime-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function loadUsers(){
  fetch('/users').then(r=>r.json()).then(d=>{
    let html='';
    if(d.length==0)html='<div class="info status show">📭 No users</div>';
    else d.forEach(u=>{
      html+=`<div class="user-item"><div><strong>ID ${u.fpID}: ${u.name}</strong></div><button class="delete-btn" onclick="deleteUser(${u.fpID})">Delete</button></div>`;
    });
    document.getElementById('users-list').innerHTML=html;
  });
}

function deleteUser(fpid){
  if(confirm('Delete fingerprint ID '+fpid+'?')) fetch('/delete?fpid='+fpid).then(r=>r.json()).then(d=>{
    if(d.success)loadUsers();
  });
}

function deleteAllFingerprints(){
  if(confirm('⚠️ DELETE ALL FINGERPRINTS?')) fetch('/deleteall').then(r=>r.json()).then(d=>{
    if(d.success){
      alert('✅ Deleted!');
      loadUsers();
    }
  });
}

function saveSMSConfig(){
  const params=new URLSearchParams({
    enabled:document.getElementById('smsEnabled').checked,
    phone1:document.getElementById('smsPhone1').value,
    phone2:document.getElementById('smsPhone2').value,
    message:document.getElementById('smsMessage').value
  });
  fetch('/savesms?'+params).then(r=>r.json()).then(d=>{
    showStatus('sms-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function loadSMSConfig(){
  fetch('/smsconfig').then(r=>r.json()).then(d=>{
    document.getElementById('smsEnabled').checked=d.enabled;
    document.getElementById('smsPhone1').value=d.phone1||'';
    document.getElementById('smsPhone2').value=d.phone2||'';
    document.getElementById('smsMessage').value=d.message||'';
  });
}

function updateStatus(){
  fetch('/status').then(r=>r.json()).then(d=>{
    let html='<p><strong>Relay:</strong> '+(d.relay?'🟢 Active':'🔴 Inactive')+'</p>';
    html+='<p><strong>Users:</strong> '+d.users+'</p>';
    html+='<p><strong>Time:</strong> '+d.time+'</p>';
    html+='<hr>';
    html+='<p><strong>Scanning:</strong> '+(d.scanning?'✅ Active':'⏸️ Inactive')+'</p>';
    if(d.enrollStatus && d.enrollStatus !== 'READY:Fingerprint sensor ready' && d.enrollStatus !== ''){
      html+='<p><strong>Enrollment:</strong> '+d.enrollStatus+'</p>';
    }
    
    // Add SIM/Modem Details
    if(d.modem){
      html+='<hr><strong>📡 SIM &amp; Network:</strong><br>';
      html+='<p>Provider: <strong>'+d.modem.provider+'</strong></p>';
      html+='<p>Signal: <strong>'+d.modem.signal+'/31</strong> '+(d.modem.signal>15?'🟢':d.modem.signal>10?'🟡':'🔴')+'</p>';
      html+='<p>SIM: '+(d.modem.simReady?'✅ Ready':'❌ Not Ready')+'</p>';
      html+='<p>Network: '+(d.modem.networkRegistered?'✅ Registered':'⏳ Searching')+'</p>';
      html+='<p>GPRS: '+(d.modem.gprsConnected?'✅ Active':'⏸️ Inactive')+'</p>';
      if(d.modem.ip && d.modem.ip.length>0){
        html+='<p>IP: <small>'+d.modem.ip+'</small></p>';
      }
    }
    
    // Add MQTT/SMS Status
    if(d.mqtt || d.sms){
      html+='<hr><strong>☁️ Cloud &amp; SMS:</strong><br>';
      if(d.mqtt){
        html+='<p>MQTT: '+(d.mqtt.connected?'✅ Connected':'❌ Disconnected')+'</p>';
      }
      if(d.sms){
        html+='<p>SMS: '+(d.sms.enabled?'✅ Enabled':'⏸️ Disabled')+'</p>';
      }
    }
    
    document.getElementById('status-info').innerHTML=html;
  });
}

// Auto-refresh status when on status tab
let statusRefreshInterval = null;
function startStatusRefresh(){
  if(statusRefreshInterval) clearInterval(statusRefreshInterval);
  updateStatus();
  statusRefreshInterval = setInterval(updateStatus, 2000); // Update every 2 seconds
}
function stopStatusRefresh(){
  if(statusRefreshInterval){
    clearInterval(statusRefreshInterval);
    statusRefreshInterval = null;
  }
}

function switchTab(tab){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.content').forEach(c=>c.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById(tab).classList.add('active');
  
  // Stop status refresh when leaving status tab
  stopStatusRefresh();
  
  if(tab==='manage')loadUsers();
  if(tab==='sms')loadSMSConfig();
  if(tab==='status')startStatusRefresh();
}

// Background system status monitor
let systemStatusInterval = null;
function updateSystemBanner(){
  fetch('/status').then(r=>r.json()).then(d=>{
    const banner = document.getElementById('system-banner');
    if(!banner) return;
    
    if(d.scanning){
      banner.className = 'info status show';
      banner.innerHTML = '👆 System Ready - Place finger on scanner to unlock';
    } else if(d.relay){
      banner.className = 'success status show';
      banner.innerHTML = '🔓 Access Granted - Relays Active';
    } else if(d.enrollActive){
      banner.className = 'info status show';
      banner.innerHTML = '📝 Enrollment in Progress';
    } else {
      banner.classList.remove('show');
    }
  }).catch(()=>{});
}

// Start background monitoring when page loads
window.addEventListener('DOMContentLoaded', ()=>{
  updateSystemBanner();
  systemStatusInterval = setInterval(updateSystemBanner, 2000);
  loadRegistrationMode();
});

function uploadOTA(){
  const f=document.getElementById('otaFile').files[0];
  if(!f){
    showStatus('ota-status','❌ Please select a firmware file','error');
    return;
  }
  const fd=new FormData();
  fd.append('update', f, f.name);
  showStatus('ota-status','⏳ Uploading firmware...','info');
  fetch('/update', {method:'POST', body:fd})
    .then(r=>r.json())
    .then(d=>{
      if(d.success){
        showStatus('ota-status','✅ Update successful. Rebooting...','success');
        setTimeout(()=>{ location.reload(); }, 5000);
      } else {
        showStatus('ota-status','❌ Update failed','error');
      }
    })
    .catch(()=>{
      showStatus('ota-status','❌ Upload error','error');
    });
}

function restartDevice(){
  if(confirm('⚠️ Restart ESP32-S3 now?')){
    showStatus('restart-status','⏳ Restarting device...','info');
    fetch('/restart').then(r=>r.json()).then(d=>{
      showStatus('restart-status','✅ Device restarting. Please reconnect after 10 seconds...','success');
      setTimeout(()=>{ location.reload(); }, 10000);
    }).catch(()=>{
      showStatus('restart-status','❌ Restart command failed','error');
    });
  }
}
</script>
</body>
</html>
)rawliteral";
    server.send(200, "text/html", html);
  });
  
  // Get next available fingerprint ID
  server.on("/nextid", HTTP_GET, []() {
    if (!fingerprintMgr->isReady()) {
      server.send(500, "application/json", "{\"success\":false,\"message\":\"Fingerprint sensor not ready\"}");
      return;
    }
    
    int nextId = 1;
    for (int id = 1; id <= 127; id++) {
      if (!fingerprintMgr->loadModel(id)) {
        nextId = id;
        break;
      }
    }
    
    String response = "{\"success\":true,\"nextId\":" + String(nextId) + "}";
    server.send(200, "application/json", response);
  });
  
  // Get enrollment status
  server.on("/enrollstatus", HTTP_GET, []() {
    String response = "{\"status\":\"" + fingerprintMgr->getEnrollmentStatus() + "\"}";
    server.send(200, "application/json", response);
  });
  
  // Enroll fingerprint
  server.on("/enroll", HTTP_GET, []() {
    if (!registrationMode) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Not in registration mode\"}");
      return;
    }
    if (!server.hasArg("fpid") || !server.hasArg("name") || !server.hasArg("personid")) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Missing parameters\"}");
      return;
    }
    
    int fpid = server.arg("fpid").toInt();
    String name = server.arg("name");
    String personid = server.arg("personid");
    
    bool started = fingerprintMgr->startEnrollment(fpid, name, personid);
    String response = "{\"success\":" + String(started ? "true" : "false") + 
                     ",\"message\":\"" + (started ? "Enrollment started" : fingerprintMgr->getEnrollmentStatus()) + "\"}";
    server.send(200, "application/json", response);
  });
  
  // Set date/time
  server.on("/settime", HTTP_GET, []() {
    if (!server.hasArg("datetime") || !rtcReady) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid request\"}");
      return;
    }
    
    String dt = server.arg("datetime");
    int year = dt.substring(0, 4).toInt();
    int month = dt.substring(5, 7).toInt();
    int day = dt.substring(8, 10).toInt();
    int hour = dt.substring(11, 13).toInt();
    int minute = dt.substring(14, 16).toInt();
    
    rtc.adjust(DateTime(year, month, day, hour, minute, 0));
    
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Time updated\"}");
  });
  
  // Get users
  server.on("/users", HTTP_GET, []() {
    DynamicJsonDocument doc(4096);
    JsonArray users = doc.to<JsonArray>();
    
    if (fingerprintMgr->isReady()) {
      int count = fingerprintMgr->getTemplateCount();
      
      for (int id = 1; id <= 200 && users.size() < count; id++) {
        if (fingerprintMgr->loadModel(id)) {
          UserData userData = fingerprintMgr->getUserData(id);
          
          JsonObject user = users.createNestedObject();
          user["fpID"] = id;
          user["name"] = userData.name;
          user["personID"] = userData.personID;
        }
      }
    }
    
    String response = "";
    serializeJson(doc, response);
    server.send(200, "application/json", response);
  });
  
  // Delete fingerprint
  server.on("/delete", HTTP_GET, []() {
    if (!server.hasArg("fpid") || !fingerprintMgr->isReady()) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid request\"}");
      return;
    }
    
    int fpid = server.arg("fpid").toInt();
    
    if (fingerprintMgr->deleteModel(fpid)) {
      Serial.printf("🗑️ Deleted fingerprint ID: %d\n", fpid);
      server.send(200, "application/json", "{\"success\":true,\"message\":\"Fingerprint deleted\"}");
    } else {
      server.send(500, "application/json", "{\"success\":false,\"message\":\"Delete failed\"}");
    }
  });
  
  // Delete ALL fingerprints
  server.on("/deleteall", HTTP_GET, []() {
    if (!fingerprintMgr->isReady()) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Fingerprint sensor not ready\"}");
      return;
    }
    
    Serial.println("🗑️ Deleting ALL fingerprints...");
    
    if (fingerprintMgr->emptyDatabase()) {
      Serial.println("✅ All fingerprints deleted!");
      server.send(200, "application/json", "{\"success\":true,\"message\":\"All fingerprints deleted\"}");
    } else {
      server.send(500, "application/json", "{\"success\":false,\"message\":\"Delete all failed\"}");
    }
  });
  
  // Get system status
  server.on("/status", HTTP_GET, []() {
    String json = "{";
    json += "\"relay\":" + String(relayActive ? "true" : "false") + ",";
    
    int userCount = 0;
    if (fingerprintMgr->isReady()) {
      userCount = fingerprintMgr->getTemplateCount();
    }
    json += "\"users\":" + String(userCount) + ",";
    
    String timeStr = "--:--:--";
    if (rtcReady) {
      DateTime now = rtc.now();
      char timeBuf[32];
      sprintf(timeBuf, "%04d-%02d-%02d %02d:%02d:%02d", 
              now.year(), now.month(), now.day(),
              now.hour(), now.minute(), now.second());
      timeStr = String(timeBuf);
    }
    json += "\"time\":\"" + timeStr + "\",";
    
    // Add enrollment status for UI
    json += "\"enrollStatus\":\"" + fingerprintMgr->getEnrollmentStatus() + "\",";
    json += "\"enrollActive\":" + String(fingerprintMgr->isEnrollmentActive() ? "true" : "false") + ",";
    
    // Add scanning state and registration mode
    json += "\"scanning\":" + String((!relayActive && fingerprintMgr->isReady() && !mscMode && !fingerprintMgr->isEnrollmentActive() && !registrationMode) ? "true" : "false") + ",";
    json += "\"registrationMode\":" + String(registrationMode ? "true" : "false") + ",";
    
    // Add modem and network details
    json += "\"modem\":{";
    json += "\"ready\":" + String(mqttMgr->isModemReady() ? "true" : "false") + ",";
    json += "\"simReady\":" + String(mqttMgr->isSIMReady() ? "true" : "false") + ",";
    json += "\"networkRegistered\":" + String(mqttMgr->isNetworkRegistered() ? "true" : "false") + ",";
    json += "\"gprsConnected\":" + String(mqttMgr->isGPRSConnected() ? "true" : "false") + ",";
    json += "\"signal\":" + String(mqttMgr->getSignalQualityValue()) + ",";
    json += "\"provider\":\"" + mqttMgr->getSIMProvider() + "\",";
    json += "\"ip\":\"" + mqttMgr->getModemIP() + "\"";
    json += "},";
    
    // Add MQTT status
    json += "\"mqtt\":{";
    json += "\"connected\":" + String(mqttMgr->isMQTTConnected() ? "true" : "false");
    json += "},";
    
    // Add SMS status
    json += "\"sms\":{";
    json += "\"enabled\":" + String(smsMgr->isEnabled() ? "true" : "false");
    json += "}";
    
    json += "}";
    
    server.send(200, "application/json", json);
  });
  
  // Get SMS config
  // Registration mode endpoints
  server.on("/getmode", HTTP_GET, []() {
    String json = String("{\"registration\":") + (registrationMode ? "true" : "false") + "}";
    server.send(200, "application/json", json);
  });
  server.on("/setmode", HTTP_GET, []() {
    if (server.hasArg("registration")) {
      String v = server.arg("registration");
      registrationMode = (v == "1" || v == "true");
      String json = String("{\"ok\":true,\"registration\":") + (registrationMode ? "true" : "false") + "}";
      server.send(200, "application/json", json);
    } else {
      server.send(400, "application/json", "{\"ok\":false}");
    }
  });

  server.on("/smsconfig", HTTP_GET, []() {
    String json = "{";
    json += "\"enabled\":" + String(smsMgr->isEnabled() ? "true" : "false") + ",";
    json += "\"phone1\":\"" + smsMgr->getSMSPhone1() + "\",";
    json += "\"phone2\":\"" + smsMgr->getSMSPhone2() + "\",";
    json += "\"message\":\"" + smsMgr->getSMSMessage() + "\"";
    json += "}";
    
    server.send(200, "application/json", json);
  });
  
  // Save SMS config
  server.on("/savesms", HTTP_GET, []() {
    if (server.hasArg("enabled")) {
      smsMgr->setEnabled(server.arg("enabled") == "true");
    }
    if (server.hasArg("phone1")) {
      smsMgr->setSMSPhone1(server.arg("phone1"));
    }
    if (server.hasArg("phone2")) {
      smsMgr->setSMSPhone2(server.arg("phone2"));
    }
    if (server.hasArg("message")) {
      smsMgr->setSMSMessage(server.arg("message"));
    }
    
    smsMgr->saveSMSConfig();
    
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Settings saved!\"}");
  });

  // Restart ESP32
  server.on("/restart", HTTP_GET, []() {
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Restarting...\"}");
    delay(1000);
    ESP.restart();
  });

  // OTA firmware update
  server.on("/update", HTTP_POST,
    []() {
      bool ok = !Update.hasError();
      String resp = "{\"success\":" + String(ok ? "true" : "false") + "}";
      server.send(200, "application/json", resp);
      if (ok) {
        delay(200);
        ESP.restart();
      }
    },
    []() {
      HTTPUpload &upload = server.upload();
      if (upload.status == UPLOAD_FILE_START) {
        DEBUG_PRINTLN("OTA: Upload start: " + upload.filename);
        if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
          Update.printError(Serial);
        }
      } else if (upload.status == UPLOAD_FILE_WRITE) {
        if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
          Update.printError(Serial);
        }
      } else if (upload.status == UPLOAD_FILE_END) {
        if (!Update.end(true)) {
          Update.printError(Serial);
        } else {
          DEBUG_PRINTLN("OTA: Update complete, size: " + String(upload.totalSize));
        }
      }
    }
  );
}
