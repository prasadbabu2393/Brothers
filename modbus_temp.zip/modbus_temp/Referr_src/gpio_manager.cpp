#include "gpio_manager.h"
#include "debug.h"

// Default GPIO pins
#define DEFAULT_GPIO1_PIN 4
#define DEFAULT_GPIO2_PIN 5
#define DEFAULT_DEBOUNCE_TIME 50  // 50ms debounce

GPIOManager::GPIOManager() 
    : _gpio1Pin(DEFAULT_GPIO1_PIN),
      _gpio2Pin(DEFAULT_GPIO2_PIN),
      _input1State(false),
      _input2State(false),
      _input1PrevState(false),
      _input2PrevState(false),
      _debounceTime(DEFAULT_DEBOUNCE_TIME),
      _lastDebounceTime1(0),
      _lastDebounceTime2(0),
      _input1Reading(false),
      _input2Reading(false),
      _newEventAvailable(false),
      _eventSource(0) {
}

void GPIOManager::begin() {
    DEBUG_PRINTLN("[GPIO] Initializing GPIO Manager...");
    
    // Load configuration from flash
    loadConfig();
    
    // Configure GPIO pins as inputs with pull-down resistors
    pinMode(_gpio1Pin, INPUT_PULLDOWN);
    pinMode(_gpio2Pin, INPUT_PULLDOWN);
    
    // Read initial states
    _input1State = digitalRead(_gpio1Pin);
    _input2State = digitalRead(_gpio2Pin);
    _input1PrevState = _input1State;
    _input2PrevState = _input2State;
    
    DEBUG_PRINT("[GPIO] GPIO1 Pin: ");
    DEBUG_PRINT(_gpio1Pin);
    DEBUG_PRINT(" | Initial State: ");
    DEBUG_PRINTLN(_input1State ? "ON" : "OFF");
    
    DEBUG_PRINT("[GPIO] GPIO2 Pin: ");
    DEBUG_PRINT(_gpio2Pin);
    DEBUG_PRINT(" | Initial State: ");
    DEBUG_PRINTLN(_input2State ? "ON" : "OFF");
    
    DEBUG_PRINT("[GPIO] Debounce Time: ");
    DEBUG_PRINT(_debounceTime);
    DEBUG_PRINTLN(" ms");
}

void GPIOManager::loop() {
    checkGPIO1();
    checkGPIO2();
}

void GPIOManager::checkGPIO1() {
    bool reading = digitalRead(_gpio1Pin);
    
    // If the reading has changed, reset the debounce timer
    if (reading != _input1Reading) {
        _lastDebounceTime1 = millis();
        _input1Reading = reading;
    }
    
    // If enough time has passed, consider it a stable reading
    if ((millis() - _lastDebounceTime1) > _debounceTime) {
        // If the reading is different from the current state, we have a toggle
        if (reading != _input1State) {
            _input1PrevState = _input1State;
            _input1State = reading;
            
            // Signal a new event
            _newEventAvailable = true;
            _eventSource = 1;
            
            DEBUG_PRINT("[GPIO] Input 1 Toggled: ");
            DEBUG_PRINTLN(_input1State ? "ON" : "OFF");
        }
    }
}

void GPIOManager::checkGPIO2() {
    bool reading = digitalRead(_gpio2Pin);
    
    // If the reading has changed, reset the debounce timer
    if (reading != _input2Reading) {
        _lastDebounceTime2 = millis();
        _input2Reading = reading;
    }
    
    // If enough time has passed, consider it a stable reading
    if ((millis() - _lastDebounceTime2) > _debounceTime) {
        // If the reading is different from the current state, we have a toggle
        if (reading != _input2State) {
            _input2PrevState = _input2State;
            _input2State = reading;
            
            // Signal a new event
            _newEventAvailable = true;
            _eventSource = 2;
            
            DEBUG_PRINT("[GPIO] Input 2 Toggled: ");
            DEBUG_PRINTLN(_input2State ? "ON" : "OFF");
        }
    }
}

void GPIOManager::loadConfig() {
    _prefs.begin("gpio", false);
    
    _gpio1Pin = _prefs.getUChar("gpio1_pin", DEFAULT_GPIO1_PIN);
    _gpio2Pin = _prefs.getUChar("gpio2_pin", DEFAULT_GPIO2_PIN);
    _debounceTime = _prefs.getUInt("debounce", DEFAULT_DEBOUNCE_TIME);
    
    _prefs.end();
    
    DEBUG_PRINTLN("[GPIO] Configuration loaded from flash");
}

void GPIOManager::saveConfig() {
    _prefs.begin("gpio", false);
    
    _prefs.putUChar("gpio1_pin", _gpio1Pin);
    _prefs.putUChar("gpio2_pin", _gpio2Pin);
    _prefs.putUInt("debounce", _debounceTime);
    
    _prefs.end();
    
    DEBUG_PRINTLN("[GPIO] Configuration saved to flash");
}

void GPIOManager::setGPIO1Pin(uint8_t pin) {
    if (pin != _gpio1Pin) {
        _gpio1Pin = pin;
        pinMode(_gpio1Pin, INPUT_PULLDOWN);
        _input1State = digitalRead(_gpio1Pin);
        _input1PrevState = _input1State;
        DEBUG_PRINT("[GPIO] GPIO1 pin changed to: ");
        DEBUG_PRINTLN(_gpio1Pin);
    }
}

void GPIOManager::setGPIO2Pin(uint8_t pin) {
    if (pin != _gpio2Pin) {
        _gpio2Pin = pin;
        pinMode(_gpio2Pin, INPUT_PULLDOWN);
        _input2State = digitalRead(_gpio2Pin);
        _input2PrevState = _input2State;
        DEBUG_PRINT("[GPIO] GPIO2 pin changed to: ");
        DEBUG_PRINTLN(_gpio2Pin);
    }
}

void GPIOManager::setDebounceTime(uint32_t ms) {
    _debounceTime = ms;
    DEBUG_PRINT("[GPIO] Debounce time set to: ");
    DEBUG_PRINT(_debounceTime);
    DEBUG_PRINTLN(" ms");
}
