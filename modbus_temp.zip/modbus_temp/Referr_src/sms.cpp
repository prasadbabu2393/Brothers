#include "sms.h"
#include "debug.h"
#include <Preferences.h>

static Preferences preferences;

SMSManager::SMSManager(RTC_DS3231* rtcPtr, HardwareSerial* modemPtr)
  : rtc(rtcPtr), rtcReady(rtcPtr != nullptr), modemSerial(modemPtr),
    modemReady(false), networkRegistered(false), smsEnabled(true),
    apn_name("bsnlnet"), mqttConnected(false) {
}

SMSManager::~SMSManager() {
}

void SMSManager::loadSMSConfig() {
  preferences.begin("sms", true);
  
  smsPhone1 = preferences.getString("phone1", "");
  smsPhone2 = preferences.getString("phone2", "");
  smsMessage = preferences.getString("message", "Access Granted: {name} ({personID}) scanned at {time} on {date}");
  smsEnabled = preferences.getBool("enabled", true);
  
  preferences.end();
  
  INFO_PRINTLN("\n═══ SMS Configuration (from Flash) ═══");
  INFO_PRINTLN("Phone 1: " + (smsPhone1.length() > 0 ? smsPhone1 : "(not set)"));
  INFO_PRINTLN("Phone 2: " + (smsPhone2.length() > 0 ? smsPhone2 : "(not set)"));
  INFO_PRINTLN("Enabled: " + String(smsEnabled ? "Yes" : "No"));
  INFO_PRINTLN("═══════════════════════════════════════\n");
}

void SMSManager::saveSMSConfig() {
  preferences.begin("sms", false);
  
  preferences.putString("phone1", smsPhone1);
  preferences.putString("phone2", smsPhone2);
  preferences.putString("message", smsMessage);
  preferences.putBool("enabled", smsEnabled);
  
  preferences.end();
  
  STATUS_OK("SMS config saved to flash!");
}

void SMSManager::sendSMS(String number, String message) {
  if (!modemReady || !networkRegistered) {
    STATUS_FAIL("Modem not ready - SMS not sent");
    DEBUG_PRINTF("   Modem:%d Network:%d\n", modemReady, networkRegistered);
    return;
  }
  
  if (number.length() == 0) {
    WARN_PRINTLN("Phone number not configured");
    return;
  }
  
  // IMPORTANT: Send MQTT keepalive BEFORE SMS to keep connection alive
  if (mqttConnected) {
    DEBUG_PRINTLN("Sending MQTT keepalive before SMS...");
    String cmd = "AT+QMTPING=0";
    modemSerial->println(cmd);
    
    unsigned long start = millis();
    String response = "";
    while (millis() - start < 5000) {
      if (modemSerial->available()) {
        response += (char)modemSerial->read();
      }
    }
    
    if (response.indexOf("OK") != -1) {
      STATUS_OK("Keepalive sent - MQTT connection refreshed");
    } else {
      WARN_PRINTLN("Keepalive failed");
    }
  }
  
  // Add +91 prefix if number doesn't start with +
  if (!number.startsWith("+")) {
    number = "+91" + number;
    DEBUG_PRINTLN("Added country code: " + number);
  }
  
  INFO_PRINTLN("\n📤 Sending SMS to " + number + "...");
  DEBUG_PRINTF("Message length: %d chars\n", message.length());
  DEBUG_PRINTLN("Message content: [" + message + "]");
  
  // Clear buffer completely
  delay(100);
  while (modemSerial->available()) {
    char c = modemSerial->read();
    DEBUG_PRINT(String(c));
  }
  delay(100);
  
  // Set SMS text mode
  DEBUG_PRINTLN("\nSending AT+CMGF=1...");
  modemSerial->println("AT+CMGF=1");
  
  unsigned long start = millis();
  String response = "";
  while (millis() - start < 3000) {
    if (modemSerial->available()) {
      char c = modemSerial->read();
      response += c;
      DEBUG_PRINT(String(c));
    }
  }
  
  if (response.indexOf("OK") == -1) {
    STATUS_FAIL("SMS mode failed! Response: " + response);
    return;
  }
  STATUS_OK("SMS mode set");
  
  delay(500);
  while (modemSerial->available()) modemSerial->read();
  
  // Send SMS command
  String cmd = "AT+CMGS=\"" + number + "\"";
  DEBUG_PRINTLN("\nSending: " + cmd);
  modemSerial->println(cmd);
  
  // Wait for '>' prompt
  start = millis();
  bool promptReceived = false;
  response = "";
  
  while (millis() - start < 5000) {
    if (modemSerial->available()) {
      char c = modemSerial->read();
      response += c;
      DEBUG_PRINT(String(c));
      if (c == '>') {
        promptReceived = true;
        break;
      }
    }
  }
  
  if (!promptReceived) {
    STATUS_FAIL("No '>' prompt! Response: " + response);
    modemSerial->write(0x1B);
    delay(100);
    while (modemSerial->available()) modemSerial->read();
    return;
  }
  
  STATUS_OK("Got prompt, sending message...");
  delay(100);
  
  // Send message character by character with echo
  for (unsigned int i = 0; i < message.length(); i++) {
    modemSerial->write(message[i]);
    DEBUG_PRINT(String(message[i]));
    delay(10);
  }
  DEBUG_PRINTLN("");
  
  delay(300);
  modemSerial->write(0x1A);
  STATUS_OK("Sent Ctrl+Z (0x1A)");
  
  // Wait for send confirmation
  start = millis();
  response = "";
  
  while (millis() - start < 30000) {
    if (modemSerial->available()) {
      char c = modemSerial->read();
      response += c;
      DEBUG_PRINT(String(c));
      
      if (response.indexOf("+CMGS:") != -1 && response.indexOf("OK") != -1) {
        INFO_PRINTLN("\n✅✅✅ SMS sent successfully!");
        
        // IMPORTANT: Check and restore MQTT connection after SMS
        delay(1000);
        if (!mqttConnected) {
          DEBUG_PRINTLN("Checking MQTT connection after SMS...");
          String mqttCheck = "AT+QMTCONN?";
          modemSerial->println(mqttCheck);
          
          unsigned long mqttStart = millis();
          String mqttResponse = "";
          while (millis() - mqttStart < 2000) {
            if (modemSerial->available()) {
              mqttResponse += (char)modemSerial->read();
            }
          }
          
          if (mqttResponse.indexOf("+QMTCONN: 0,0,0") == -1) {
            WARN_PRINTLN("MQTT disconnected after SMS, would need reconnect");
          } else {
            STATUS_OK("MQTT still connected");
          }
        }
        return;
      }
      if (response.indexOf("ERROR") != -1 || response.indexOf("+CMS ERROR") != -1) {
        STATUS_FAIL("SMS send error: " + response);
        return;
      }
    }
  }
  
  STATUS_FAIL("SMS send timeout! Last response: " + response);
}

void SMSManager::sendModbusAlert(float reg1, float reg2) {
  if (!smsEnabled) {
    DEBUG_PRINTLN("SMS disabled, skipping alert.");
    return;
  }
  
  if (!rtcReady) {
    WARN_PRINTLN("RTC not ready, cannot create timestamp for SMS.");
    return;
  }
  
  // Create a standard message for Modbus alerts
  String message = "Modbus Alert! Trigger Value: ";
  message += String(reg1, 2);
  message += ". Full reading: [";
  message += String(reg1, 2);
  message += ", ";
  message += String(reg2, 2);
  message += "]. Time: ";
  message += getRTCTimestamp();

  // Send to configured phone numbers
  if (smsPhone1.length() > 0) {
    sendSMS(smsPhone1, message);
    delay(2000); // Delay between sending two SMS
  }
  
  if (smsPhone2.length() > 0) {
    sendSMS(smsPhone2, message);
  }
}

void SMSManager::sendCustomSMS(String message) {
  if (!smsEnabled) {
    INFO_PRINTLN("SMS is disabled in config");
    return;
  }
  
  // Send to configured phone numbers
  if (smsPhone1.length() > 0) {
    sendSMS(smsPhone1, message);
    delay(2000); // Delay between sending two SMS
  }
  
  if (smsPhone2.length() > 0) {
    sendSMS(smsPhone2, message);
  }
}

void SMSManager::setSMSPhone1(String phone) {
  smsPhone1 = phone;
}

void SMSManager::setSMSPhone2(String phone) {
  smsPhone2 = phone;
}

void SMSManager::setSMSMessage(String message) {
  smsMessage = message;
}

void SMSManager::setAPNName(String apn) {
  apn_name = apn;
}

void SMSManager::setEnabled(bool enabled) {
  smsEnabled = enabled;
}

void SMSManager::setModemStatus(bool ready, bool network, bool mqtt) {
  modemReady = ready;
  networkRegistered = network;
  mqttConnected = mqtt;
}

String SMSManager::getSMSPhone1() const {
  return smsPhone1;
}

String SMSManager::getSMSPhone2() const {
  return smsPhone2;
}

String SMSManager::getSMSMessage() const {
  return smsMessage;
}

String SMSManager::getAPNName() const {
  return apn_name;
}

bool SMSManager::isEnabled() const {
  return smsEnabled;
}

String SMSManager::getRTCTimestamp() {
  if (!rtcReady || !rtc) return "00:00:00";
  
  DateTime now = rtc->now();
  char timestamp[16];
  sprintf(timestamp, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  return String(timestamp);
}
