#ifndef GPIO_MANAGER_H
#define GPIO_MANAGER_H

#include <Arduino.h>
#include <Preferences.h>

class GPIOManager {
public:
    GPIOManager();
    
    void begin();
    void loop();
    
    // Configuration methods
    void loadConfig();
    void saveConfig();
    void setGPIO1Pin(uint8_t pin);
    void setGPIO2Pin(uint8_t pin);
    void setDebounceTime(uint32_t ms);
    
    // Getter methods
    uint8_t getGPIO1Pin() const { return _gpio1Pin; }
    uint8_t getGPIO2Pin() const { return _gpio2Pin; }
    uint32_t getDebounceTime() const { return _debounceTime; }
    
    // Status methods
    bool getInput1Status() const { return _input1State; }
    bool getInput2Status() const { return _input2State; }
    String getInput1StatusString() const { return _input1State ? "ON" : "OFF"; }
    String getInput2StatusString() const { return _input2State ? "ON" : "OFF"; }
    
    // Check if there's a new toggle event
    bool hasNewEvent() const { return _newEventAvailable; }
    uint8_t getEventSource() const { return _eventSource; } // 1 for GPIO1, 2 for GPIO2
    void clearEvent() { _newEventAvailable = false; }

private:
    Preferences _prefs;
    
    // GPIO pins
    uint8_t _gpio1Pin;
    uint8_t _gpio2Pin;
    
    // Current states
    bool _input1State;
    bool _input2State;
    
    // Previous states for toggle detection
    bool _input1PrevState;
    bool _input2PrevState;
    
    // Debouncing
    uint32_t _debounceTime;
    uint32_t _lastDebounceTime1;
    uint32_t _lastDebounceTime2;
    bool _input1Reading;
    bool _input2Reading;
    
    // Event tracking
    bool _newEventAvailable;
    uint8_t _eventSource; // 1 or 2
    
    // Helper methods
    void checkGPIO1();
    void checkGPIO2();
};

#endif // GPIO_MANAGER_H
