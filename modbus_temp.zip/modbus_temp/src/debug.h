#ifndef DEBUG_H
#define DEBUG_H

#include <Arduino.h>

// ==================== DEBUG CONTROL ====================
// Set DEBUG_MODE to 1 for development, 0 for production
// This can be overridden by defining DEBUG_MODE before including this file
#ifndef DEBUG_MODE
#define DEBUG_MODE 0  // Change to 1 for verbose output
#endif

// ==================== DEBUG MACROS ====================

// Verbose debug prints (disabled in production)
#if DEBUG_MODE
  #define DEBUG_PRINT(x) Serial.print(x)
  #define DEBUG_PRINTLN(x) Serial.println(x)
  #define DEBUG_PRINTF(fmt, ...) Serial.printf(fmt, ##__VA_ARGS__)
#else
  #define DEBUG_PRINT(x)
  #define DEBUG_PRINTLN(x)
  #define DEBUG_PRINTF(fmt, ...)
#endif

// Error/Warning prints (always enabled)
#define ERROR_PRINTLN(x) Serial.println("❌ ERROR: " + String(x))
#define ERROR_PRINTF(fmt, ...) Serial.printf("❌ ERROR: " fmt "\n", ##__VA_ARGS__)
#define WARN_PRINTLN(x) Serial.println("⚠️ WARNING: " + String(x))
#define WARN_PRINTF(fmt, ...) Serial.printf("⚠️ WARNING: " fmt "\n", ##__VA_ARGS__)

// Info prints (always enabled - important status)
#define INFO_PRINTLN(x) Serial.println(x)
#define INFO_PRINTF(fmt, ...) Serial.printf(fmt "\n", ##__VA_ARGS__)

// Status prints with icons (always enabled - critical info)
#define STATUS_OK(x) Serial.println("✅ " + String(x))
#define STATUS_FAIL(x) Serial.println("❌ " + String(x))
#define STATUS_WAIT(x) Serial.println("⏳ " + String(x))
#define STATUS_INFO(x) Serial.println("ℹ️ " + String(x))

#endif // DEBUG_H
