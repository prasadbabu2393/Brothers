#ifndef SDCARD_H
#define SDCARD_H

#include <Arduino.h>
#include "FS.h"
#include "SD.h"
#include "SPI.h"

class SDCardManager {
private:
  SPIClass* spiSD;
  bool sdReady;
  
  // Pin definitions
  uint8_t misoPin;
  uint8_t sckPin;
  uint8_t mosiPin;
  uint8_t csPin;

public:
  SDCardManager(uint8_t miso, uint8_t sck, uint8_t mosi, uint8_t cs);
  ~SDCardManager();
  
  // Initialization and status
  void initialize();
  void reinitialize();
  bool isReady() const;
  uint64_t getCardSize();
  
  // File operations
  bool fileExists(const char* path);
  File openFile(const char* path, const char* mode);
  bool deleteFile(const char* path);
  bool createFile(const char* path, const char* content = "");
  
  // Directory operations
  bool dirExists(const char* path);
  
  // Utility
  void printFSInfo();
  void endSD();
  void beginSPI();
};

#endif // SDCARD_H
