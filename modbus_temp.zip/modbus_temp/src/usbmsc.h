#ifndef USBMSC_H
#define USBMSC_H

#include <Arduino.h>
#include "USB.h"
#include "USBMSC.h"
#include "FS.h"
#include "SD.h"

class USBMSCManager {
private:
  USBMSC msc;
  bool mscEnabled;
  bool sdReady;
  
  // Static callback wrappers (since USBMSC needs C-style function pointers)
  static USBMSCManager* instance;
  static int32_t onWrite(uint32_t lba, uint32_t offset, uint8_t* buffer, uint32_t bufsize);
  static int32_t onRead(uint32_t lba, uint32_t offset, void* buffer, uint32_t bufsize);
  static bool onStartStop(uint8_t power_condition, bool start, bool load_eject);

public:
  USBMSCManager();
  ~USBMSCManager();
  
  // Initialization and control
  void initialize(uint64_t cardSize);
  void enable(uint64_t cardSize);
  void disable();
  bool isEnabled() const;
  
  // Configuration
  void setVendorID(const char* vendor);
  void setProductID(const char* product);
  void setProductRevision(const char* revision);
};

#endif // USBMSC_H
