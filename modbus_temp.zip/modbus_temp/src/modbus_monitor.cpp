/*
 * ESP32-S3 Modbus Monitoring System
 * 
 * Features:
 * - Reads two float values from a Modbus device
 * - Triggers events when temperature crosses configurable low/high thresholds
 * - CSV logging to SD card with RTC timestamps
 * - USB Mass Storage for SD card access
 * - WiFi SoftAP for configuration
 * - OTA firmware updates
 * - Modular architecture
 * 
 * Hardware Connections:
 * 
 * SD Card (SPI):
 * - MISO: GPIO 39, SCK: GPIO 40, MOSI: GPIO 41, CS: GPIO 42
 * 
 * RTC DS3231 (I2C):
 * - SDA: GPIO 11, SCL: GPIO 10
 * 
 * Modbus (UART1):
 * - TX: GPIO 9, RX: GPIO 3
 * 
 * Relays:
 * - Relay 1: GPIO 4
 * - Relay 2: GPIO 5
 * 
 * USB Detection:
 * - VSTAT: GPIO 8
 */

#include "FS.h"
#include "SD.h"
#include "SPI.h"
#include "Wire.h"
#include "RTClib.h"
#include "USB.h"
#include "USBMSC.h"
#include <WiFi.h>
#include <WebServer.h>
#include <Update.h>
#include <ArduinoJson.h>
#include <Preferences.h>

// ==================== DEBUG CONTROL ====================
#define DEBUG_MODE 1
#include "debug.h"

// Include modular classes
#include "modbus_manager.h"
#include "mqtt.h"
#include "sms.h"
#include "sdcard.h"
#include "usbmsc.h"

// Pin Definitions
#define SD_MISO 39
#define SD_SCK  40
#define SD_MOSI 41
#define SD_CS   42
#define RTC_SDA 11
#define RTC_SCL 10
#define MODBUS_TX 9
#define MODBUS_RX 3
#define MODBUS_DE_RE 7
#define RELAY1  47
#define RELAY2  21
#define USB_VSTAT 8
#define IO 12 //to disable relay

// WiFi AP Settings
const char* AP_SSID = "Teamp_Monitor#01";
const char* AP_PASS = "12345678";

// Objects
RTC_DS3231 rtc;
HardwareSerial modemSerial(2);
HardwareSerial modbusSerial(1); // Use UART1 for Modbus
WebServer server(80);
Preferences preferences;

// Modular class instances
ModbusManager* modbusMgr = nullptr;
MQTTManager* mqttMgr = nullptr;
SMSManager* smsMgr = nullptr;
SDCardManager* sdcardMgr = nullptr;
USBMSCManager* usbmscMgr = nullptr;

// Global State
bool sdReady = false;
bool rtcReady = false;
bool mscMode = false;
bool apMode = false;
String currentLogFile = "";

// Modem State
bool modemReady = false;
bool simPresent = false;
bool networkRegistered = false;
int signalQuality = 0;
bool gprsConnected = false;
bool mqttConnected = false;
String modemIP = "";
String simProvider = "Unknown";
String simBalance = "Checking...";
String simICCID = "N/A";
String modemIMEI = "N/A";
String networkType = "Unknown";
String signalPercent = "0%";

// SIM reconnection state
unsigned long lastSimCheckTime = 0;
const unsigned long SIM_CHECK_INTERVAL = 15000; // Check every 15 seconds
bool simReconnecting = false;
int reconnectionAttempts = 0;
const int MAX_RECONNECTION_ATTEMPTS = 3;
unsigned long lastReconnectionAttempt = 0;
const unsigned long RECONNECTION_TIMEOUT = 30000; // 30 seconds between full resets
bool initialConnectionEstablished = false; // Track if we ever had a working connection

// Operation failure tracking
bool smsOperationFailed = false;
bool mqttOperationFailed = false;
int consecutiveOperationFailures = 0;
const int MAX_OPERATION_FAILURES = 2; // Trigger reconnect after 2 consecutive failures

// ==================== FUNCTION DECLARATIONS ====================
void initializeRTC();
void initializeModules();
void createTodayLogFile();
void logModbusTrigger(float temperature, float humidity, const String& status, float lowThreshold, float highThreshold);
bool ensureMQTTConnection();
void triggerModemReconnection(); // Force modem reconnection
void enableMSC();
void disableMSC();
void startSoftAP();
void stopSoftAP();
void setupWebServer();
String getRTCTimestamp();
String getRTCDate();
void activateRelays();
void deactivateRelays();

// ==================== SETUP ====================
void setup() {
  Serial.begin(115200);
  delay(100);
  
  // Initialize USB subsystem first
  USB.begin();
  
  pinMode(USB_VSTAT, INPUT);
  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  digitalWrite(RELAY1, LOW);
  digitalWrite(RELAY2, LOW);
  
  Serial.println("\n╔═══════════════════════════════════════╗");
  Serial.println("║      ESP32-S3 Modbus Monitor         ║");
  Serial.println("║      Modular Architecture            ║");
  Serial.println("╚═══════════════════════════════════════╝\n");
  
  initializeRTC();
  initializeModules();
  smsMgr->loadSMSConfig();
  
  // Activate GPRS and connect to MQTT
  if (modemReady && simPresent && networkRegistered) {
    Serial.println("\n[5/5] Setting up MQTT connection...");
    mqttMgr->activatePDPContext();
    gprsConnected = mqttMgr->isGPRSConnected();
    if (gprsConnected) {
      mqttMgr->connectToMQTT();
      mqttConnected = mqttMgr->isMQTTConnected();
    }
    initialConnectionEstablished = true; // Mark as established since modem was ready at boot
  } else {
    WARN_PRINTLN("⚠️ Modem/SIM not ready at boot - will retry in background");
  }
  
  // Check for USB connection
  if (digitalRead(USB_VSTAT)) {
    Serial.println("🔌 USB Connected - Starting Mass Storage Mode");
    enableMSC();
  } else {
    // Start WiFi AP Mode
    startSoftAP();
  }
}

// ==================== MAIN LOOP ====================
void loop() {
  // Check USB status with debouncing
  static bool lastUSB = false;
  static unsigned long lastUSBChangeTime = 0;
  static bool usbDebounceState = false;
  const unsigned long USB_DEBOUNCE_DELAY = 200; // 200ms debounce
  
  bool currentUSB = digitalRead(USB_VSTAT);
  
  // Debounce USB state changes
  if (currentUSB != usbDebounceState) {
    lastUSBChangeTime = millis();
    usbDebounceState = currentUSB;
  }
  
  // Only process state change after debounce period
  if ((millis() - lastUSBChangeTime > USB_DEBOUNCE_DELAY) && (currentUSB != lastUSB)) {
    lastUSB = currentUSB;
    if (currentUSB) {
      Serial.println("\n🔌 USB Connected");
      // Wait a moment for any pending SD writes to complete
      delay(100);
      if (apMode) {
        stopSoftAP();
      }
      enableMSC();
    } else {
      Serial.println("\n🔌 USB Disconnected");
      disableMSC();
      if (!apMode) {
        startSoftAP();
      }
    }
  }
  
  // Handle web server
  if (apMode && !mscMode) {
    server.handleClient();
  }
  
  // Check for operation failures and trigger reconnection
  if (smsOperationFailed || mqttOperationFailed) {
    consecutiveOperationFailures++;
    WARN_PRINTF("⚠️ Operation failure detected! Count: %d/%d\n", 
                consecutiveOperationFailures, MAX_OPERATION_FAILURES);
    
    if (consecutiveOperationFailures >= MAX_OPERATION_FAILURES) {
      WARN_PRINTLN("⚠️ Multiple operation failures - forcing modem reconnection!");
      triggerModemReconnection();
      consecutiveOperationFailures = 0;
    }
    
    // Reset flags
    smsOperationFailed = false;
    mqttOperationFailed = false;
  }
  
  // Non-blocking SIM reconnection check
  if (!mscMode && millis() - lastSimCheckTime >= SIM_CHECK_INTERVAL) {
    lastSimCheckTime = millis();
    
    // Check if modem/SIM needs attention (non-blocking check)
    bool currentModemReady = mqttMgr->isModemReady();
    bool currentSimPresent = mqttMgr->isSIMReady();
    bool currentNetworkReg = mqttMgr->isNetworkRegistered();
    
    // Also check signal quality - weak signal can cause issues
    int currentSignal = mqttMgr->getSignalQualityValue();
    bool weakSignal = (currentSignal < 10 && currentSignal != 0); // Less than ~30% signal
    
    // Case 1: Initial boot - modem was never ready, keep trying
    if (!initialConnectionEstablished && (!modemReady || !simPresent)) {
      DEBUG_PRINTLN("🔍 Initial modem setup - checking if ready now...");
      
      // Try quick status check first
      currentModemReady = mqttMgr->checkModemStatus();
      currentSimPresent = mqttMgr->checkSIMStatus();
      
      if (currentModemReady && currentSimPresent) {
        currentNetworkReg = mqttMgr->checkNetworkRegistration();
        
        if (currentNetworkReg) {
          STATUS_OK("✅ Modem/SIM now ready!");
          modemReady = true;
          simPresent = true;
          networkRegistered = true;
          initialConnectionEstablished = true;
          
          // Get SIM details
          signalQuality = mqttMgr->getSignalQualityValue();
          simProvider = mqttMgr->getSIMProvider();
          signalPercent = mqttMgr->getSignalStrengthPercent();
          networkType = mqttMgr->getNetworkType();
          simICCID = mqttMgr->getSIMICCID();
          modemIMEI = mqttMgr->getModemIMEI();
          
          // Connect GPRS/MQTT
          DEBUG_PRINTLN("Connecting to network services...");
          mqttMgr->activatePDPContext();
          gprsConnected = mqttMgr->isGPRSConnected();
          if (gprsConnected) {
            mqttMgr->connectToMQTT();
            mqttConnected = mqttMgr->isMQTTConnected();
          }
          
          // Update SMS manager
          smsMgr->setModemStatus(modemReady, networkRegistered, mqttConnected);
          
          STATUS_OK("Modem fully initialized!");
        }
      } else {
        // Still not ready - try full init every 30 seconds
        if (millis() - lastReconnectionAttempt >= RECONNECTION_TIMEOUT) {
          lastReconnectionAttempt = millis();
          reconnectionAttempts++;
          
          INFO_PRINTLN("════════════════════════════════════════");
          INFO_PRINTF("🔄 Initial Setup Attempt %d\n", reconnectionAttempts);
          INFO_PRINTLN("════════════════════════════════════════");
          
          mqttMgr->initializeModem();
          
          modemReady = mqttMgr->isModemReady();
          simPresent = mqttMgr->isSIMReady();
          networkRegistered = mqttMgr->isNetworkRegistered();
          
          if (modemReady && simPresent && networkRegistered) {
            initialConnectionEstablished = true;
            STATUS_OK("✅ Initial modem setup successful!");
            
            signalQuality = mqttMgr->getSignalQualityValue();
            simProvider = mqttMgr->getSIMProvider();
            signalPercent = mqttMgr->getSignalStrengthPercent();
            networkType = mqttMgr->getNetworkType();
            simICCID = mqttMgr->getSIMICCID();
            modemIMEI = mqttMgr->getModemIMEI();
            
            mqttMgr->activatePDPContext();
            gprsConnected = mqttMgr->isGPRSConnected();
            if (gprsConnected) {
              mqttMgr->connectToMQTT();
              mqttConnected = mqttMgr->isMQTTConnected();
            }
            
            smsMgr->setModemStatus(modemReady, networkRegistered, mqttConnected);
            reconnectionAttempts = 0;
          } else {
            DEBUG_PRINTF("Status: Modem=%d, SIM=%d, Network=%d\n",
                        modemReady, simPresent, networkRegistered);
            WARN_PRINTLN("Will retry in 30 seconds...");
          }
        }
      }
    }
    // Case 2: Connection was working, but now lost
    else if (initialConnectionEstablished) {
      // Detect state changes
      if (modemReady && !currentModemReady) {
        WARN_PRINTLN("⚠️ Modem became unavailable!");
        simReconnecting = true;
        reconnectionAttempts = 0;
      }
      
      if (simPresent && !currentSimPresent) {
        WARN_PRINTLN("⚠️ SIM card removed or lost connection!");
        simReconnecting = true;
        reconnectionAttempts = 0;
      }
      
      if (networkRegistered && !currentNetworkReg) {
        WARN_PRINTLN("⚠️ Network registration lost!");
        simReconnecting = true;
        reconnectionAttempts = 0;
      }
      
      if (weakSignal && (modemReady || simPresent)) {
        DEBUG_PRINTF("⚠️ Weak signal detected: %d/31\n", currentSignal);
      }
      
      // Try to reconnect if needed
      if (simReconnecting) {
        // Check if enough time has passed for full reinit attempt
        if (millis() - lastReconnectionAttempt >= RECONNECTION_TIMEOUT) {
          lastReconnectionAttempt = millis();
          reconnectionAttempts++;
          
          if (reconnectionAttempts <= MAX_RECONNECTION_ATTEMPTS) {
            INFO_PRINTLN("════════════════════════════════════════");
            INFO_PRINTF("🔄 Reconnection Attempt %d/%d\n", reconnectionAttempts, MAX_RECONNECTION_ATTEMPTS);
            INFO_PRINTLN("════════════════════════════════════════");
            
            // Properly disconnect existing connections
            mqttMgr->resetModemConnection();
            mqttConnected = false;
            gprsConnected = false;
            
            // Full modem reinitialization
            DEBUG_PRINTLN("Reinitializing modem...");
            mqttMgr->initializeModem();
            
            // Update states after reinitialization
            modemReady = mqttMgr->isModemReady();
            simPresent = mqttMgr->isSIMReady();
            networkRegistered = mqttMgr->isNetworkRegistered();
            signalQuality = mqttMgr->getSignalQualityValue();
            
            // If connection restored
            if (modemReady && simPresent && networkRegistered) {
              STATUS_OK("✅ SIM connection restored!");
              simReconnecting = false;
              reconnectionAttempts = 0;
              
              // Update SIM details
              simProvider = mqttMgr->getSIMProvider();
              signalPercent = mqttMgr->getSignalStrengthPercent();
              networkType = mqttMgr->getNetworkType();
              simICCID = mqttMgr->getSIMICCID();
              modemIMEI = mqttMgr->getModemIMEI();
              
              // Reconnect GPRS/MQTT
              DEBUG_PRINTLN("Reconnecting to network services...");
              mqttMgr->activatePDPContext();
              gprsConnected = mqttMgr->isGPRSConnected();
              if (gprsConnected) {
                mqttMgr->connectToMQTT();
                mqttConnected = mqttMgr->isMQTTConnected();
              }
              
              // Update SMS manager status
              smsMgr->setModemStatus(modemReady, networkRegistered, mqttConnected);
              
              STATUS_OK("System fully restored!");
            } else {
              STATUS_FAIL("Reconnection attempt failed");
              DEBUG_PRINTF("Status: Modem=%d, SIM=%d, Network=%d, Signal=%d\n",
                          modemReady, simPresent, networkRegistered, signalQuality);
              
              if (reconnectionAttempts >= MAX_RECONNECTION_ATTEMPTS) {
                WARN_PRINTLN("⚠️ Max reconnection attempts reached!");
                WARN_PRINTLN("⚠️ System will continue trying every 30 seconds...");
                // Reset counter to keep trying
                reconnectionAttempts = 0;
              }
            }
          }
        } else {
          // Quick status check between full reinit attempts
          currentModemReady = mqttMgr->checkModemStatus();
          currentSimPresent = mqttMgr->checkSIMStatus();
          currentNetworkReg = mqttMgr->checkNetworkRegistration();
          
          if (currentModemReady && currentSimPresent && currentNetworkReg) {
            STATUS_OK("✅ Connection recovered naturally!");
            simReconnecting = false;
            reconnectionAttempts = 0;
            
            modemReady = true;
            simPresent = true;
            networkRegistered = true;
            signalQuality = mqttMgr->getSignalQualityValue();
            signalPercent = mqttMgr->getSignalStrengthPercent();
            
            // Restore services
            if (!gprsConnected) {
              mqttMgr->activatePDPContext();
              gprsConnected = mqttMgr->isGPRSConnected();
            }
            if (gprsConnected && !mqttConnected) {
              mqttMgr->connectToMQTT();
              mqttConnected = mqttMgr->isMQTTConnected();
            }
            
            smsMgr->setModemStatus(modemReady, networkRegistered, mqttConnected);
          }
        }
      } else {
        // Normal periodic update of connection info
        modemReady = currentModemReady;
        simPresent = currentSimPresent;
        networkRegistered = currentNetworkReg;
        
        if (modemReady && simPresent) {
          signalQuality = mqttMgr->getSignalQualityValue();
          signalPercent = mqttMgr->getSignalStrengthPercent();
        }
      }
    }
  }

  // Handle Modbus Reading and Triggering
  if (modbusMgr && !mscMode) {
    modbusMgr->loop();

    if (modbusMgr->isNewDataAvailable()) {
      float temperature = modbusMgr->getRegister1Value();
      float humidity = modbusMgr->getRegister2Value();
      float lowThreshold = modbusMgr->getLowThreshold();
      float highThreshold = modbusMgr->getHighThreshold();

      String status = "NORMAL";
      if (temperature < lowThreshold) {
        status = "LOW";
      } else if (temperature > highThreshold) {
        status = "HIGH";
      }

      Serial.printf("New Modbus data: Temp=%.2f°C, Hum=%.2f%%, Low=%.2f, High=%.2f -> %s\n",
                    temperature, humidity, lowThreshold, highThreshold, status.c_str());

      // Always log to SD Card (for all readings)
      logModbusTrigger(temperature, humidity, status, lowThreshold, highThreshold);

      if (status != "NORMAL") {
        INFO_PRINTLN("******** TEMPERATURE ALERT ********");
        
        // 1. Activate relays for alert indication
        activateRelays();

        // 2. Send SMS Alert (check for failure)
        if (!smsMgr->sendModbusAlert(temperature, humidity, status, lowThreshold, highThreshold)) {
          smsOperationFailed = true; // Mark SMS as failed
          WARN_PRINTLN("⚠️ SMS operation failed - will trigger reconnection check");
        }

        // 3. Publish to MQTT
        if (ensureMQTTConnection()) {
          String timestamp = String(getRTCDate()) + "T" + String(getRTCTimestamp());
          mqttMgr->publishModbusData(temperature, humidity, status, lowThreshold, highThreshold, timestamp);
        }
        
        INFO_PRINTLN("***********************************");
      } else {
        // Temperature is normal - deactivate relays
        deactivateRelays();
      }
      
      modbusMgr->clearNewDataFlag();
    }
  }
  
  delay(10);
}

// ==================== INITIALIZATION ====================

void initializeRTC() {
  Serial.println("═══════════════════════════════════════");
  Serial.println("RTC Initialization");
  Serial.println("═══════════════════════════════════════");
  
  Wire.begin(RTC_SDA, RTC_SCL);
  
  if (rtc.begin(&Wire)) {
    rtcReady = true;
    Serial.println("✅ RTC OK");
    
    if (rtc.lostPower()) {
      Serial.println("⚠️  Setting default time");
      rtc.adjust(DateTime(2025, 1, 1, 0, 0, 0));
    }
    
    DateTime now = rtc.now();
    Serial.printf("Time: %04d-%02d-%02d %02d:%02d:%02d\n",
                  now.year(), now.month(), now.day(),
                  now.hour(), now.minute(), now.second());
  } else {
    rtcReady = false;
    Serial.println("❌ RTC Failed");
  }
  Serial.println();
}

void initializeModules() {
  // Initialize SD Card Manager
  sdcardMgr = new SDCardManager(SD_MISO, SD_SCK, SD_MOSI, SD_CS);
  sdcardMgr->initialize();
  sdReady = sdcardMgr->isReady();
  
  createTodayLogFile();
  
  // Initialize USB MSC Manager
  usbmscMgr = new USBMSCManager();
  
  // Initialize Modbus Manager with RS485 pins
  modbusMgr = new ModbusManager(modbusSerial, MODBUS_RX, MODBUS_TX, MODBUS_DE_RE);
  modbusMgr->begin();

  // Initialize MQTT Manager (share same modem serial)
  mqttMgr = new MQTTManager(&rtc, &modemSerial);
  mqttMgr->initializeModem();
  modemReady = mqttMgr->isModemReady();
  simPresent = mqttMgr->isSIMReady();
  networkRegistered = mqttMgr->isNetworkRegistered();
  signalQuality = mqttMgr->getSignalQualityValue();
  simProvider = mqttMgr->getSIMProvider();
  gprsConnected = mqttMgr->isGPRSConnected();
  
  // Get additional SIM details
  if (modemReady && simPresent) {
    simICCID = mqttMgr->getSIMICCID();
    modemIMEI = mqttMgr->getModemIMEI();
    signalPercent = mqttMgr->getSignalStrengthPercent();
    networkType = mqttMgr->getNetworkType();
  }
  
  // Initialize SMS Manager
  smsMgr = new SMSManager(&rtc, &modemSerial);
  smsMgr->setModemStatus(modemReady, networkRegistered, mqttMgr->isMQTTConnected());
}

// ==================== LOGGING ====================

static unsigned long logEntryCount = 0;

void createTodayLogFile() {
  if (!sdReady || !rtcReady || !sdcardMgr) return;
  
  DateTime now = rtc.now();
  char filename[32];
  sprintf(filename, "/%04d-%02d-%02d.csv", now.year(), now.month(), now.day());
  currentLogFile = String(filename);
  
  if (!sdcardMgr->fileExists(filename)) {
    File f = sdcardMgr->openFile(filename, "write");
    if (f) {
      f.println("S.No,Timestamp,Temperature,Humidity,Status,LowThreshold,HighThreshold");
      f.close();
      Serial.printf("📝 Created log: %s\n", filename);
      logEntryCount = 0;
    }
  }
}

void logModbusTrigger(float temperature, float humidity, const String& status, float lowThreshold, float highThreshold) {
  if (!sdReady || !rtcReady || !sdcardMgr) return;
  
  createTodayLogFile();
  logEntryCount++;
  
  DateTime now = rtc.now();
  
  File f = sdcardMgr->openFile(currentLogFile.c_str(), "append");
  if (f) {
    char timestamp[32];
    sprintf(timestamp, "%02d:%02d:%02d",
            now.hour(), now.minute(), now.second());
    
    f.printf("%lu,%s,%.2f,%.2f,%s,%.2f,%.2f\n",
             logEntryCount,
             timestamp,
             temperature,
             humidity,
             status.c_str(),
             lowThreshold,
             highThreshold);
    f.close();
    
    Serial.printf("📝 Logged [%lu]: %s - Temp:%.2f, Hum:%.2f - %s\n", 
                  logEntryCount, timestamp, temperature, humidity, status.c_str());
  }
}

// Attempt to bring MQTT back online before publishing events
bool ensureMQTTConnection() {
  if (!mqttMgr) return false;
  
  // Update local connection status from manager
  mqttConnected = mqttMgr->isMQTTConnected();
  if (mqttConnected) {
    consecutiveOperationFailures = 0; // Reset on success
    return true;
  }
  
  Serial.println("🔄 MQTT not connected - reconnecting...");
  mqttMgr->activatePDPContext();
  gprsConnected = mqttMgr->isGPRSConnected();
  if (gprsConnected) {
    mqttMgr->connectToMQTT();
    mqttConnected = mqttMgr->isMQTTConnected();
  }
  
  if (!mqttConnected) {
    Serial.println("⚠️ MQTT reconnect failed");
    mqttOperationFailed = true; // Set failure flag
    return false;
  }
  
  consecutiveOperationFailures = 0; // Reset on success
  return mqttConnected;
}

void triggerModemReconnection() {
  WARN_PRINTLN("🔄 Forcing immediate modem reconnection due to operation failures...");
  simReconnecting = true;
  reconnectionAttempts = 0;
  lastReconnectionAttempt = 0; // Force immediate attempt
}


// ==================== RELAY CONTROL ====================
void activateRelays() {
  digitalWrite(RELAY1, HIGH);
  digitalWrite(RELAY2, HIGH);
  Serial.println("🔴 Relays ACTIVATED - Temperature alert!");
}

void deactivateRelays() {
  digitalWrite(RELAY1, LOW);
  digitalWrite(RELAY2, LOW);
  Serial.println("🟢 Relays DEACTIVATED - Temperature normal");
}

// ==================== USB MASS STORAGE ====================

void enableMSC() {
  if (!sdReady || mscMode || !sdcardMgr || !usbmscMgr) {
    if (mscMode) {
      DEBUG_PRINTLN("⚠️ MSC already enabled");
    } else {
      WARN_PRINTLN("⚠️ Cannot enable MSC - SD card not ready or managers not initialized");
    }
    return;
  }
  
  uint64_t cardSize = sdcardMgr->getCardSize();
  if (cardSize == 0) {
    WARN_PRINTLN("⚠️ Cannot enable MSC - SD card size is 0");
    return;
  }

  // Keep SD mounted but enable USB MSC raw access (matches working reference)
  // The mscMode flag prevents file operations while USB is active
  Serial.println("💾 Enabling USB Mass Storage...");
  Serial.printf("💾 Card Size: %llu MB\n", cardSize / (1024 * 1024));

  usbmscMgr->enable(cardSize);
  
  mscMode = true;
  Serial.println("💾 USB Mass Storage ENABLED - SD card accessible from PC");
  Serial.println("⚠️  Do not unplug while transferring files!");
}

void disableMSC() {
  if (!mscMode || !sdcardMgr || !usbmscMgr) return;
  
  usbmscMgr->disable();
  mscMode = false;
  
  Serial.println("💾 USB Mass Storage DISABLED");
  
  // Reinitialize SD filesystem after USB MSC release
  delay(500);
  sdcardMgr->endSD();
  delay(100);
  sdcardMgr->reinitialize();
}

// ==================== WIFI SOFT AP ====================

void startSoftAP() {
  Serial.println("\n═══════════════════════════════════════");
  Serial.println("Starting WiFi Access Point");
  Serial.println("═══════════════════════════════════════");
  
  WiFi.softAP(AP_SSID, AP_PASS);
  IPAddress IP = WiFi.softAPIP();
  
  Serial.printf("SSID: %s\n", AP_SSID);
  Serial.printf("Password: %s\n", AP_PASS);
  Serial.printf("IP: %s\n", IP.toString().c_str());
  Serial.println("═══════════════════════════════════════\n");
  
  setupWebServer();
  server.begin();
  apMode = true;
}

void stopSoftAP() {
  if (!apMode) return;
  
  server.stop();
  WiFi.softAPdisconnect(true);
  apMode = false;
  Serial.println("📡 WiFi AP Stopped");
}

// ==================== UTILITY FUNCTIONS ====================

String getRTCTimestamp() {
  if (!rtcReady) return "00:00:00";
  
  DateTime now = rtc.now();
  char timestamp[16];
  sprintf(timestamp, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  return String(timestamp);
}

String getRTCDate() {
  if (!rtcReady) return "0000-00-00";
  
  DateTime now = rtc.now();
  char date[16];
  sprintf(date, "%04d-%02d-%02d", now.year(), now.month(), now.day());
  return String(date);
}

// ==================== WEB SERVER ====================

void setupWebServer() {
  server.on("/", HTTP_GET, []() {
    String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>⚙️ RS485 Temp/Humidity Monitor</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:linear-gradient(135deg,#2b5876 0%,#4e4376 100%);min-height:100vh;padding:20px}
.container{max-width:900px;margin:0 auto;background:rgba(255,255,255,0.98);padding:30px;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3)}
h1{color:#2b5876;text-align:center;margin-bottom:10px;font-size:2em;text-shadow:2px 2px 4px rgba(0,0,0,0.1)}
.subtitle{text-align:center;color:#666;margin-bottom:30px;font-size:0.9em}
.tabs{display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap}
.tab{flex:1;min-width:120px;padding:12px;background:#2b5876;color:#fff;border:none;border-radius:10px;cursor:pointer;font-size:14px;font-weight:bold;transition:all 0.3s;text-align:center}
.tab:hover{background:#4e4376;transform:translateY(-2px);box-shadow:0 5px 15px rgba(0,0,0,0.2)}
.tab.active{background:#4e4376;box-shadow:0 5px 15px rgba(0,0,0,0.3)}
.content{display:none;animation:fadeIn 0.5s}
.content.active{display:block}
@keyframes fadeIn{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
.card{background:#f8f9fa;padding:20px;margin:15px 0;border-radius:15px;box-shadow:0 5px 15px rgba(0,0,0,0.1)}
.card h2{color:#2b5876;margin-bottom:15px;font-size:1.3em;display:flex;align-items:center;gap:10px}
.form-group{margin:15px 0}
label{display:block;margin-bottom:8px;font-weight:600;color:#333;font-size:0.95em}
input,select,textarea{width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:15px;transition:all 0.3s;background:#fff}
input:focus,select:focus,textarea:focus{outline:none;border-color:#2b5876;box-shadow:0 0 0 3px rgba(43,88,118,0.1)}
button{width:100%;padding:14px;background:linear-gradient(135deg,#2b5876,#4e4376);color:#fff;border:none;border-radius:10px;cursor:pointer;font-size:16px;font-weight:bold;transition:all 0.3s;margin-top:10px}
button:hover{transform:translateY(-2px);box-shadow:0 5px 20px rgba(43,88,118,0.4)}
.status{padding:15px;margin:15px 0;border-radius:10px;font-size:14px;display:none}
.status.show{display:block;animation:slideIn 0.3s}
@keyframes slideIn{from{opacity:0;transform:translateX(-20px)}to{opacity:1;transform:translateX(0)}}
.success{background:#d4edda;color:#155724;border-left:5px solid #28a745}
.error{background:#f8d7da;color:#721c24;border-left:5px solid #dc3545}
.info{background:#d1ecf1;color:#0c5460;border-left:5px solid #17a2b8}
</style>
</head>
<body>
<div class="container">
<h1>⚙️ RS485 Temp/Humidity Monitor</h1>
<p class="subtitle">Configuration & Management Portal</p>

<div class="tabs">
<button class="tab active" onclick="switchTab('modbus')">🔧 Modbus</button>
<button class="tab" onclick="switchTab('sms')">📱 SMS</button>
<button class="tab" onclick="switchTab('datetime')">🕒 Date/Time</button>
<button class="tab" onclick="switchTab('status')">📊 Status</button>
<button class="tab" onclick="switchTab('ota')">⬆️ OTA</button>
<button class="tab" onclick="switchTab('restart')">🔄 Restart</button>
</div>

<div id="modbus" class="content active">
<div class="card">
<h2>🔧 Modbus Settings</h2>
<div class="form-group">
<label for="lowThreshold">Low Temperature Threshold (°C)</label>
<input type="number" id="lowThreshold" step="0.1" placeholder="e.g., 18.0">
</div>
<div class="form-group">
<label for="highThreshold">High Temperature Threshold (°C)</label>
<input type="number" id="highThreshold" step="0.1" placeholder="e.g., 30.0">
</div>
<div class="form-group">
<label for="periodicity">Polling Periodicity (seconds)</label>
<input type="number" id="periodicity" step="1" placeholder="e.g., 5">
</div>
<button onclick="saveModbusConfig()">💾 Save Modbus Settings</button>
<div id="modbus-status" class="status"></div>
</div>
</div>

<div id="sms" class="content">
<div class="card">
<h2>📱 SMS Settings</h2>
<div class="form-group">
<label style="display:flex;align-items:center;gap:10px;"><input type="checkbox" id="smsEnabled" style="width:auto">Enable SMS Notifications</label>
</div>
<div class="form-group">
<label>📞 Phone Number 1</label>
<input type="text" id="smsPhone1" placeholder="Enter primary phone number">
</div>
<div class="form-group">
<label>📞 Phone Number 2 (Optional)</label>
<input type="text" id="smsPhone2" placeholder="Enter secondary phone number">
</div>
<p class="info status show">SMS message format is fixed in this version.</p>
<button onclick="saveSMSConfig()">💾 Save SMS Settings</button>
<div id="sms-status" class="status"></div>
</div>

<div class="card" style="margin-top:20px">
<h2>📡 SIM & Network Status</h2>
<button onclick="refreshSIMStatus()" style="margin-bottom:15px">🔄 Refresh SIM Status</button>
<div id="sim-status-info">
<p style="text-align:center;color:#666">Loading SIM status...</p>
</div>
</div>
</div>

<div id="datetime" class="content">
<div class="card">
<h2>🕒 Set Date & Time</h2>
<div class="form-group">
<label>Select Date and Time</label>
<input type="datetime-local" id="datetime">
</div>
<button onclick="setDateTime()">✅ Update Date & Time</button>
<div id="datetime-status" class="status"></div>
</div>
</div>

<div id="status" class="content">
<div class="card">
<h2>📊 System Status</h2>
<button onclick="updateStatus()" style="margin-bottom:15px">🔄 Refresh Status</button>
<div id="status-info"></div>
</div>
</div>

<div id="ota" class="content">
<div class="card">
<h2>⬆️ OTA Firmware Update</h2>
<div class="form-group">
<label>Select firmware (.bin)</label>
<input type="file" id="otaFile" accept=".bin,.bin.gz">
</div>
<button onclick="uploadOTA()">🚀 Upload & Update</button>
<div id="ota-status" class="status"></div>
</div>
</div>

<div id="restart" class="content">
<div class="card">
<h2>🔄 Restart ESP32-S3</h2>
<p class="info status show">⚠️ This will restart the ESP32-S3 device. You will need to reconnect to the WiFi after restart.</p>
<button onclick="restartDevice()" style="background:linear-gradient(135deg,#dc3545,#c82333)">🔄 Restart Device</button>
<div id="restart-status" class="status"></div>
</div>
</div>

</div>

<script>
function switchTab(tab){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.content').forEach(c=>c.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById(tab).classList.add('active');
  if(tab==='modbus') loadModbusConfig();
  if(tab==='sms') { loadSMSConfig(); refreshSIMStatus(); }
  if(tab==='status') updateStatus();
}

function showStatus(id,message,type){
  const el=document.getElementById(id);
  el.className='status '+type+' show';
  el.innerHTML=message;
  setTimeout(()=>el.classList.remove('show'),5000);
}

function loadModbusConfig(){
  fetch('/modbusconfig').then(r=>r.json()).then(d=>{
    document.getElementById('lowThreshold').value = d.low_threshold ?? '';
    document.getElementById('highThreshold').value = d.high_threshold ?? '';
    document.getElementById('periodicity').value = (d.periodicity / 1000) || '';
  });
}

function saveModbusConfig(){
  const low = parseFloat(document.getElementById('lowThreshold').value);
  const high = parseFloat(document.getElementById('highThreshold').value);
  if (isNaN(low) || isNaN(high) || high <= low) {
    showStatus('modbus-status','❌ Please set valid low/high thresholds (high must be greater than low)','error');
    return;
  }

  const params=new URLSearchParams({
    low_threshold: low,
    high_threshold: high,
    periodicity: document.getElementById('periodicity').value * 1000
  });
  fetch('/savemodbus?'+params).then(r=>r.json()).then(d=>{
    showStatus('modbus-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function loadSMSConfig(){
  fetch('/smsconfig').then(r=>r.json()).then(d=>{
    document.getElementById('smsEnabled').checked=d.enabled;
    document.getElementById('smsPhone1').value=d.phone1||'';
    document.getElementById('smsPhone2').value=d.phone2||'';
  });
}

function saveSMSConfig(){
  const params=new URLSearchParams({
    enabled:document.getElementById('smsEnabled').checked,
    phone1:document.getElementById('smsPhone1').value,
    phone2:document.getElementById('smsPhone2').value
  });
  fetch('/savesms?'+params).then(r=>r.json()).then(d=>{
    showStatus('sms-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function refreshSIMStatus(){
  fetch('/simstatus').then(r=>r.json()).then(d=>{
    const getStatusIcon = (status) => status ? '✅' : '❌';
    const getSignalColor = (quality) => {
      if (quality >= 20) return '#28a745';
      if (quality >= 10) return '#ffc107';
      return '#dc3545';
    };
    
    let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:15px">';
    
    // Left column
    html += '<div>';
    html += '<p><strong>Modem:</strong> ' + getStatusIcon(d.modemReady) + ' ' + (d.modemReady ? 'Ready' : 'Not Ready') + '</p>';
    html += '<p><strong>SIM Card:</strong> ' + getStatusIcon(d.simPresent) + ' ' + (d.simPresent ? 'Detected' : 'Not Found') + '</p>';
    html += '<p><strong>Network:</strong> ' + getStatusIcon(d.networkRegistered) + ' ' + (d.networkRegistered ? 'Registered' : 'Not Registered') + '</p>';
    html += '<p><strong>GPRS:</strong> ' + getStatusIcon(d.gprsConnected) + ' ' + (d.gprsConnected ? 'Connected' : 'Disconnected') + '</p>';
    html += '<p><strong>MQTT:</strong> ' + getStatusIcon(d.mqttConnected) + ' ' + (d.mqttConnected ? 'Connected' : 'Disconnected') + '</p>';
    html += '</div>';
    
    // Right column
    html += '<div>';
    html += '<p><strong>Signal:</strong> <span style="color:' + getSignalColor(d.signalQuality) + ';font-weight:bold">' + d.signalPercent + '</span> (' + d.signalQuality + '/31)</p>';
    html += '<p><strong>Provider:</strong> ' + d.provider + '</p>';
    html += '<p><strong>Network Type:</strong> ' + d.networkType + '</p>';
    html += '<p><strong>ICCID:</strong> <small>' + d.iccid + '</small></p>';
    html += '<p><strong>IMEI:</strong> <small>' + d.imei + '</small></p>';
    if (d.modemIP && d.modemIP.length > 0) {
      html += '<p><strong>Modem IP:</strong> ' + d.modemIP + '</p>';
    }
    if (d.reconnecting) {
      html += '<p style="color:#ffc107;font-weight:bold">🔄 Reconnecting...</p>';
    }
    html += '</div>';
    
    html += '</div>';
    
    document.getElementById('sim-status-info').innerHTML = html;
  }).catch(err => {
    document.getElementById('sim-status-info').innerHTML = '<p style="color:#dc3545">Failed to fetch SIM status</p>';
  });
}

function setDateTime(){
  let dt=document.getElementById('datetime').value;
  if(!dt){
    const now=new Date();
    dt=now.getFullYear()+'-'+(now.getMonth()+1).toString().padStart(2,'0')+'-'+now.getDate().toString().padStart(2,'0')+'T'+now.getHours().toString().padStart(2,'0')+':'+now.getMinutes().toString().padStart(2,'0');
  }
  fetch('/settime?datetime='+encodeURIComponent(dt)).then(r=>r.json()).then(d=>{
    showStatus('datetime-status',(d.success?'✅ ':'❌ ')+d.message,d.success?'success':'error');
  });
}

function updateStatus(){
  fetch('/status').then(r=>r.json()).then(d=>{
    let html = '<p><strong>RTC Time:</strong> '+d.time+'</p>';
    html += '<p><strong>Modbus Periodicity:</strong> '+(d.modbus_period / 1000)+'s</p>';
    html += '<p><strong>Low Threshold:</strong> '+d.low_threshold+' °C</p>';
    html += '<p><strong>High Threshold:</strong> '+d.high_threshold+' °C</p>';
    html += '<p><strong>Temperature:</strong> '+d.temperature+' °C</p>';
    html += '<p><strong>Humidity:</strong> '+d.humidity+' %RH</p>';
    html += '<p><strong>Status:</strong> '+(d.temp_status || 'NORMAL')+'</p>';
    html += '<hr><p><strong>MQTT Connected:</strong> '+(d.mqtt_connected ? '✅ Yes' : '❌ No')+'</p>';
    document.getElementById('status-info').innerHTML=html;
  });
}

function uploadOTA(){
  const f=document.getElementById('otaFile').files[0];
  if(!f){ showStatus('ota-status','❌ Please select a firmware file','error'); return; }
  const fd=new FormData();
  fd.append('update', f, f.name);
  showStatus('ota-status','⏳ Uploading firmware...','info');
  fetch('/update', {method:'POST', body:fd})
    .then(r=>r.json())
    .then(d=>{
      if(d.success){
        showStatus('ota-status','✅ Update successful. Rebooting...','success');
        setTimeout(()=>{ location.reload(); }, 5000);
      } else {
        showStatus('ota-status','❌ Update failed: ' + (d.error || ''),'error');
      }
    }).catch(()=>{ showStatus('ota-status','❌ Upload error','error'); });
}

function restartDevice(){
  if(!confirm('⚠️ Are you sure you want to restart the ESP32-S3?'))return;
  showStatus('restart-status','⏳ Restarting device...','info');
  fetch('/restart').then(r=>r.json()).then(d=>{
    if(d.success){
      showStatus('restart-status','✅ Device restarting... Please wait 10 seconds and reconnect.','success');
      setTimeout(()=>{location.reload();}, 10000);
    } else {
      showStatus('restart-status','❌ Restart failed','error');
    }
  }).catch(()=>{ showStatus('restart-status','❌ Connection lost (device restarting)','info'); setTimeout(()=>{location.reload();}, 10000); });
}

// Load initial config on page load
window.onload = () => {
  loadModbusConfig();
  updateStatus();
};

</script>
</body>
</html>
)rawliteral";
    server.send(200, "text/html", html);
  });

  // Get Modbus config
  server.on("/modbusconfig", HTTP_GET, []() {
    if (!modbusMgr) return;
    String json = "{";
    json += "\"low_threshold\":" + String(modbusMgr->getLowThreshold()) + ",";
    json += "\"high_threshold\":" + String(modbusMgr->getHighThreshold()) + ",";
    json += "\"periodicity\":" + String(modbusMgr->getPeriodicity());
    json += "}";
    server.send(200, "application/json", json);
  });

  // Save Modbus config
  server.on("/savemodbus", HTTP_GET, []() {
    if (!modbusMgr) return;

    float low = modbusMgr->getLowThreshold();
    float high = modbusMgr->getHighThreshold();

    if (server.hasArg("low_threshold")) {
      low = server.arg("low_threshold").toFloat();
    }
    if (server.hasArg("high_threshold")) {
      high = server.arg("high_threshold").toFloat();
    }

    if (high <= low) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"High threshold must be greater than low threshold\"}");
      return;
    }

    modbusMgr->setLowThreshold(low);
    modbusMgr->setHighThreshold(high);

    if (server.hasArg("periodicity")) {
      modbusMgr->setPeriodicity(server.arg("periodicity").toInt());
    }
    modbusMgr->saveConfig();
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Modbus settings saved!\"}");
  });

  // Get SMS config
  server.on("/smsconfig", HTTP_GET, []() {
    String json = "{";
    json += "\"enabled\":" + String(smsMgr->isEnabled() ? "true" : "false") + ",";
    json += "\"phone1\":\"" + smsMgr->getSMSPhone1() + "\",";
    json += "\"phone2\":\"" + smsMgr->getSMSPhone2() + "\"";
    json += "}";
    server.send(200, "application/json", json);
  });
  
  // Save SMS config
  server.on("/savesms", HTTP_GET, []() {
    if (server.hasArg("enabled")) {
      smsMgr->setEnabled(server.arg("enabled") == "true");
    }
    if (server.hasArg("phone1")) {
      smsMgr->setSMSPhone1(server.arg("phone1"));
    }
    if (server.hasArg("phone2")) {
      smsMgr->setSMSPhone2(server.arg("phone2"));
    }
    smsMgr->saveSMSConfig();
    server.send(200, "application/json", "{\"success\":true,\"message\":\"SMS settings saved!\"}");
  });
  
  // Get SIM status with all details
  server.on("/simstatus", HTTP_GET, []() {
    // Update current values
    if (modemReady && simPresent) {
      signalQuality = mqttMgr->getSignalQualityValue();
      signalPercent = mqttMgr->getSignalStrengthPercent();
    }
    
    String json = "{";
    json += "\"modemReady\":" + String(modemReady ? "true" : "false") + ",";
    json += "\"simPresent\":" + String(simPresent ? "true" : "false") + ",";
    json += "\"networkRegistered\":" + String(networkRegistered ? "true" : "false") + ",";
    json += "\"gprsConnected\":" + String(gprsConnected ? "true" : "false") + ",";
    json += "\"mqttConnected\":" + String(mqttConnected ? "true" : "false") + ",";
    json += "\"signalQuality\":" + String(signalQuality) + ",";
    json += "\"signalPercent\":\"" + signalPercent + "\",";
    json += "\"provider\":\"" + simProvider + "\",";
    json += "\"iccid\":\"" + simICCID + "\",";
    json += "\"imei\":\"" + modemIMEI + "\",";
    json += "\"networkType\":\"" + networkType + "\",";
    json += "\"modemIP\":\"" + modemIP + "\",";
    json += "\"reconnecting\":" + String(simReconnecting ? "true" : "false");
    json += "}";
    server.send(200, "application/json", json);
  });

  // Set date/time
  server.on("/settime", HTTP_GET, []() {
    if (!server.hasArg("datetime") || !rtcReady) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid request\"}");
      return;
    }
    String dt = server.arg("datetime");
    rtc.adjust(DateTime(dt.substring(0, 4).toInt(), dt.substring(5, 7).toInt(), dt.substring(8, 10).toInt(), dt.substring(11, 13).toInt(), dt.substring(14, 16).toInt(), 0));
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Time updated\"}");
  });
  
  // Get system status
  server.on("/status", HTTP_GET, []() {
    String json = "{";
    json += "\"time\":\"" + getRTCDate() + " " + getRTCTimestamp() + "\",";
    if (modbusMgr) {
      json += "\"modbus_period\":" + String(modbusMgr->getPeriodicity()) + ",";
      float t = modbusMgr->getRegister1Value();
      float h = modbusMgr->getRegister2Value();
      float low = modbusMgr->getLowThreshold();
      float high = modbusMgr->getHighThreshold();
      String status = "NORMAL";
      if (t < low) status = "LOW"; else if (t > high) status = "HIGH";
      json += "\"low_threshold\":" + String(low) + ",";
      json += "\"high_threshold\":" + String(high) + ",";
      json += "\"temperature\":" + String(t) + ",";
      json += "\"humidity\":" + String(h) + ",";
      json += "\"temp_status\":\"" + status + "\",";
    }
    json += "\"mqtt_connected\":" + String(mqttConnected ? "true" : "false");
    json += "}";
    server.send(200, "application/json", json);
  });

  // OTA firmware update
  server.on("/update", HTTP_POST,
    []() {
      bool ok = !Update.hasError();
      String resp = "{\"success\":" + String(ok ? "true" : "false") + ",\"error\":\"" + (Update.hasError() ? String(Update.errorString()) : "") + "\"}";
      server.send(200, "application/json", resp);
      if (ok) { ESP.restart(); }
    },
    []() {
      HTTPUpload &upload = server.upload();
      if (upload.status == UPLOAD_FILE_START) {
        if (!Update.begin(UPDATE_SIZE_UNKNOWN)) { Update.printError(Serial); }
      } else if (upload.status == UPLOAD_FILE_WRITE) {
        if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) { Update.printError(Serial); }
      } else if (upload.status == UPLOAD_FILE_END) {
        if (!Update.end(true)) { Update.printError(Serial); }
      }
    }
  );

  // Restart device endpoint
  server.on("/restart", HTTP_GET, []() {
    DEBUG_PRINTLN("[WEB] Restart requested");
    server.send(200, "application/json", "{\"success\":true,\"message\":\"Device restarting...\"}");
    delay(500);  // Give time for response to be sent
    ESP.restart();
  });

  server.begin();
  DEBUG_PRINTLN("[WEB] Web server started");
}
