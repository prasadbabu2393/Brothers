#include "sdcard.h"
#include "debug.h"

SDCardManager::SDCardManager(uint8_t miso, uint8_t sck, uint8_t mosi, uint8_t cs)
  : sdReady(false), misoPin(miso), sckPin(sck), mosiPin(mosi), csPin(cs) {
  spiSD = new SPIClass(HSPI);
}

SDCardManager::~SDCardManager() {
  if (spiSD) {
    SD.end();
    delete spiSD;
  }
}

void SDCardManager::initialize() {
  DEBUG_PRINTLN("═══════════════════════════════════════");
  DEBUG_PRINTLN("SD Card Initialization");
  DEBUG_PRINTLN("═══════════════════════════════════════");
  
  spiSD->begin(sckPin, misoPin, mosiPin, csPin);
  
  if (SD.begin(csPin, *spiSD)) {
    sdReady = true;
    STATUS_OK("SD Card OK");
    DEBUG_PRINTF("Size: %llu MB\n", SD.cardSize() / (1024 * 1024));
  } else {
    sdReady = false;
    STATUS_FAIL("SD Card Failed");
  }
  DEBUG_PRINTLN("");
}

void SDCardManager::reinitialize() {
  if (sdReady) {
    SD.end();
    delay(100);
  }
  
  spiSD->begin(sckPin, misoPin, mosiPin, csPin);
  
  if (SD.begin(csPin, *spiSD)) {
    sdReady = true;
    STATUS_OK("SD Card reinitialized");
  } else {
    sdReady = false;
    STATUS_FAIL("SD Card reinitialization failed");
  }
}

bool SDCardManager::isReady() const {
  return sdReady;
}

uint64_t SDCardManager::getCardSize() {
  if (!sdReady) return 0;
  return SD.cardSize();
}

bool SDCardManager::fileExists(const char* path) {
  if (!sdReady) return false;
  return SD.exists(path);
}

File SDCardManager::openFile(const char* path, const char* mode) {
  if (!sdReady) return File();
  
  const char* writeMode;
  if (String(mode) == "w" || String(mode) == "write") {
    writeMode = FILE_WRITE;
  } else if (String(mode) == "a" || String(mode) == "append") {
    writeMode = FILE_APPEND;
  } else {
    writeMode = FILE_READ;
  }
  
  return SD.open(path, writeMode);
}

bool SDCardManager::deleteFile(const char* path) {
  if (!sdReady) return false;
  
  if (SD.exists(path)) {
    return SD.remove(path);
  }
  return false;
}

bool SDCardManager::createFile(const char* path, const char* content) {
  if (!sdReady) return false;
  
  File f = SD.open(path, FILE_WRITE);
  if (f) {
    if (content && strlen(content) > 0) {
      f.println(content);
    }
    f.close();
    return true;
  }
  return false;
}

bool SDCardManager::dirExists(const char* path) {
  if (!sdReady) return false;
  return SD.exists(path);
}

void SDCardManager::printFSInfo() {
  if (!sdReady) {
    DEBUG_PRINTLN("SD Card not ready");
    return;
  }
  
  DEBUG_PRINTF("Card Size: %llu MB\n", SD.cardSize() / (1024 * 1024));
}

void SDCardManager::endSD() {
  if (sdReady) {
    SD.end();
    sdReady = false;
  }
}

void SDCardManager::beginSPI() {
  spiSD->begin(sckPin, misoPin, mosiPin, csPin);
  SD.begin(csPin, *spiSD);
  sdReady = true;
}
