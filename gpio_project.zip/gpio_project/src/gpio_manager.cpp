#include "gpio_manager.h"
#include "debug.h"

// Default GPIO pins
#define DEFAULT_GPIO1_PIN 4
#define DEFAULT_GPIO2_PIN 5
#define DEFAULT_DEBOUNCE_TIME 50  // 50ms debounce

GPIOManager::GPIOManager() 
    : _gpio1Pin(DEFAULT_GPIO1_PIN),
      _gpio2Pin(DEFAULT_GPIO2_PIN),
      _dgState(false),
      _ebState(false),
      _dgPrevState(false),
      _ebPrevState(false),
      _debounceTime(DEFAULT_DEBOUNCE_TIME),
      _lastDebounceTime1(0),
      _lastDebounceTime2(0),
      _dgReading(false),
      _ebReading(false),
      _newEventAvailable(false),
      _eventSource(0) {
}

void GPIOManager::begin() {
    DEBUG_PRINTLN("[GPIO] Initializing GPIO Manager...");
    
    // Load configuration from flash
    loadConfig();
    
    // Configure GPIO pins as inputs with pull-down resistors
    pinMode(_gpio1Pin, INPUT_PULLDOWN);
    pinMode(_gpio2Pin, INPUT_PULLDOWN);
    
    // Read initial states
    _dgState = digitalRead(_gpio1Pin);
    _ebState = digitalRead(_gpio2Pin);
    _dgPrevState = _dgState;
    _ebPrevState = _ebState;
    
    DEBUG_PRINT("[GPIO] GPIO1 Pin: ");
    DEBUG_PRINT(_gpio1Pin);
    DEBUG_PRINT(" | Initial State: ");
    DEBUG_PRINTLN(_dgState ? "ON" : "OFF");
    
    DEBUG_PRINT("[GPIO] GPIO2 Pin: ");
    DEBUG_PRINT(_gpio2Pin);
    DEBUG_PRINT(" | Initial State: ");
    DEBUG_PRINTLN(_ebState ? "ON" : "OFF");
    
    DEBUG_PRINT("[GPIO] Debounce Time: ");
    DEBUG_PRINT(_debounceTime);
    DEBUG_PRINTLN(" ms");
}

void GPIOManager::loop() {
    checkGPIO1();
    checkGPIO2();
}

void GPIOManager::checkGPIO1() {
    bool reading = digitalRead(_gpio1Pin);
    
    // If the reading has changed, reset the debounce timer
    if (reading != _dgReading) {
        _lastDebounceTime1 = millis();
        _dgReading = reading;
    }
    
    // If enough time has passed, consider it a stable reading
    if ((millis() - _lastDebounceTime1) > _debounceTime) {
        // If the reading is different from the current state, we have a toggle
        if (reading != _dgState) {
            _dgPrevState = _dgState;
            _dgState = reading;
            
            // Signal a new event
            _newEventAvailable = true;
            _eventSource = 1;
            
            DEBUG_PRINT("[GPIO] DG Status Toggled: ");
            DEBUG_PRINTLN(_dgState ? "ON" : "OFF");
        }
    }
}

void GPIOManager::checkGPIO2() {
    bool reading = digitalRead(_gpio2Pin);
    
    // If the reading has changed, reset the debounce timer
    if (reading != _ebReading) {
        _lastDebounceTime2 = millis();
        _ebReading = reading;
    }
    
    // If enough time has passed, consider it a stable reading
    if ((millis() - _lastDebounceTime2) > _debounceTime) {
        // If the reading is different from the current state, we have a toggle
        if (reading != _ebState) {
            _ebPrevState = _ebState;
            _ebState = reading;
            
            // Signal a new event
            _newEventAvailable = true;
            _eventSource = 2;
            
            DEBUG_PRINT("[GPIO] EB Status Toggled: ");
            DEBUG_PRINTLN(_ebState ? "ON" : "OFF");
        }
    }
}

void GPIOManager::loadConfig() {
    _prefs.begin("gpio", false);
    
    _gpio1Pin = _prefs.getUChar("gpio1_pin", DEFAULT_GPIO1_PIN);
    _gpio2Pin = _prefs.getUChar("gpio2_pin", DEFAULT_GPIO2_PIN);
    _debounceTime = _prefs.getUInt("debounce", DEFAULT_DEBOUNCE_TIME);
    
    _prefs.end();
    
    DEBUG_PRINTLN("[GPIO] Configuration loaded from flash");
}

void GPIOManager::saveConfig() {
    _prefs.begin("gpio", false);
    
    _prefs.putUChar("gpio1_pin", _gpio1Pin);
    _prefs.putUChar("gpio2_pin", _gpio2Pin);
    _prefs.putUInt("debounce", _debounceTime);
    
    _prefs.end();
    
    DEBUG_PRINTLN("[GPIO] Configuration saved to flash");
}

void GPIOManager::setGPIO1Pin(uint8_t pin) {
    if (pin != _gpio1Pin) {
        _gpio1Pin = pin;
        pinMode(_gpio1Pin, INPUT_PULLDOWN);
        _dgState = digitalRead(_gpio1Pin);
        _dgPrevState = _dgState;
        DEBUG_PRINT("[GPIO] GPIO1 pin changed to: ");
        DEBUG_PRINTLN(_gpio1Pin);
    }
}

void GPIOManager::setGPIO2Pin(uint8_t pin) {
    if (pin != _gpio2Pin) {
        _gpio2Pin = pin;
        pinMode(_gpio2Pin, INPUT_PULLDOWN);
        _ebState = digitalRead(_gpio2Pin);
        _ebPrevState = _ebState;
        DEBUG_PRINT("[GPIO] GPIO2 pin changed to: ");
        DEBUG_PRINTLN(_gpio2Pin);
    }
}

void GPIOManager::setDebounceTime(uint32_t ms) {
    _debounceTime = ms;
    DEBUG_PRINT("[GPIO] Debounce time set to: ");
    DEBUG_PRINT(_debounceTime);
    DEBUG_PRINTLN(" ms");
}
