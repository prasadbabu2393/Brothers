#include "usbmsc.h"
#include "debug.h"

// Static member initialization
USBMSCManager* USBMSCManager::instance = nullptr;

int32_t USBMSCManager::onWrite(uint32_t lba, uint32_t offset, uint8_t* buffer, uint32_t bufsize) {
  return SD.writeRAW((uint8_t*)buffer, lba) ? bufsize : -1;
}

int32_t USBMSCManager::onRead(uint32_t lba, uint32_t offset, void* buffer, uint32_t bufsize) {
  return SD.readRAW((uint8_t*)buffer, lba) ? bufsize : -1;
}

bool USBMSCManager::onStartStop(uint8_t power_condition, bool start, bool load_eject) {
  return true;
}

USBMSCManager::USBMSCManager()
  : mscEnabled(false), sdReady(false) {
  instance = this;
}

USBMSCManager::~USBMSCManager() {
  if (mscEnabled) {
    disable();
  }
  instance = nullptr;
}

void USBMSCManager::initialize(uint64_t cardSize) {
  DEBUG_PRINTLN("═══════════════════════════════════════");
  DEBUG_PRINTLN("USB Mass Storage Initialization");
  DEBUG_PRINTLN("═══════════════════════════════════════");
  
  uint32_t sectorCount = cardSize / 512;
  
  msc.vendorID("ESP32");
  msc.productID("SD Card");
  msc.productRevision("1.0");
  msc.onRead(onRead);
  msc.onWrite(onWrite);
  msc.onStartStop(onStartStop);
  msc.mediaPresent(true);
  msc.begin(sectorCount, 512);
  
  if (!USB) USB.begin();
  
  mscEnabled = true;
  sdReady = true;
  STATUS_OK("USB Mass Storage initialized");
  DEBUG_PRINTLN("");
}

void USBMSCManager::enable(uint64_t cardSize) {
  if (mscEnabled) {
    DEBUG_PRINTLN("USB MSC already enabled");
    return;
  }
  
  initialize(cardSize);
  STATUS_OK("USB Mass Storage ENABLED");
}

void USBMSCManager::disable() {
  if (!mscEnabled) return;
  
  msc.end();
  mscEnabled = false;
  
  STATUS_OK("USB Mass Storage DISABLED");
  
  delay(500);
  SD.end();
  delay(100);
}

bool USBMSCManager::isEnabled() const {
  return mscEnabled;
}

void USBMSCManager::setVendorID(const char* vendor) {
  msc.vendorID(vendor);
}

void USBMSCManager::setProductID(const char* product) {
  msc.productID(product);
}

void USBMSCManager::setProductRevision(const char* revision) {
  msc.productRevision(revision);
}
