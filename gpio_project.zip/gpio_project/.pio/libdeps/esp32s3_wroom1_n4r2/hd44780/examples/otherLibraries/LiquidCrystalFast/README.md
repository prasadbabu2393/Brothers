LiquidCrystalFast hd44780 examples
=================================

LiquidCrystalFast library must be installed in order to use these sketches.<br>

#### The examples are broken up into sub directories for with/without R/W pin

* `LiquidCrystalFastnoRW`<br>
Contains example sketches that are for LCDs that are wired up directly to Arduino pins without the R/W pin

* `LiquidCrystalFastRW`<br>
Contains example sketches that are for LCDs that are wired up directly to Arduino pins with the R/W pin
