# GPIO Monitor - MQTT/SMS Diagnostic Guide

## Current Issue
MQTT and SMS are not working. Modem responds to AT but initialization stops after "Modem responding".

## What's Happening
Based on the serial output, the initialization sequence is:
1. ✅ RTC Initialization
2. ✅ SD Card OK  
3. ✅ Modem power cycle complete
4. ✅ Modem responding to AT command
5. ❌ **STUCK HERE - No SIM status, network status, or provider output**

## Root Causes to Check

### 1. **SIM Card Issues**
The code now prints: `[SIM] AT+CPIN? Response: ...`

**What to look for in serial output:**
```
✅ SIM ready              → SIM detected, working
❌ No SIM card detected   → SIM not inserted or loose
⚠️ SIM state: +CPIN:...   → SIM needs PIN, etc.
```

**Action:** Check if your SIM card is properly inserted in the ESP32-S3 modem module

### 2. **Network Registration**
The code now prints: `[NETWORK] AT+CREG? Response: ...`

**What to look for:**
```
✅ Network registered (Home/Roaming)  → Cell network OK
⏳ Searching network...                → Still searching (normal initially)
⚠️ Not registered, not searching       → Modem not searching for network
⚠️ Registration status unknown: ...    → Response not recognized
```

**Action:** Ensure you're in an area with signal. The modem may take 1-2 minutes to register.

### 3. **Signal Quality**
The code now prints: `[SIGNAL] AT+CSQ Response: ...`

**What to look for:**
```
✅ Signal: 10/31   → Good signal
⚠️ Signal: 31/31   → Unknown (typically weak signal)
❌ Signal unknown  → Modem not responding to CSQ command
```

**Action:** If signal is 31/31 or unavailable, move to a location with better signal.

### 4. **SIM Provider Detection**
The code now prints: `[MODEM] Detecting SIM provider...`

**What to look for:**
```
✅ Detected: BSNL / Jio / Airtel / VI
⚠️ Unknown operator: [name]
❌ Provider detection failed
```

This determines the correct APN for GPRS connection.

---

## Expected Full Output (When Working)

```
═══════════════════════════════════════
4G Modem Initialization
═══════════════════════════════════════
Powering modem...
✅ Modem power cycle complete
Configuring modem...
Attempt 1/5: ✅ Modem responding

[MODEM] Sending setup commands...
✅ Modem configured

[MODEM] Checking SIM...
[SIM] AT+CPIN? Response: +CPIN: READY
✅ SIM ready

[MODEM] Waiting for network (30-60 sec)...
[NETWORK] AT+CREG? Response: +CREG: 2,1
✅ Network registered (Home/Roaming)!

[MODEM] Checking signal quality...
[SIGNAL] AT+CSQ Response: +CSQ: 15,99
✅ Signal: 15/31

[MODEM] Detecting SIM provider...
Network: BSNL
✅ Detected: BSNL

⚙️ Auto-configuring APN...
✅ APN changed: bsnlnet → bsnlnet

╔═══════════════════════╗
║   MODEM STATUS        ║
╠═══════════════════════╣
║ Ready:    ✅ YES      ║
╚═══════════════════════╝
```

---

## Troubleshooting Steps

### **If SIM status is unknown or fails:**
1. Remove and reinsert the SIM card
2. Check if SIM works in a phone
3. Verify SIM contacts are clean
4. Check SIM card holder on modem isn't damaged

### **If network doesn't register:**
1. Wait 1-2 minutes - network registration takes time
2. Ensure modem has antenna attached
3. Check signal: should see AT+CSQ: 0-20 (not 31)
4. Move to different location with better signal
5. Check if data plan is active on SIM

### **If SMS/MQTT still fails after network OK:**
1. Verify phone number format on UI (with or without +91)
2. Check MQTT server IP (13.203.2.58) is reachable
3. Check if data plan supports GPRS/4G

---

## Next Steps

1. Upload the modified code to ESP32-S3
2. **Monitor serial output carefully** - look for the [SIM], [NETWORK], [SIGNAL] messages
3. Share the **complete serial output** including all those messages
4. We can debug from there

---

## Key Pin Definitions (verify these match your hardware)
```
MODEM TX:  GPIO 16
MODEM RX:  GPIO 17
MODEM KEY: GPIO 38 (power control)
```

If these don't match your wiring, update in [src/mqtt.h](src/mqtt.h#L7-L9)
